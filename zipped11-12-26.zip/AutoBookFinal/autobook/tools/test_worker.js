#!/usr/bin/env node
/**
 * tools/test_worker.js — background watcher for TEST-TAGGED jobs only.
 *
 * Sits on the shared queue (the same one app/trigger/server.js enqueues
 * into) and automatically dry-runs every job that arrives — but ONLY if
 * the job is tagged isTest:true, meaning the trigger request that created
 * it explicitly set { "test": true } in its POST body. tools/fake_trigger.js
 * always sends that tag. The real Monitor Booking sender
 * (monitor-booking/src/notifier/autobook.js) never sends it, so real
 * detected dates are never touched by this watcher.
 *
 * A job that arrives WITHOUT the test tag is deliberately left alone —
 * logged loudly and NOT processed, because there is currently no
 * production (real-submit) worker for this codebase to safely hand it
 * to. Building that real worker is intentionally a separate, later step;
 * this file must never be the thing that clicks a real submit button.
 *
 * Reuses the exact same hardened logic as tools/dry_run_booking.js
 * (ensureLoggedIn, runLeg, SELECTORS) rather than duplicating it — every
 * fix from testing (the btn-check radio click, the flatpickr double-click
 * and month navigation, the dropoff-reset retry, the pax quirk, etc.)
 * applies here automatically too.
 *
 * Usage:
 *   node tools/test_worker.js [--headed]
 *
 * --headed opens a real visible browser window per job (only useful if
 * you're on a machine with an actual display) so you can watch it work —
 * same flag as tools/dry_run_booking.js. Default (no flag) is headless,
 * which is what you'd actually want for a background watcher.
 *
 * IMPORTANT — runs the trigger server itself, in-process:
 * sharedQueue only lives in memory, scoped to ONE Node process. Running
 * `node app/trigger/server.js` in a separate terminal from this watcher
 * would give each its own independent, disconnected queue — the trigger
 * server enqueues into a queue this watcher can never see. So this file
 * starts the trigger server directly, in the same process, guaranteeing
 * they share the exact same queue instance. Do NOT also run
 * `node app/trigger/server.js` separately while this is running — that
 * would either conflict on the port or create a second, useless queue.
 *
 * Leave it running in its own terminal. Feed it jobs from another
 * terminal with tools/fake_trigger.js. Ctrl+C to stop — this exits
 * immediately; if a job is actively mid-flight when you do that, it'll
 * abort (shows up as a logged leg failure, nothing more).
 */

const path = require('path');
require('dotenv').config({ path: path.join(__dirname, '..', '.env'), quiet: true });
const { chromium } = require('playwright');

const { sharedQueue } = require('../app/queue/queue');
const { loadProfile } = require('../app/queue/job');
const { startTriggerServer } = require('../app/trigger/server');
const { SELECTORS, PROFILES_DIR, SCREENSHOTS_DIR, ensureLoggedIn, runLeg } = require('./dry_run_booking');

const HEADED = process.argv.includes('--headed');

let browser = null;
let triggerServer = null;
let shuttingDown = false;

async function processTestJob(job) {
    console.log(`\n=== Processing TEST job ${job.job_id} — profile ${job.profile_id}, ${job.date}, legs: ${job.processes.join(', ')} ===`);

    const profile = loadProfile(job.profile_id, PROFILES_DIR);
    if (!profile) {
        console.error(`  \u274c Profile ${job.profile_id} not found — skipping job.`);
        return;
    }

    const context = await browser.newContext();
    const page = await context.newPage();
    const args = { headed: HEADED, date: job.date };

    try {
        await ensureLoggedIn(context, page, profile.id, args);

        for (const leg of job.processes) {
            // job.legConfigs is resolved once in app/queue/job.js's
            // buildJob(), against this date's actual weekday in
            // Philippine time — not profile.booking[leg] directly, which
            // doesn't exist under the nested monday/wednesday/thursday
            // schema (see app/queue/job.js's resolveDayBooking header
            // comment for why this bit worker.js too, before it was fixed).
            const legConfig = job.legConfigs?.[leg];
            if (!legConfig) {
                console.error(`  \u274c No "${leg}" config in profile ${profile.id} — skipping this leg.`);
                continue;
            }
            try {
                await runLeg(page, profile, leg, legConfig, args);
                console.log(`  \u2705 ${leg} leg dry-run OK for job ${job.job_id}`);
            } catch (err) {
                const failPath = path.join(SCREENSHOTS_DIR, `${job.job_id}-${leg}-FAILED.png`);
                await page.screenshot({ path: failPath }).catch(() => {});
                console.error(`  \u274c ${leg} leg failed for job ${job.job_id}: ${err.message}`);
                console.error(`  Screenshot: ${failPath}`);
            }
        }
    } catch (err) {
        console.error(`  \u274c Job ${job.job_id} failed before any leg ran (likely login): ${err.message}`);
    } finally {
        await context.close();
    }
}

async function mainLoop() {
    while (!shuttingDown) {
        const job = await sharedQueue.dequeue();

        if (!job.isTest) {
            // Deliberately not processed — see file header. This job is
            // now gone from the queue (dequeue() removes it), which is a
            // real limitation worth fixing (e.g. a persistent log or a
            // proper production worker to hand it to) before this is
            // used anywhere near real trigger traffic.
            console.warn(
                `\n\u26a0\u26a0\u26a0  Received a NON-TEST job (${job.job_id}, source="${job.source}") — ` +
                `IGNORING IT. This watcher only handles test-tagged jobs; there is no production worker yet. ` +
                `This job has been dropped from the queue and will not be retried.`
            );
            continue;
        }

        await processTestJob(job);
    }
}

async function main() {
    console.log(`Test worker starting — ${HEADED ? 'HEADED' : 'headless'}, dry-run only, test-tagged jobs only.`);
    triggerServer = startTriggerServer(); // in-process, so it shares sharedQueue with the loop below
    browser = await chromium.launch({ headless: !HEADED });
    console.log(`Watching the shared queue (current size: ${sharedQueue.size()}). Waiting for jobs...`);
    console.log('Feed it from another terminal with: node tools/fake_trigger.js "<date>"\n');

    await mainLoop();
}

async function shutdown() {
    if (shuttingDown) return;
    shuttingDown = true;
    console.log('\nShutting down after the current job finishes...');
    if (triggerServer) triggerServer.close();
    if (browser) await browser.close();
    process.exit(0);
}

process.on('SIGINT', shutdown);
process.on('SIGTERM', shutdown);

main();
