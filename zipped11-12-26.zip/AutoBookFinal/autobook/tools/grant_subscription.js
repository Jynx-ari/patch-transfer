// Manual subscription grant — a fast, safe stopgap for granting access
// RIGHT NOW, before the full claim/payment pipeline (session 2) exists.
// This is the CLI form of the "direct grant" concept from the payments
// spec patch (section 9.1) — pulled forward on its own since a customer
// wanting to buy shouldn't have to wait for the whole claims system to
// be built first.
//
// Writes the same `subscription` schema as tools/backfill_subscriptions.js
// and app/queue/subscription.js — nothing downstream (the trigger/worker
// gates, admin panel) needs to know this came from a CLI grant instead of
// a future automated claim approval.
//
// SAFE BY DEFAULT: dry-run unless --apply, same convention as the
// backfill script. Respects the 7-slot capacity ceiling for genuinely
// NEW occupants — pass --force-capacity to knowingly override (e.g. a
// real emergency), never silent.
//
// Usage:
//   node tools/grant_subscription.js <profileId> <plan> [options]
//
// Plans: day_pass | weekly | biweekly | monthly | custom
//
// Options:
//   --apply                  actually write the file (default: dry run / preview only)
//   --type=paid|complimentary|gifted   default: paid
//   --amount=<number>        overrides the plan's list price (e.g. discounted rate)
//   --days=<n>                required when plan=custom — length of access in days
//   --reason="..."            free text, stored on the subscription record
//   --granted-by="admin"      default: "admin"
//   --force-capacity          allow granting a NEW occupant even at 7/7 (logged, not silent)
//
// Examples:
//   node tools/grant_subscription.js 123456789 weekly --apply
//   node tools/grant_subscription.js 123456789 custom --days=10 --amount=50 --apply
//   node tools/grant_subscription.js 123456789 monthly --type=gifted --reason="thanks for the bug report" --apply

const fs = require('fs');
const path = require('path');
const yaml = require('js-yaml');
const { getCapacitySummary, todayISO } = require('../app/queue/subscription');

const PROFILES_DIR = path.join(__dirname, '..', 'profiles');

const PLAN_PRICES = {
    day_pass: 15,
    weekly: 30,
    biweekly: 55,
    monthly: 100,
};

function addDays(isoDate, days) {
    const d = new Date(isoDate + 'T00:00:00Z');
    d.setUTCDate(d.getUTCDate() + days);
    return d.toISOString().slice(0, 10);
}

function addOneMonth(isoDate) {
    const d = new Date(isoDate + 'T00:00:00Z');
    d.setUTCMonth(d.getUTCMonth() + 1);
    return d.toISOString().slice(0, 10);
}

function parseArgs(argv) {
    const [profileId, plan, ...rest] = argv;
    const opts = { apply: false, type: 'paid', grantedBy: 'admin', forceCapacity: false };
    for (const arg of rest) {
        if (arg === '--apply') opts.apply = true;
        else if (arg === '--force-capacity') opts.forceCapacity = true;
        else if (arg.startsWith('--type=')) opts.type = arg.slice('--type='.length);
        else if (arg.startsWith('--amount=')) opts.amount = Number(arg.slice('--amount='.length));
        else if (arg.startsWith('--days=')) opts.days = Number(arg.slice('--days='.length));
        else if (arg.startsWith('--reason=')) opts.reason = arg.slice('--reason='.length).replace(/^"|"$/g, '');
        else if (arg.startsWith('--granted-by=')) opts.grantedBy = arg.slice('--granted-by='.length).replace(/^"|"$/g, '');
    }
    return { profileId, plan, opts };
}

function computeExpiry(plan, opts, startDate) {
    if (plan === 'custom') {
        if (!opts.days || opts.days <= 0) {
            throw new Error('plan=custom requires --days=<n>');
        }
        return addDays(startDate, opts.days);
    }
    if (plan === 'monthly') return addOneMonth(startDate);
    if (plan === 'day_pass') return startDate; // valid for the single selected operating day
    if (plan === 'weekly') return addDays(startDate, 7);
    if (plan === 'biweekly') return addDays(startDate, 14);
    throw new Error(`Unknown plan "${plan}". Use one of: day_pass, weekly, biweekly, monthly, custom`);
}

function run() {
    const { profileId, plan, opts } = parseArgs(process.argv.slice(2));

    if (!profileId || !plan) {
        console.log('Usage: node tools/grant_subscription.js <profileId> <plan> [--apply] [--type=paid|complimentary|gifted] [--amount=N] [--days=N (plan=custom only)] [--reason="..."] [--force-capacity]');
        process.exit(1);
    }

    const file = path.join(PROFILES_DIR, `${profileId}.yaml`);
    if (!fs.existsSync(file)) {
        console.error(`ERROR: no profile YAML found for ${profileId}. Create the profile first (they need to run through Stella at least once).`);
        process.exit(1);
    }

    const profile = yaml.load(fs.readFileSync(file, 'utf8')) || {};
    const today = todayISO();

    let startDate = today;
    // Renewal: if this profile already has an unexpired subscription,
    // extend from ITS expiry rather than from today, so a renewal never
    // shortens or loses already-paid time.
    const existing = profile.subscription;
    if (existing && existing.expiry_date && existing.expiry_date >= today) {
        startDate = existing.expiry_date;
        console.log(`Note: profile already has an active subscription until ${existing.expiry_date} — treating this as a RENEWAL, stacking on top rather than replacing it.`);
    }

    let expiryDate;
    try {
        expiryDate = computeExpiry(plan, opts, startDate);
    } catch (e) {
        console.error(`ERROR: ${e.message}`);
        process.exit(1);
    }

    const amount = opts.amount !== undefined ? opts.amount : (PLAN_PRICES[plan] ?? null);

    // Capacity check — only matters for a genuinely NEW occupant. A
    // renewal (profile already occupying a slot) never needs to check
    // this, per app/queue/subscription.js's hasCapacityFor() reasoning.
    const capacity = getCapacitySummary(PROFILES_DIR);
    const alreadyOccupying = capacity.occupants.some(o => o.id === String(profileId));
    if (!alreadyOccupying && capacity.atCapacity && !opts.forceCapacity) {
        console.error(`ERROR: capacity is full (${capacity.used}/${capacity.max}) and this would be a NEW occupant. Refusing to grant.`);
        console.error('Pass --force-capacity to override anyway (this will exceed the 7-slot ceiling — do this knowingly, not by habit).');
        process.exit(1);
    }
    if (!alreadyOccupying && capacity.atCapacity && opts.forceCapacity) {
        console.warn(`WARNING: overriding capacity ceiling (${capacity.used}/${capacity.max}) via --force-capacity.`);
    }

    const newSub = {
        type: opts.type,
        plan,
        status: 'active',
        amount_paid: amount,
        start_date: startDate,
        expiry_date: expiryDate,
        granted_by: opts.grantedBy,
        reason: opts.reason || null,
        note: null,
    };

    console.log(`${opts.apply ? 'GRANTING' : 'WOULD GRANT'} to ${profileId} (${profile.name || 'unnamed'}):`);
    console.log(JSON.stringify(newSub, null, 2));
    console.log(`Capacity after this grant: ${alreadyOccupying ? capacity.used : capacity.used + 1}/${capacity.max}`);

    if (opts.apply) {
        profile.subscription = newSub;
        fs.writeFileSync(file, yaml.dump(profile, { lineWidth: -1 }));
        console.log('\nWritten. This profile is now eligible for the next scheduled booking run.');
    } else {
        console.log('\nThis was a dry run — nothing was written. Re-run with --apply to actually grant this.');
    }
}

run();
