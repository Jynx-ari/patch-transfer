#!/usr/bin/env node
/**
 * tools/fake_trigger.js — simulates Monitor Booking's POST to Autobook's
 * trigger endpoint, so you can test the trigger server + queue + profile
 * validation without running the real Monitor Booking pipeline, and
 * without touching docker-compose.part2.yml or any container at all.
 *
 * The trigger server's Docker container deliberately has NO port mapped
 * to the host (see docker-compose.part2.yml's comments) — that's on
 * purpose, so nothing outside the Docker network can hit it. This means
 * a host-side script can never reach the containerized version, by
 * design. To test, run the trigger server directly on the host instead
 * (same "host-only dev tool" pattern as dry_run_booking.js):
 *
 *   Terminal 1 (starts the real trigger server, on host, not Docker):
 *     node app/trigger/server.js
 *
 *   Terminal 2 (this script — sends a fake "date opened" signal to it):
 *     node tools/fake_trigger.js "August 31, 2026" "September 2, 2026"
 *
 * No AUTOBOOK_TRIGGER_HOST override needed — its own default (127.0.0.1)
 * is already correct for this. Both terminals read the same autobook/.env,
 * so AUTOBOOK_TRIGGER_SECRET and AUTOBOOK_TRIGGER_PORT automatically match.
 *
 * SAFETY: this only exercises enqueueForNewDates() — it reads+validates
 * your real profiles and pushes jobs onto the in-memory queue. There is
 * currently no worker consuming that queue and driving a browser, so
 * this cannot cause a real booking no matter what dates you pass.
 */

const path = require('path');
require('dotenv').config({ path: path.join(__dirname, '..', '.env'), quiet: true });

const HOST = process.env.AUTOBOOK_TRIGGER_HOST || '127.0.0.1';
const PORT = parseInt(process.env.AUTOBOOK_TRIGGER_PORT, 10) || 4790;
const SECRET = process.env.AUTOBOOK_TRIGGER_SECRET;

async function main() {
    const dates = process.argv.slice(2);
    if (dates.length === 0) {
        console.error('Usage: node tools/fake_trigger.js "August 31, 2026" ["September 2, 2026" ...]');
        process.exit(1);
    }
    if (!SECRET) {
        console.error('AUTOBOOK_TRIGGER_SECRET is not set in autobook/.env — the trigger server will reject this with 401.');
        process.exit(1);
    }

    const url = `http://${HOST}:${PORT}/trigger/date-open`;
    console.log(`POSTing ${dates.length} fake date(s) to ${url} ...`);
    console.log(`Dates: ${dates.join(', ')}\n`);

    let res;
    try {
        res = await fetch(url, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'x-trigger-secret': SECRET,
            },
            body: JSON.stringify({ dates, source: 'fake_trigger (manual test)', test: true }),
        });
    } catch (err) {
        console.error(`Couldn't reach the trigger server at ${url}: ${err.message}`);
        console.error('Is it actually running? In another terminal: node app/trigger/server.js');
        process.exit(1);
    }

    const body = await res.json().catch(() => null);
    console.log(`Response: HTTP ${res.status}`);
    console.log(JSON.stringify(body, null, 2));

    if (res.ok && body?.enqueued?.length) {
        console.log(`\n\u2705 ${body.enqueued.length} job(s) enqueued. Queue size is now ${body.queueSize}.`);
        console.log('Nothing actually books anything yet — there\'s no worker consuming this queue and driving a ' +
            'browser. This only proves the trigger endpoint + queue + profile validation are wired correctly.');
    } else if (res.ok) {
        console.log('\nRequest succeeded but nothing was enqueued — likely no active/valid profiles in profiles/. ' +
            'Check the "skipped" list above if present.');
    }

    if (body?.skipped?.length) {
        console.log(`\n\u26a0  ${body.skipped.length} profile(s) skipped (failed validation):`);
        body.skipped.forEach(s => console.log(`  - ${s.profileId}: ${s.errors.join('; ')}`));
    }
}

main();
