#!/usr/bin/env python3
"""
inspect_page.py — Autobook Phase 1 dev tool.

Opens a booking website with Playwright and reports every form control
that might matter for automation: <select> dropdowns and their options,
radio button groups, checkboxes, text inputs, and buttons.

This is a READ-ONLY inspection tool. It never submits anything.

Usage:
    python inspect_page.py https://example-booking-site.com
    python inspect_page.py https://example-booking-site.com --headed
    python inspect_page.py https://example-booking-site.com --wait-selector "#booking-form"
    python inspect_page.py https://example-booking-site.com --login-url https://example.com/login \
        --username-env AUTOBOOK_INSPECT_USER --password-env AUTOBOOK_INSPECT_PASS \
        --username-selector "#email" --password-selector "#password" --submit-selector "#login-btn"

Credentials, if used, are read only from environment variables (never from
CLI args or hardcoded values) so they don't end up in shell history or logs.

Install:
    pip install playwright
    playwright install chromium
"""

import argparse
import asyncio
import os
import sys
from dataclasses import dataclass, field


@dataclass
class SelectInfo:
    identifier: str
    label: str
    options: list = field(default_factory=list)


async def inspect(args: argparse.Namespace) -> None:
    try:
        from playwright.async_api import async_playwright
    except ImportError:
        print("Playwright is not installed. Run:\n"
              "  pip install playwright\n"
              "  playwright install chromium", file=sys.stderr)
        sys.exit(1)

    async with async_playwright() as p:
        browser = await p.chromium.launch(headless=not args.headed)
        context = await browser.new_context()
        page = await context.new_page()

        # Optional login flow, credentials only ever pulled from env vars.
        if args.login_url:
            await _do_login(page, args)

        target = args.login_url and args.post_login_url or args.url
        print(f"\nNavigating to: {target}\n")
        await page.goto(target, wait_until="networkidle")

        if args.wait_selector:
            await page.wait_for_selector(args.wait_selector, timeout=15000)

        await _report_selects(page)
        await _report_radios(page)
        await _report_checkboxes(page)
        await _report_text_inputs(page)
        await _report_buttons(page)

        if args.headed:
            print("\n(Headed mode: browser stays open 30s for manual poking around.)")
            await page.wait_for_timeout(30000)

        await browser.close()


async def _do_login(page, args: argparse.Namespace) -> None:
    if not (args.username_env and args.password_env):
        print("--login-url given but --username-env/--password-env missing. Skipping login.",
              file=sys.stderr)
        return

    username = os.environ.get(args.username_env)
    password = os.environ.get(args.password_env)
    if not username or not password:
        print(f"Env vars {args.username_env}/{args.password_env} not set. Skipping login.",
              file=sys.stderr)
        return

    print(f"Logging in via {args.login_url} ...")
    await page.goto(args.login_url, wait_until="networkidle")
    await page.fill(args.username_selector, username)
    await page.fill(args.password_selector, password)
    await page.click(args.submit_selector)
    await page.wait_for_load_state("networkidle")
    print("Login flow submitted (success is not verified by this tool — check the page manually).")


async def _report_selects(page) -> None:
    print("=== SELECT ELEMENTS ===\n")
    selects = await page.query_selector_all("select")
    if not selects:
        print("  (none found)\n")
        return

    for sel in selects:
        name = await sel.get_attribute("name") or ""
        el_id = await sel.get_attribute("id") or ""
        identifier = el_id or name or "(unnamed)"

        label = await _find_label_for(page, el_id)
        header = f"{label or identifier}"
        if el_id or name:
            header += f"  [id={el_id or '-'} name={name or '-'}]"
        print(header)

        options = await sel.query_selector_all("option")
        for i, opt in enumerate(options, start=1):
            value = await opt.get_attribute("value")
            text = (await opt.inner_text()).strip()
            print(f"  {i}. {text}  (value={value})")
        print()


async def _report_radios(page) -> None:
    radios = await page.query_selector_all("input[type=radio]")
    if not radios:
        return
    print("=== RADIO GROUPS ===\n")
    groups: dict = {}
    for r in radios:
        name = await r.get_attribute("name") or "(unnamed group)"
        value = await r.get_attribute("value")
        el_id = await r.get_attribute("id") or ""
        label = await _find_label_for(page, el_id)
        groups.setdefault(name, []).append(label or value or "(unlabeled)")

    for name, opts in groups.items():
        print(f"{name}")
        for i, o in enumerate(opts, start=1):
            print(f"  {i}. {o}")
        print()


async def _report_checkboxes(page) -> None:
    boxes = await page.query_selector_all("input[type=checkbox]")
    if not boxes:
        return
    print("=== CHECKBOXES ===\n")
    for b in boxes:
        name = await b.get_attribute("name") or ""
        el_id = await b.get_attribute("id") or ""
        label = await _find_label_for(page, el_id)
        print(f"  {label or name or el_id or '(unlabeled checkbox)'}  [id={el_id or '-'} name={name or '-'}]")
    print()


async def _report_text_inputs(page) -> None:
    inputs = await page.query_selector_all(
        "input[type=text], input[type=date], input[type=time], input:not([type])"
    )
    if not inputs:
        return
    print("=== TEXT / DATE / TIME INPUTS ===\n")
    for i in inputs:
        name = await i.get_attribute("name") or ""
        el_id = await i.get_attribute("id") or ""
        placeholder = await i.get_attribute("placeholder") or ""
        label = await _find_label_for(page, el_id)
        print(f"  {label or placeholder or name or el_id or '(unlabeled input)'}  "
              f"[id={el_id or '-'} name={name or '-'} placeholder={placeholder or '-'}]")
    print()


async def _report_buttons(page) -> None:
    buttons = await page.query_selector_all("button, input[type=submit], input[type=button]")
    if not buttons:
        return
    print("=== BUTTONS ===\n")
    for b in buttons:
        text = (await b.inner_text()) if await b.get_attribute("type") not in ("submit", "button") else ""
        text = text.strip() if text else (await b.get_attribute("value") or "")
        el_id = await b.get_attribute("id") or ""
        print(f"  {text or '(no text)'}  [id={el_id or '-'}]")
    print()


async def _find_label_for(page, el_id: str):
    if not el_id:
        return None
    try:
        label_el = await page.query_selector(f'label[for="{el_id}"]')
        if label_el:
            text = (await label_el.inner_text()).strip()
            return text or None
    except Exception:
        pass
    return None


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Inspect a booking website's form controls.")
    parser.add_argument("url", help="URL of the page to inspect (or the pre-login page if using --login-url)")
    parser.add_argument("--headed", action="store_true", help="Show the browser window instead of headless")
    parser.add_argument("--wait-selector", help="CSS selector to wait for before inspecting (e.g. '#booking-form')")

    login_group = parser.add_argument_group("optional login flow")
    login_group.add_argument("--login-url", help="URL of the login page")
    login_group.add_argument("--post-login-url", help="URL to navigate to after login (defaults to `url`)")
    login_group.add_argument("--username-env", help="Env var name holding the username")
    login_group.add_argument("--password-env", help="Env var name holding the password")
    login_group.add_argument("--username-selector", default="#username", help="CSS selector for username field")
    login_group.add_argument("--password-selector", default="#password", help="CSS selector for password field")
    login_group.add_argument("--submit-selector", default="#login-submit", help="CSS selector for login submit button")

    return parser


if __name__ == "__main__":
    parser = build_parser()
    args = parser.parse_args()
    asyncio.run(inspect(args))
