// One-time migration script — writes the new `subscription` block (see
// app/queue/subscription.js) onto the profiles that already have real,
// pre-existing arrangements from before the subscription system existed:
//
//   - The legacy ₱250 supporters: complimentary access through
//     2026-12-31 (spec patch section 8). Confirmed as 4 real customer
//     supporters (Sammyy☆, 雨KAI, Vercus, Volkov Pava) — a 5th name once
//     assumed to be a supporter (Jyn_ari.x) turned out to be the
//     operator's own profile, not a paying customer, so it's
//     deliberately excluded below rather than backfilled.
//   - Kendrick: already paid ₱100 for a Monthly plan, currently active
//     (this is a normal PAID subscription, just backfilled by hand
//     because the claim/payment pipeline didn't exist yet when he paid).
//
// Deliberately data-driven (the table below) rather than clever
// auto-detection — there is no reliable signal on disk that says "this
// profile already paid ₱250" or "this one paid ₱100 for a month", so
// this has to be told explicitly, once, by a human who knows the real
// history. Anyone NOT in this table is left untouched — they'll go
// through the normal claim/payment flow like any new customer.
//
// SAFE TO RE-RUN: by default this NEVER overwrites a profile that
// already has a `subscription` block — re-running after a partial run,
// or after the claims system has since updated someone's subscription,
// won't clobber real data. Pass --force to overwrite anyway (e.g. if you
// made a mistake in the table below and need to fix it before anyone's
// touched their subscription since).
//
// Usage:
//   node tools/backfill_subscriptions.js            # dry run, prints what it WOULD do
//   node tools/backfill_subscriptions.js --apply     # actually writes the YAML files
//   node tools/backfill_subscriptions.js --apply --force   # also overwrite existing subscription blocks

const fs = require('fs');
const path = require('path');
const yaml = require('js-yaml');

const PROFILES_DIR = path.join(__dirname, '..', 'profiles');

// ---- the one thing you edit when running this for real -------------------

const MIGRATION_DATE = new Date().toISOString().slice(0, 10); // today, YYYY-MM-DD — used as start_date when the real original payment date isn't known

const BACKFILL_TABLE = {
    // The 5 legacy ₱250 infra-upgrade supporters — complimentary through
    // Dec 31, 2026. If you know any of their ACTUAL original payment
    // dates, replace MIGRATION_DATE below with that instead; it only
    // affects display/audit, not the (fixed) expiry.
    '1082890102818218014': { // Sammyy☆
        type: 'complimentary', plan: 'legacy_supporter', amount_paid: 250,
        start_date: MIGRATION_DATE, expiry_date: '2026-12-31',
        granted_by: 'admin', reason: 'infra upgrade contribution, not a normal plan purchase',
    },
    '833692577324466186': { // 雨KAI
        type: 'complimentary', plan: 'legacy_supporter', amount_paid: 250,
        start_date: MIGRATION_DATE, expiry_date: '2026-12-31',
        granted_by: 'admin', reason: 'infra upgrade contribution, not a normal plan purchase',
    },
    '910460439694020658': { // Vercus
        type: 'complimentary', plan: 'legacy_supporter', amount_paid: 250,
        start_date: MIGRATION_DATE, expiry_date: '2026-12-31',
        granted_by: 'admin', reason: 'infra upgrade contribution, not a normal plan purchase',
    },
    '922734859112284190': { // Volkov Pava
        type: 'complimentary', plan: 'legacy_supporter', amount_paid: 250,
        start_date: MIGRATION_DATE, expiry_date: '2026-12-31',
        granted_by: 'admin', reason: 'infra upgrade contribution, not a normal plan purchase',
    },

    // Kendrick already paid ₱100 for a Monthly plan before the claims
    // pipeline existed — a normal PAID subscription, just backfilled by
    // hand. Expiry = start + 1 calendar month.
    '1018852133245833257': { // Kendrick
        type: 'paid', plan: 'monthly', amount_paid: 100,
        start_date: MIGRATION_DATE, expiry_date: addOneMonth(MIGRATION_DATE),
        granted_by: 'admin_backfill', reason: 'paid before the claims/payment pipeline existed',
    },

    // NOTE: 1254934253507055637 (Jyn_ari.x) is the OPERATOR's own
    // profile — deliberately NOT in this table. The operator doesn't
    // need a subscription record at all; see the operator bypass in
    // app/trigger/server.js and app/worker/worker.js (isOperatorProfile
    // short-circuits the subscription gate entirely), and set
    // AUTOBOOK_OPERATOR_PROFILE_IDS=1254934253507055637 in the real .env
    // so it's also excluded from the 7-slot capacity count.
};

function addOneMonth(isoDate) {
    const d = new Date(isoDate + 'T00:00:00Z');
    d.setUTCMonth(d.getUTCMonth() + 1);
    return d.toISOString().slice(0, 10);
}

// ---- migration logic (shouldn't need editing) -----------------------------

function profilePath(id) {
    return path.join(PROFILES_DIR, `${id}.yaml`);
}

function run() {
    const apply = process.argv.includes('--apply');
    const force = process.argv.includes('--force');

    console.log(`Backfill mode: ${apply ? 'APPLY (writing files)' : 'DRY RUN (no files touched — pass --apply to write)'}${force ? ' [force: will overwrite existing subscription blocks]' : ''}\n`);

    for (const [id, sub] of Object.entries(BACKFILL_TABLE)) {
        const file = profilePath(id);
        if (!fs.existsSync(file)) {
            console.log(`SKIP  ${id} — no profile YAML on disk (per spec: never create one on their behalf, they'll go through the normal claim flow if/when they return)`);
            continue;
        }

        const profile = yaml.load(fs.readFileSync(file, 'utf8')) || {};

        if (profile.subscription && !force) {
            console.log(`SKIP  ${id} (${profile.name || 'unnamed'}) — already has a subscription block. Re-run with --force to overwrite.`);
            continue;
        }

        const newSub = {
            type: sub.type,
            plan: sub.plan,
            status: 'active',
            amount_paid: sub.amount_paid,
            start_date: sub.start_date,
            expiry_date: sub.expiry_date,
            granted_by: sub.granted_by,
            reason: sub.reason,
            note: null,
        };

        console.log(`${apply ? 'WRITE' : 'WOULD WRITE'} ${id} (${profile.name || 'unnamed'}) -> ${JSON.stringify(newSub)}`);

        if (apply) {
            profile.subscription = newSub;
            fs.writeFileSync(file, yaml.dump(profile, { lineWidth: -1 }));
        }
    }

    const untouched = fs.readdirSync(PROFILES_DIR)
        .filter(f => f.endsWith('.yaml'))
        .map(f => f.replace(/\.yaml$/, ''))
        .filter(id => !(id in BACKFILL_TABLE));

    if (untouched.length > 0) {
        console.log(`\nProfiles NOT in the backfill table (left untouched — no subscription, normal claim flow applies): ${untouched.join(', ')}`);
    }

    if (!apply) {
        console.log('\nThis was a dry run. Re-run with --apply to actually write these subscription blocks.');
    }
}

run();
