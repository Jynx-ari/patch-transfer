#!/usr/bin/env node
/**
 * tools/dry_run_booking.js — Autobook dry-run harness.
 *
 * Drives the REAL feua.kliquep2p.com booking form using one profile's
 * real origin/dropoff/time and that profile's REAL saved signature (via
 * app/workflow/signature.js) — everything except the final "submit"
 * click, which this script deliberately never calls.
 *
 * Reuses existing project code rather than reinventing it:
 *   - app/queue/job.js          (loadProfile, validateProfile)
 *   - app/workflow/signature.js (applySignature — real signature replay)
 *
 * Usage:
 *   node tools/dry_run_booking.js <profileId> [--leg morning|afternoon] [--headed] [--date "August 31, 2026"]
 *
 * Examples:
 *   node tools/dry_run_booking.js profile1 --leg morning
 *   node tools/dry_run_booking.js profile3 --leg afternoon --date "August 31, 2026"
 *   node tools/dry_run_booking.js profile1          (roundtrip profile, no --leg: runs both legs)
 *
 * LOGIN — works headless, no display needed:
 * Reads the profile's own encrypted site login (profiles/<id>/credentials.enc,
 * saved via /credentials-set in Discord) and decrypts it with
 * AUTOBOOK_CREDENTIALS_KEY from autobook/.env — the same key the bot uses.
 * If a profile has no credentials saved yet, this fails with a clear
 * message telling them to run /credentials-set first.
 * Only pass --headed if you're on a machine with an actual display and
 * want to log in by hand instead / watch the run live.
 *
 * Requires Playwright + dotenv (devDependencies — see package.json):
 *   npm install
 *   npx playwright install chromium
 *   sudo npx playwright install-deps chromium   (Linux servers only — installs
 *                                                 system libs Chromium needs)
 *
 * IMPORTANT — SCOPE:
 * The live site has no combined "roundtrip" form — a roundtrip is just
 * the same one-way form, submitted twice: once for the morning leg, once
 * for the afternoon leg (confirmed against the real site). This script
 * mirrors that: for a roundtrip profile, if --leg isn't given, it runs
 * the morning leg through to the pre-submit screenshot, navigates back
 * to a fresh booking form, then runs the afternoon leg the same way —
 * two independent dry runs in one invocation, matching how a real
 * roundtrip booking would actually be made as two separate submissions.
 * Pass --leg morning or --leg afternoon to test just one.
 *
 * IMPORTANT — WHY THIS IS SAFE TO RUN ANYTIME:
 * The site visually disables not-yet-open calendar dates via the
 * `.flatpickr-disabled` class, but the seat/time data behind them is
 * already live server-side. This script swaps that class the same way
 * you did manually in the Elements panel, so it can pull real
 * departure-time/seat data and exercise the full form + signature flow
 * without waiting for the site to officially open a date. It still never
 * touches the final submit button, so no real booking is made.
 */

const path = require('path');
const fs = require('fs');
require('dotenv').config({ path: path.join(__dirname, '..', '.env'), quiet: true });
const { chromium } = require('playwright');
const fernet = require('fernet');
const { loadProfile, validateProfile, resolveDayBooking, DEFAULT_TIMEZONE } = require('../app/queue/job');
const { applySignature } = require('../app/workflow/signature');

const PROFILES_DIR = path.join(__dirname, '..', 'profiles');
// Mode-aware: real production submissions never get saved under a
// "dry-run" name (misleading — see
// FEU_AutoBook_Production_Booking_Fixes.md section 7).
const SCREENSHOTS_DIR = path.join(
    __dirname, '..',
    String(process.env.AUTOBOOK_MODE || 'test').toLowerCase() === 'production' ? 'booking-screenshots' : 'dry-run-screenshots'
);

/**
 * profiles/{id}/booking-screenshots/{date}/{leg}_{kind}_{timestamp}.png
 *
 * Nested UNDER the profile's own directory deliberately — /app/profiles
 * is already bind-mounted to the host (per
 * FEU_AutoBook_Production_Booking_Fixes.md section 6), so screenshots
 * get persistence "for free" without needing a NEW, separate bind mount
 * the way a flat top-level screenshots directory would have. Also keeps
 * everything for one profile in one place, and gives the admin panel a
 * natural place to look: profiles/{id}/booking-screenshots/.
 */
function buildScreenshotPath(profileId, date, leg, kind) {
    const dir = path.join(PROFILES_DIR, String(profileId), 'booking-screenshots', String(date || 'unknown-date'));
    fs.mkdirSync(dir, { recursive: true });
    return path.join(dir, `${leg}_${kind}_${Date.now()}.png`);
}
const LOGIN_URL = 'https://feua.kliquep2p.com';
const BOOKING_URL = 'https://feua.kliquep2p.com/client/booking-now';

// Confirms we're on the booking page already logged in (same selector the
// old prototype used, and it's proven to work — the calendar only renders
// once you're authenticated).
const LOGGED_IN_SELECTOR = '.flatpickr-day';

const LOGIN_SELECTORS = {
    signInButton: '.btn_signIn',
    emailInput: 'input[name="email1"]',
    passwordInput: 'input[name="password1"]',
    submitButton: 'button[type="submit"]',
};

/**
 * Decrypts a profile's own site login, saved via /credentials-set in
 * Discord (profiles/<id>/credentials.enc) and encrypted with the same
 * AUTOBOOK_CREDENTIALS_KEY the bot uses (Fernet — verified compatible
 * between Python's `cryptography` and this npm `fernet` package).
 * Returns null if nothing is saved for this profile.
 */
function loadDecryptedCredentials(profileId) {
    const credPath = path.join(PROFILES_DIR, String(profileId), 'credentials.enc');
    if (!fs.existsSync(credPath)) return null;

    const key = process.env.AUTOBOOK_CREDENTIALS_KEY;
    if (!key) {
        throw new Error('profiles/' + profileId + '/credentials.enc exists but AUTOBOOK_CREDENTIALS_KEY is not set in autobook/.env — cannot decrypt.');
    }

    const secret = new fernet.Secret(key);
    const tokenStr = fs.readFileSync(credPath, 'utf8').trim();
    const token = new fernet.Token({ secret, token: tokenStr, ttl: 0 }); // ttl:0 = no expiry check; this isn't a session token
    let decoded;
    try {
        decoded = token.decode();
    } catch (e) {
        throw new Error(`Failed to decrypt credentials for profile ${profileId} (wrong AUTOBOOK_CREDENTIALS_KEY, or the file is corrupt): ${e.message}`);
    }
    return JSON.parse(decoded);
}

// Real selectors, carried over from the old prototype's
// src/shared/config.js (captured from live page dumps) plus the Continue
// button markup you pasted, which matches `continueButton` below exactly.
const SELECTORS = {
    tripTypeOneWay: 'input[name="trip_type"][value="One-way"]',
    tripTypeRoundtrip: 'input[name="trip_type"][value="Roundtrip"]',
    origin: 'select#origin',
    // The site's own field is named "destination" in its HTML; we keep
    // calling it "dropoff" in our own code/logs per the spec's
    // origin/dropoff terminology (see autobook_spec_update_patch.md).
    dropoff: 'select#destination',
    vanName: 'select#van_name',
    departureTime: 'select#departuretime',
    pax: 'select#pax',
    availableSeats: 'input#avail_seat[name="avail_seat"]',
    departureDateInput: 'input#departure',
    flatpickrDay: '.flatpickr-day',
    flatpickrDayDisabled: '.flatpickr-disabled',
    // Shared "Continue" button — same one for every stepper step except
    // the final submit, per the HTML you pasted:
    //   <button type="button" class="btn btn-lg btn-primary next" data-kt-stepper-action="next">Continue
    continueButton: 'button.next[data-kt-stepper-action="next"]',
    // Deliberately NEVER clicked by this script.
    finalSubmitButton: 'button[type="submit"][data-kt-stepper-action="submit"]',
    agreementCheckbox: 'input#agreement',
    signatureCanvas: 'div#sig canvas',
    signatureHiddenField: 'textarea#signature64',
};

/**
 * Thrown when the route/date/van/time combination is legitimately fully
 * booked — NOT a bug, not a selector problem, just no seats. Kept as its
 * own error type (rather than a generic Error) so callers (worker.js)
 * can treat this as a clean, expected rejection instead of a booking
 * failure — see FEU_AutoBook_Production_Booking_Fixes.md section 1: the
 * old code failed hard on "No selectable options in pax" for exactly
 * this legitimate case.
 */
class FullyBookedError extends Error {
    constructor(message) {
        super(message);
        this.name = 'FullyBookedError';
    }
}

function parseArgs(argv) {
    const args = { profileId: argv[2], leg: null, headed: false, date: null };
    for (let i = 3; i < argv.length; i++) {
        if (argv[i] === '--leg') args.leg = argv[++i];
        else if (argv[i] === '--headed') args.headed = true;
        else if (argv[i] === '--date') args.date = argv[++i];
    }
    return args;
}

/** "17:00" -> "5:00 PM", to match the site's option text like "5:10 PM". */
function to12Hour(hhmm) {
    const [h, m] = String(hhmm).split(':').map(Number);
    const period = h >= 12 ? 'PM' : 'AM';
    const h12 = ((h + 11) % 12) + 1;
    return `${h12}:${String(m).padStart(2, '0')} ${period}`;
}

function timeToMinutes(text) {
    const m = String(text).match(/(\d+):(\d+)\s*(AM|PM)/i);
    if (!m) return null;
    let [, h, mi, ap] = m;
    h = parseInt(h, 10) % 12;
    if (/pm/i.test(ap)) h += 12;
    return h * 60 + parseInt(mi, 10);
}

/** Reads what every upstream field ACTUALLY currently shows, so a
 * timeout error can say definitively whether something silently reverted
 * upstream instead of us having to guess or ask for another screenshot. */
async function dumpFormState(page) {
    try {
        return await page.evaluate((sel) => {
            const selectVal = (s) => {
                const el = document.querySelector(s);
                if (!el) return '(field not found)';
                if (!el.value) return '(empty/placeholder)';
                const opt = el.options ? el.options[el.selectedIndex] : null;
                return opt ? opt.textContent.trim() : el.value;
            };
            const inputVal = (s) => {
                const el = document.querySelector(s);
                if (!el) return '(field not found)';
                return el.value || '(empty)';
            };
            return {
                origin: selectVal(sel.origin),
                dropoff: selectVal(sel.dropoff),
                date: inputVal(sel.departureDateInput),
                van: selectVal(sel.vanName),
                departureTime: selectVal(sel.departureTime),
                pax: selectVal(sel.pax),
                availableSeats: inputVal(sel.availableSeats),
            };
        }, SELECTORS);
    } catch {
        return null;
    }
}

async function waitForOptions(page, selector, { minOptions = 2, timeout = 10000, fieldName } = {}) {
    try {
        await page.waitForFunction(
            ({ sel, min }) => {
                const el = document.querySelector(sel);
                return el && el.options.length >= min;
            },
            { sel: selector, min: minOptions },
            { timeout }
        );
    } catch (err) {
        const currentCount = await page.$eval(selector, el => el.options.length).catch(() => 'unknown');
        const state = await dumpFormState(page);
        throw new Error(
            `Timed out waiting for "${fieldName || selector}" to populate — still only ${currentCount} option(s) ` +
            `after ${timeout}ms (needed ${minOptions}+).\n` +
            `  Live form state at time of failure: ${state ? JSON.stringify(state, null, 2) : '(could not read)'}`
        );
    }
}

/**
 * Selects an option by matching text (case-insensitive). If nothing
 * matches and `label` looks like a time field, falls back to the
 * closest available time and logs a warning instead of failing — this
 * is a dry run, so "closest offered slot" is still a useful signal.
 * With no `desiredText` at all, just takes the first real option
 * ("whatever comes first", per your note on van selection).
 */
async function selectOption(page, selector, desiredText, label) {
    const options = await page.$eval(selector, el =>
        Array.from(el.options).map(o => ({ value: o.value, text: o.textContent.trim() }))
    );
    const real = options.filter(o => o.value !== '');
    if (real.length === 0) throw new Error(`No selectable options in ${label} (${selector})`);

    let target = null;
    if (desiredText) {
        target = real.find(o => o.text.toLowerCase() === String(desiredText).toLowerCase());
        if (!target && /time/i.test(label)) {
            const wantMin = timeToMinutes(desiredText);
            if (wantMin !== null) {
                let best = null, bestDiff = Infinity;
                for (const o of real) {
                    const optMin = timeToMinutes(o.text);
                    if (optMin === null) continue;
                    const diff = Math.abs(optMin - wantMin);
                    if (diff < bestDiff) { best = o; bestDiff = diff; }
                }
                if (best) {
                    console.warn(`  \u26a0  "${desiredText}" not offered for ${label} — using closest available: "${best.text}"`);
                    target = best;
                }
            }
        }
        if (!target) {
            const available = real.map(o => o.text).join(', ');
            throw new Error(`"${desiredText}" not found in ${label}. Available: ${available}`);
        }
    } else {
        target = real[0];
    }

    await page.selectOption(selector, target.value);
    // Belt-and-suspenders: Playwright's selectOption already fires native
    // input/change events, but if this select is wrapped by a UI plugin
    // (chosen/select2-style) that only reacts to its own bound listeners,
    // explicitly re-dispatching bubbling events here costs nothing and
    // may be what a dependent field (like pax) is actually waiting on.
    await page.$eval(selector, el => {
        el.dispatchEvent(new Event('input', { bubbles: true }));
        el.dispatchEvent(new Event('change', { bubbles: true }));
    });

    // Verify the selection actually stuck. Some fields get silently reset
    // by a dependent AJAX call shortly after a related field changes
    // (e.g. dropoff getting wiped back to empty right after origin's own
    // change handler refreshes its option list) — the selectOption call
    // above succeeds, but the site quietly clears it a moment later. Wait
    // briefly, re-check, and select again once if it reverted.
    await page.waitForTimeout(500);
    let currentValue = await page.$eval(selector, el => el.value);
    if (currentValue !== target.value) {
        await page.selectOption(selector, target.value);
        await page.$eval(selector, el => {
            el.dispatchEvent(new Event('input', { bubbles: true }));
            el.dispatchEvent(new Event('change', { bubbles: true }));
        });
        await page.waitForTimeout(400);
        currentValue = await page.$eval(selector, el => el.value);
        if (currentValue !== target.value) {
            throw new Error(`${label} selection ("${target.text}") didn't stick even after retrying — the site appears to be resetting this field asynchronously.`);
        }
        console.log(`  (${label} selection was reset by the site and had to be reselected)`);
    }

    return target;
}

/**
 * Your discovered fix: the site's calendar visually disables not-yet-open
 * dates via `.flatpickr-disabled`, but the seat/time data behind them is
 * already live server-side. Swapping the class to `.flatpickr-enabled`
 * lets the real click event fire and pull real departure-time/seat data.
 *
 * Also replicates the click-twice behavior you observed: the first click
 * after force-enabling only fires the page's own
 * "Empty string passed to getElementById()" warning and doesn't finish
 * populating the dependent dropdowns; the second click is what actually
 * does it.
 */
async function forceEnableAndPickDate(page, ariaLabel) {
    await page.click(SELECTORS.departureDateInput);
    await page.waitForSelector(SELECTORS.flatpickrDay, { timeout: 5000 });

    const MAX_MONTH_ADVANCES = 6; // covers ~6 months ahead, plenty for near-term testing
    let resolvedLabel = null;

    for (let attempt = 0; attempt <= MAX_MONTH_ADVANCES; attempt++) {
        // Everything — finding the right day, force-enabling it, AND
        // clicking it (twice, matching the manual quirk you found) —
        // happens inside ONE evaluate call. Doing the click as a separate
        // outer Playwright action left a gap where the site's own
        // re-render could wipe out whatever we'd just tagged/modified, so
        // the follow-up click silently found zero matching elements.
        // Calling day.click() directly in-page (same trick as the
        // trip-type radio fix) also sidesteps Playwright's
        // visibility/actionability checks entirely, which is what we want
        // here since the day only becomes "real" the instant we
        // un-disable it.
        resolvedLabel = await page.evaluate(async ({ wantedLabel }) => {
            const today = new Date();
            today.setHours(0, 0, 0, 0);

            // Parse the WANTED date once, up front, and compare by actual
            // calendar date (year/month/day) rather than exact string
            // equality against the site's own aria-label text. The two
            // sides format dates independently (e.g. a trigger sending
            // "September 02, 2026" vs. flatpickr's own aria-label being
            // "September 2, 2026" — no leading zero) and a raw string
            // compare silently fails on every single day, even the
            // correct one, exhausting all month-navigation attempts
            // before giving up with a misleading "date not found" error.
            let wantedDate = null;
            if (wantedLabel) {
                wantedDate = new Date(wantedLabel);
                if (isNaN(wantedDate.getTime())) {
                    throw new Error(`Couldn't parse the requested date "${wantedLabel}" as a real date.`);
                }
                wantedDate.setHours(0, 0, 0, 0);
            }

            const isVisible = (el) => {
                if (!el.isConnected || el.getClientRects().length === 0) return false;
                const style = window.getComputedStyle(el);
                return style.visibility !== 'hidden' && style.display !== 'none';
            };

            const days = Array.from(document.querySelectorAll('.flatpickr-day'));
            let target = null;
            for (const day of days) {
                if (day.classList.contains('prevMonthDay') || day.classList.contains('nextMonthDay')) continue;
                if (!isVisible(day)) continue;
                const al = day.getAttribute('aria-label');
                if (!al) continue;
                const d = new Date(al);
                if (isNaN(d.getTime())) continue;
                d.setHours(0, 0, 0, 0);
                if (d < today) continue; // never touch past days
                if (wantedDate && d.getTime() !== wantedDate.getTime()) continue;

                day.classList.remove('flatpickr-disabled');
                day.classList.add('flatpickr-enabled');
                target = day;
                break;
            }
            if (!target) return null;

            target.click();
            await new Promise(r => setTimeout(r, 300));
            target.click(); // second click — matches the manual quirk you found

            return target.getAttribute('aria-label');
        }, { wantedLabel: ariaLabel || null });

        if (resolvedLabel) break;
        if (!ariaLabel) break; // "any upcoming day" mode never needs month navigation — the open month always has one (except literally Dec 31)

        // Specific date not found in the currently open month — it may
        // just be next month or later. Click the calendar's own
        // "next month" arrow (same click-via-JS approach, for consistency)
        // and try again in the newly rendered month.
        const hasNextArrow = await page.$('.flatpickr-next-month');
        if (!hasNextArrow) break; // nothing left to navigate to — give up
        await page.evaluate(() => document.querySelector('.flatpickr-next-month')?.click());
        await page.waitForTimeout(400); // let flatpickr re-render the new month's days
    }

    if (!resolvedLabel) {
        throw new Error(ariaLabel
            ? `Date "${ariaLabel}" wasn't found as a visible, upcoming day on the calendar (checked up to ${MAX_MONTH_ADVANCES} months ahead).`
            : 'No visible, upcoming (today-or-later) date found on the calendar to pick.');
    }
    return resolvedLabel;
}

/**
 * The trip-type radios are Bootstrap `.btn-check` inputs — visually
 * hidden, with a styled <label> covering them. A normal coordinate-based
 * page.click() keeps hitting the label (or the sticky header while
 * scrolling into view) and times out. Clicking via JS bypasses the
 * visibility/overlap check entirely — same fix the old prototype used —
 * then this confirms the radio actually ended up checked.
 */
async function clickRadioViaJs(page, selector, label) {
    await page.waitForSelector(selector, { state: 'attached', timeout: 15000 });
    await page.$eval(selector, el => el.click());
    const checked = await page.$eval(selector, el => el.checked);
    if (!checked) {
        throw new Error(`${label} radio did not register as checked (selector: ${selector})`);
    }
}

/**
 * The site uses SweetAlert2 for validation/info popups (.swal2-container).
 * If one is already open, clicking Continue would just time out silently
 * behind it — this reads the popup's actual title/message first so the
 * real reason surfaces immediately instead of a bare 30s timeout.
 */
async function clickContinueOrSurfacePopup(page) {
    const popup = await page.$('.swal2-popup');
    if (popup) {
        const text = await page.evaluate(() => {
            const title = document.querySelector('.swal2-title')?.textContent?.trim() || '';
            const html = document.querySelector('.swal2-html-container')?.textContent?.trim() || '';
            return [title, html].filter(Boolean).join(' — ');
        });
        throw new Error(`Site showed a popup instead of advancing: "${text || '(empty popup)'}"`);
    }
    await page.click(SELECTORS.continueButton);
}

/**
 * Runs one leg (morning or afternoon) as an independent one-way run
 * against a fresh booking form.
 * @param {'dry-run'|'submit'} mode - 'dry-run' (default) behaves exactly
 *   as before: never clicks submit. 'submit' is used ONLY by
 *   app/worker/worker.js (AUTOBOOK_MODE=production) and actually clicks the final submit
 *   button — see the safety notes there before ever passing this.
 * Throws on failure before the submit click — caller decides what to do
 * with a failed leg (e.g. still attempt the other one). Once submit is
 * actually clicked in 'submit' mode, this function does NOT retry or
 * throw on an uncertain confirmation — it reports what it saw and lets
 * the caller decide, since retrying a click that may have already gone
 * through risks a duplicate real booking.
 */
async function runLeg(page, profile, leg, legConfig, args, mode = 'dry-run') {
    console.log(`\n=== DRY RUN: profile "${profile.id}" — ${leg} leg ===`);
    console.log(`Origin:   ${legConfig.origin}`);
    console.log(`Dropoff:  ${legConfig.dropoff}`);
    console.log(`Time:     ${legConfig.time}\n`);

    await page.goto(BOOKING_URL, { waitUntil: 'networkidle' });
    await page.waitForSelector(SELECTORS.origin, { timeout: 15000 });
    await clickRadioViaJs(page, SELECTORS.tripTypeOneWay, 'trip type');

    await waitForOptions(page, SELECTORS.origin, { fieldName: 'origin' });
    const origin = await selectOption(page, SELECTORS.origin, legConfig.origin, 'origin');
    await page.waitForTimeout(500); // let origin's likely dropoff-repopulation AJAX settle before we touch dropoff

    await waitForOptions(page, SELECTORS.dropoff, { fieldName: 'dropoff' });
    const dropoff = await selectOption(page, SELECTORS.dropoff, legConfig.dropoff, 'dropoff');

    const pickedDate = await forceEnableAndPickDate(page, args.date || null);
    console.log(`Date:            ${pickedDate}`);

    await waitForOptions(page, SELECTORS.vanName, { fieldName: 'van' });
    const van = await selectOption(page, SELECTORS.vanName, null, 'van'); // "whatever comes first"

    await waitForOptions(page, SELECTORS.departureTime, { fieldName: 'departure time' });
    const desiredTime = to12Hour(legConfig.time);
    const departureTime = await selectOption(page, SELECTORS.departureTime, desiredTime, 'departure time');

    // Pax always has exactly ONE option whether loaded or not — even
    // "FULLY BOOKED" is still a single option with an empty value — so
    // option-count can never signal "loaded" here (that was the bug).
    // Wait for the option TEXT to move off the "Please Select" placeholder
    // instead — this just tells us the dependent fields have finished
    // updating after the van/time selection; it is NOT "waiting for a
    // pax value to pick", since pax is never actively selected below
    // (see FEU_AutoBook_Production_Booking_Fixes.md section 1 — the site
    // controls/defaults this field itself, normally to "1", and treating
    // it as something AutoBook must select was the actual bug behind
    // "No selectable options in pax" rejecting legitimate bookings).
    await page.waitForFunction(
        (sel) => {
            const el = document.querySelector(sel);
            if (!el || el.options.length === 0) return false;
            const text = el.options[0].textContent.trim().toLowerCase();
            return text !== '' && text !== 'please select';
        },
        SELECTORS.pax,
        { timeout: 20000 }
    ).catch(async () => {
        const state = await dumpFormState(page);
        throw new Error(`Pax field never moved off "Please Select" after 20s — the page may not have finished updating after the time selection.\n  Live form state: ${state ? JSON.stringify(state, null, 2) : '(could not read)'}`);
    });

    const paxText = await page.$eval(SELECTORS.pax, el => el.options[0]?.textContent.trim() || '').catch(() => '');
    console.log(`Pax field reports: ${paxText || '(empty)'}`);

    // Available Seats is the PRIMARY availability signal — wait for it to
    // actually populate before trusting it. A short timeout here is
    // deliberate: pax has already confirmed the dependent fields updated,
    // so this is just giving the seats field a moment to catch up, not a
    // fresh wait from zero. If it never populates, we do NOT treat that
    // as "fully booked" (an empty/loading value proves nothing either
    // way) — we fall back to the pax-text check alone and proceed.
    await page.waitForFunction(
        (sel) => {
            const el = document.querySelector(sel);
            return el && el.value !== '' && el.value !== null;
        },
        SELECTORS.availableSeats,
        { timeout: 8000 }
    ).catch(() => { /* handled by the null check below — not fatal */ });

    const availableSeatsRaw = await page.$eval(SELECTORS.availableSeats, el => el.value).catch(() => null);
    const availableSeats = availableSeatsRaw !== null && availableSeatsRaw !== '' ? Number(availableSeatsRaw) : null;
    console.log(`Available seats: ${availableSeats !== null ? availableSeats : '(could not read — proceeding on pax text alone)'}`);

    const paxSaysFullyBooked = /fully booked/i.test(paxText);
    const seatsSayFullyBooked = availableSeats !== null && !Number.isNaN(availableSeats) && availableSeats === 0;

    if (paxSaysFullyBooked || seatsSayFullyBooked) {
        const evidenceShot = buildScreenshotPath(profile.id, pickedDate, leg, 'fully-booked');
        await page.screenshot({ path: evidenceShot }).catch(() => {});
        throw new FullyBookedError(
            `${legConfig.origin} -> ${legConfig.dropoff} at ${legConfig.time} is fully booked ` +
            `(pax: "${paxText}", available seats: ${availableSeats !== null ? availableSeats : 'unknown'}). Screenshot: ${evidenceShot}`
        );
    }

    // Deliberately NOT selecting a pax value — the site defaults/controls
    // this field itself (normally to "1"). AutoBook must never actively
    // select it; doing so was the root cause of legitimate bookings being
    // rejected. See section 1 of the production booking-fixes doc.

    await page.screenshot({ path: buildScreenshotPath(profile.id, pickedDate, leg, 'step1') });

    // Advance: step 1 (form) -> step 2 (payment summary review, nothing
    // to fill) -> step 3 (terms + signature). Same shared button both
    // times, per the site's stepper design.
    await clickContinueOrSurfacePopup(page);
    await page.waitForTimeout(500);
    await clickContinueOrSurfacePopup(page);
    await page.waitForTimeout(500);

    const sigResult = await applySignature(page, profile.id, SELECTORS);

    const screenshotPath = buildScreenshotPath(profile.id, pickedDate, leg, 'pre-submit');
    await page.screenshot({ path: screenshotPath, fullPage: true });

    const submitButton = await page.$(SELECTORS.finalSubmitButton);

    if (mode === 'submit') {
        if (!submitButton) {
            throw new Error(`Submit button not found for ${leg} leg — selectors may be stale. Refusing to guess; nothing was submitted.`);
        }

        console.log(`\n>>> SUBMIT MODE: clicking final submit for profile "${profile.id}" — ${leg} leg <<<`);

        // Same JS-click pattern as the trip-type radios above — this
        // site's Bootstrap-styled buttons have proven unreliable with
        // coordinate-based page.click().
        await page.$eval(SELECTORS.finalSubmitButton, el => el.click());

        // Confirmed against the real site (see profile owner's report):
        // after Discord thread mentioned a captured redirect —
        // successful submission redirects to
        //   https://feua.kliquep2p.com/client/success/<booking-ref-token>
        // That's a far stronger, site-specific signal than the earlier
        // generic "URL moved off booking-now OR a swal2 popup sounds
        // successful" guess, so it's now the primary confirmation check.
        // The swal2-popup race is kept as a fallback ONLY for the
        // unconfirmed case where the redirect doesn't happen (e.g. the
        // site changes this flow later, or an error popup appears
        // instead) — no retry of the click itself under any outcome here,
        // since a duplicate click on an already-processed submission
        // risks a duplicate real booking, which is worse than a booking
        // that needs a human to glance at the screenshot.
        const SUCCESS_URL_PATTERN = /\/client\/success\/([A-Za-z0-9]+)/;
        let confirmed = false;
        let confirmationNote = '(no confirmation signal seen within 15s)';
        let bookingRef = null;
        try {
            await Promise.race([
                page.waitForURL(url => SUCCESS_URL_PATTERN.test(url.pathname), { timeout: 15000 })
                    .then(() => {
                        confirmed = true;
                        bookingRef = SUCCESS_URL_PATTERN.exec(page.url())?.[1] || null;
                        confirmationNote = `Redirected to /client/success/ — booking ref ${bookingRef}`;
                    }),
                page.waitForSelector('.swal2-popup', { timeout: 15000 }).then(async () => {
                    const text = await page.evaluate(() => {
                        const title = document.querySelector('.swal2-title')?.textContent?.trim() || '';
                        const html = document.querySelector('.swal2-html-container')?.textContent?.trim() || '';
                        return [title, html].filter(Boolean).join(' — ');
                    });
                    confirmed = /success|confirm|booked|thank/i.test(text);
                    confirmationNote = `Popup shown (no success redirect seen): "${text || '(empty)'}"`;
                }),
            ]);
        } catch (e) {
            confirmationNote = `(error while watching for confirmation: ${e.message})`;
        }

        // Give the success page's own content (booking summary / invoice
        // details) a moment to finish rendering before capturing it —
        // this is the actual invoice view now, not a guessed-at link.
        if (confirmed && bookingRef) {
            await page.waitForLoadState('networkidle', { timeout: 8000 }).catch(() => {});
        }

        const postSubmitScreenshot = buildScreenshotPath(profile.id, pickedDate, leg, bookingRef ? 'success' : (confirmed ? 'success' : 'needs-manual-check'));
        await page.screenshot({ path: postSubmitScreenshot, fullPage: true }).catch(() => {});

        console.log(`Submit clicked:  yes`);
        console.log(`Confirmation:    ${confirmed ? 'looks successful' : 'UNCERTAIN — check screenshot manually'} — ${confirmationNote}`);
        console.log(`Booking ref:     ${bookingRef || '(none captured)'}`);
        console.log(`Screenshot:      ${postSubmitScreenshot}`);

        return {
            leg,
            submitted: true,
            confirmed,
            confirmationNote,
            bookingRef,
            successUrl: confirmed && bookingRef ? page.url() : null,
            screenshot: postSubmitScreenshot,
            origin: origin.text,
            dropoff: dropoff.text,
            date: pickedDate,
            van: van.text,
            departureTime: departureTime.text,
            signatureVariant: sigResult.signatureVariant,
        };
    }

    console.log(`\n--- ${leg} leg dry run complete — nothing was submitted ---`);
    console.log(`Origin:          ${origin.text}`);
    console.log(`Dropoff:         ${dropoff.text}`);
    console.log(`Van:             ${van.text}`);
    console.log(`Departure time:  ${departureTime.text}`);
    console.log(`Signature:       variant ${sigResult.signatureVariant}`);
    console.log(`Submit button:   ${submitButton ? 'found on page (never clicked)' : 'NOT FOUND — selectors may be stale, check manually'}`);
    console.log(`Screenshot:      ${screenshotPath}`);

    return {
        leg,
        submitted: false,
        dryRun: true,
        screenshot: screenshotPath,
        origin: origin.text,
        dropoff: dropoff.text,
        date: pickedDate,
        van: van.text,
        departureTime: departureTime.text,
        signatureVariant: sigResult.signatureVariant,
    };
}

/**
 * Logs in without needing a visible browser, using the PROFILE's OWN
 * credentials (saved via /credentials-set in Discord, decrypted with
 * AUTOBOOK_CREDENTIALS_KEY) — never a shared/global login. This is what
 * makes the dry run usable on a headless server with no X display:
 * --headed is only needed as a fallback if the profile has no saved
 * credentials yet and you genuinely have a screen to log in on manually.
 */
async function ensureLoggedIn(context, page, profileId, args) {
    await page.goto(BOOKING_URL, { waitUntil: 'networkidle' });
    if (await page.$(LOGGED_IN_SELECTOR)) return;

    const creds = loadDecryptedCredentials(profileId); // throws on bad key/corrupt file

    if (creds) {
        console.log(`Logging in as ${creds.email}...`);
        await page.goto(LOGIN_URL, { waitUntil: 'networkidle' });
        await page.waitForSelector(LOGIN_SELECTORS.signInButton, { timeout: 10000 });
        await page.click(LOGIN_SELECTORS.signInButton);
        await page.fill(LOGIN_SELECTORS.emailInput, creds.email);
        await page.fill(LOGIN_SELECTORS.passwordInput, creds.password);
        await Promise.all([
            page.waitForNavigation({ waitUntil: 'networkidle' }).catch(() => {}),
            page.click(LOGIN_SELECTORS.submitButton),
        ]);
        await page.goto(BOOKING_URL, { waitUntil: 'networkidle' });
    } else if (args.headed) {
        console.log(`No credentials saved for profile ${profileId} (run /credentials-set in Discord first). `
            + 'Since this is --headed, log in manually in the window instead, then press Enter here to continue...');
        await new Promise(resolve => process.stdin.once('data', resolve));
        await page.goto(BOOKING_URL, { waitUntil: 'networkidle' });
    } else {
        throw new Error(
            `No credentials saved for profile ${profileId}. Have them run /credentials-set in Discord ` +
            `(accepts the consent prompt, then enters their feua.kliquep2p.com login in the private form). ` +
            `On a machine with a real display, you can also rerun with --headed and log in manually instead.`
        );
    }

    if (!(await page.$(LOGGED_IN_SELECTOR))) {
        throw new Error('Login attempted but the booking calendar still isn\'t showing — credentials may be wrong, or the site changed its login flow.');
    }
    console.log('Logged in.\n');
}

async function run() {
    const args = parseArgs(process.argv);
    if (!args.profileId) {
        console.error('Usage: node tools/dry_run_booking.js <profileId> [--leg morning|afternoon] [--headed] [--date "August 31, 2026"]');
        process.exit(1);
    }

    const profile = loadProfile(args.profileId, PROFILES_DIR);
    if (!profile) {
        console.error(`Profile "${args.profileId}" not found in ${PROFILES_DIR}`);
        process.exit(1);
    }

    // Per-weekday profiles (monday/wednesday/thursday — see bot.py) need
    // an actual date to know which day's config applies; default to
    // "today" resolved in Philippine time (not the host's ambient TZ) if
    // --date wasn't passed, so this still works untouched for the older
    // flat-schema profiles that don't care what day it is.
    const testDate = args.date || new Date().toLocaleDateString('en-US', {
        timeZone: DEFAULT_TIMEZONE, month: 'long', day: 'numeric', year: 'numeric',
    });

    const validationErrors = validateProfile(profile, testDate);
    if (validationErrors.length > 0) {
        console.error(`Profile failed validation for ${testDate}:`);
        validationErrors.forEach(e => console.error(`  - ${e}`));
        process.exit(1);
    }

    const resolvedBooking = resolveDayBooking(profile, testDate);
    const mode = resolvedBooking.mode;
    if (resolvedBooking.weekday) {
        console.log(`Date:            ${testDate} (${resolvedBooking.weekday}, resolved in ${DEFAULT_TIMEZONE})`);
    }
    // Which legs to run: explicit --leg wins; otherwise a roundtrip
    // profile runs BOTH legs (two independent one-way submissions,
    // matching how the real site actually handles roundtrips), and a
    // morning/afternoon profile just runs its one leg.
    const legsToRun = args.leg ? [args.leg] : (mode === 'roundtrip' ? ['morning', 'afternoon'] : [mode]);

    for (const leg of legsToRun) {
        if (!resolvedBooking[leg]) {
            console.error(`Profile mode is "${mode}" — no "${leg}" leg to test.`);
            process.exit(1);
        }
    }

    if (legsToRun.length > 1) {
        console.log(`Roundtrip profile — running both legs as two separate one-way dry runs: ${legsToRun.join(' then ')}.`);
    }

    fs.mkdirSync(SCREENSHOTS_DIR, { recursive: true });

    const browser = await chromium.launch({ headless: !args.headed });
    const context = await browser.newContext();
    const page = await context.newPage();

    await ensureLoggedIn(context, page, profile.id, args);

    const results = [];
    try {
        for (const leg of legsToRun) {
            const legConfig = resolvedBooking[leg];
            try {
                await runLeg(page, profile, leg, legConfig, args);
                results.push({ leg, ok: true });
            } catch (err) {
                const failPath = path.join(SCREENSHOTS_DIR, `${profile.id}-${leg}-FAILED.png`);
                await page.screenshot({ path: failPath }).catch(() => {});
                console.error(`\n\u274c ${leg} leg failed: ${err.message}`);
                console.error(`Screenshot at point of failure: ${failPath}`);
                results.push({ leg, ok: false, error: err.message });
                // Keep going to the next leg (if any) rather than aborting
                // the whole roundtrip dry run over one leg's failure.
            }
        }

        console.log(`\n=== SUMMARY ===`);
        for (const r of results) {
            console.log(`  ${r.ok ? '\u2705' : '\u274c'} ${r.leg}${r.ok ? '' : `: ${r.error}`}`);
        }
        process.exitCode = results.some(r => !r.ok) ? 1 : 0;

        if (args.headed) {
            console.log('\nBrowser stays open for manual review. Close the window or Ctrl+C here when done.');
            await new Promise(() => {});
        }
    } finally {
        if (!args.headed) await browser.close();
    }
}

if (require.main === module) {
    run();
}

module.exports = {
    SELECTORS,
    PROFILES_DIR,
    SCREENSHOTS_DIR,
    ensureLoggedIn,
    runLeg,
    loadDecryptedCredentials,
    FullyBookedError,
    buildScreenshotPath,
};