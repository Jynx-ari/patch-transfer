#!/usr/bin/env python3
"""
Autobook Discord bot — the "place for me and my friends" to enter booking
config (origin, dropoff, times, mode) and, as of the /credentials-set
command below, their own feua.kliquep2p.com login — collected only after
an explicit consent step, encrypted at rest, never logged or echoed back.
This is a deliberate exception to the bot's original "config only, never
credentials" design — see /credentials-set's own docstring for the
consent flow and encryption details.

Each Discord user gets one profile, stored at profiles/<discord_id>.yaml,
matching the schema in the Autobook spec (section 5/29). No cap on the
number of profiles — anyone can create one.

Commands (all slash commands):
    /booking-set morning origin:<choice> time:<6:00 | 7:00>
    /booking-set afternoon dropoff:<choice> time:<4:10 | 5:10>
    /booking-set roundtrip morning_origin:<choice> morning_time:<6:00 | 7:00> afternoon_dropoff:<choice> afternoon_time:<4:10 | 5:10>
    /booking-view
    /booking-status active|inactive   (pause/resume without deleting your config)
    /booking-delete
    /requirements             (checklist of what's still needed before Autobook will book for you)
    /signature-link          (one-time web link, draws + saves directly)
    /signature-list
    /signature-delete slot:<1-3>
    /credentials-set          (checks consent reactions -> private modal for email/password)
    /credentials-status       (shows whether creds are on file, never their values)
    /credentials-clear
    /consent-post             (admin-only, one-time: posts the 3 consent messages to react to)

Setup:
    pip install discord.py pyyaml cryptography
    export AUTOBOOK_DISCORD_TOKEN="your-bot-token"
    export AUTOBOOK_TEST_GUILD_ID="your-server-id"   # optional, for instant sync while testing
    export AUTOBOOK_CREDENTIALS_KEY="..."            # required for /credentials-set — see .env.example
    python bot.py

The bot token is read only from the AUTOBOOK_DISCORD_TOKEN env var —
never hardcode it, never log it.

AUTOBOOK_TEST_GUILD_ID is optional. If set, slash commands sync instantly
to that one Discord server (right-click server icon > Copy Server ID,
with Developer Mode on) instead of the normal global sync, which can take
up to ~1hr to show up everywhere. Unset it once you're ready to go live
on all servers the bot is in.
"""

import json
import os
import re
import secrets
import sys
import time
from pathlib import Path

import discord
from discord import app_commands
import yaml

try:
    from cryptography.fernet import Fernet, InvalidToken
except ImportError:
    Fernet = None
    InvalidToken = Exception

DOTENV_PATH = Path(__file__).resolve().parent.parent / ".env"
try:
    from dotenv import load_dotenv
    _dotenv_loaded = load_dotenv(DOTENV_PATH)
    if not _dotenv_loaded:
        print(f"WARNING: no .env file found at {DOTENV_PATH} — only vars already "
              f"exported in the shell/systemd environment will be seen.", file=sys.stderr)
except ImportError:
    print("WARNING: python-dotenv isn't installed (pip install python-dotenv --break-system-packages) "
          "— .env file will be ignored; only vars already exported in the shell/systemd environment "
          "will be seen.", file=sys.stderr)

TIME_RE = re.compile(r"^([01]\d|2[0-3]):[0-5]\d$")  # strict 24h HH:MM, e.g. 07:30, 17:00

# Per-day config. Monday's afternoon time is different from Wed/Thu's
# (uncertain, prepared in advance — see AFTERNOON_TIME_CHOICES_BY_DAY);
# morning is the same across all three days. `name` is what's shown in
# Discord (12h, no leading zero). `value` is what actually gets stored
# in the profile YAML and, from there, is what dry_run_booking.js's
# to12Hour() converts to match the site's dropdown option text — that
# conversion REQUIRES strict 24h "HH:MM", so the value side must stay in
# that exact format even though the label doesn't.
DAY_KEYS = ["monday", "wednesday", "thursday"]
DAY_LABELS = {"monday": "Monday", "wednesday": "Wednesday", "thursday": "Thursday"}

MORNING_TIME_CHOICES_BY_DAY = {
    "monday": [("6:00", "06:00"), ("7:00", "07:00")],
    "wednesday": [("6:00", "06:00"), ("7:00", "07:00")],
    "thursday": [("6:00", "06:00"), ("7:00", "07:00")],
}
AFTERNOON_TIME_CHOICES_BY_DAY = {
    "monday": [("3:15", "15:15"), ("4:15", "16:15")],   # unconfirmed — easy to change, see note above
    "wednesday": [("4:10", "16:10"), ("5:10", "17:10")],
    "thursday": [("4:10", "16:10"), ("5:10", "17:10")],
}
MODE_CHOICES = [("Roundtrip", "roundtrip"), ("Morning only", "morning"), ("Afternoon only", "afternoon")]

PROFILES_DIR = Path(__file__).resolve().parent.parent / "profiles"
PROFILES_DIR.mkdir(exist_ok=True)
# No profile-count cap — anyone can create a profile now (see
# _check_profile_slot(), kept as a no-op for the one call site).

FEU_ALABANG = "FEU Alabang"
OTHER_STOPS = [
    "Vista Mall SOMO",
    "Puregold Pacita Complex San Pedro",
    "SM City BF Parañaque",
]

MAX_SIGNATURES_PER_PROFILE = 3

# Public HTTPS URL for app/webserver/signature_server.js, e.g.
# https://sign.yourdomain.com — set once you've got a reverse proxy with
# TLS pointed at that container. Left unset, /signature-link (the only
# way to add a signature — /signature-add was removed) is disabled.
SIGNATURE_BASE_URL = os.environ.get("AUTOBOOK_SIGNATURE_BASE_URL", "").rstrip("/")

# Token files are the hand-off point with app/webserver/signature_server.js
# (a separate Node process/container). Both sides just need to agree on
# this directory + JSON shape — see readToken()/tokenPath() there. Writing
# the token directly here (instead of shelling out to `node ... issue-token`)
# means the bot has zero dependency on Node being installed wherever bot.py
# happens to run.
SIGNATURE_TOKENS_DIR = PROFILES_DIR / "_signature_tokens"
SIGNATURE_TOKENS_DIR.mkdir(parents=True, exist_ok=True)
SIGNATURE_TOKEN_TTL_MS = int(os.environ.get("AUTOBOOK_SIGNATURE_TOKEN_TTL_MIN", "15")) * 60_000


def issue_signature_token(discord_id: int) -> str:
    """Mints a session token for the signature capture page. Must match
    the shape signature_server.js's readToken() expects: a 32-hex-char
    filename, JSON body {discordId, expiresAt (ms epoch)}. We don't set a
    currentSub field here — signature_server.js's handleGetCapture()
    always mints/overwrites one itself on first page load (and rotates it
    on every save after that), so it doesn't matter that Python-minted
    tokens start without one."""
    token = secrets.token_hex(16)  # 32 hex chars, matches signature_server.js's tokenPath() regex
    record = {"discordId": str(discord_id), "expiresAt": int(time.time() * 1000) + SIGNATURE_TOKEN_TTL_MS}
    (SIGNATURE_TOKENS_DIR / f"{token}.json").write_text(json.dumps(record))
    return token


# --- Credentials (site login) ---------------------------------------------
# Deliberate, explicit exception to this bot's original "never touches
# credentials" boundary — added at the user's request. Kept as safe as
# reasonably possible within Discord's constraints:
#   - Collected via a private Modal, never as visible slash-command args
#     (command args show up as plain text in the channel before the bot
#     even responds; modal contents don't).
#   - Gated behind an explicit consent step (three required checks) whose
#     acceptance (with version numbers + timestamp) is recorded alongside
#     the encrypted credentials.
#   - Encrypted at rest with Fernet (AES128-CBC + HMAC-SHA256) using a key
#     that lives only in .env, never in this repo or in logs.
#   - Never echoed back in any bot reply, including error messages.
TERMS_VERSION = "2.0"
PRIVACY_VERSION = "1.0"

# --- Consent gate (replaces the old in-command checkbox dropdown) ---------
# Instead of a ConsentView shown inline in /credentials-set, consent is now
# proven by reacting with CONSENT_EMOJI to three specific, pre-posted
# messages (Privacy Notice, Terms & Conditions, Transparency) that Stella
# posts once via /consent-post. Checked LIVE against the Discord API at the
# moment it matters (when /credentials-set is run, and as a nudge at the
# end of each /booking-set walkthrough step) — deliberately NOT a
# background poll/timer, since nothing here needs to be checked when
# nobody's actively going through the flow.
CONSENT_EMOJI = "✅"
CONSENT_CHANNELS = {
    "privacy": {
        "label": "Privacy Notice",
        "channel_id": int(os.environ.get("AUTOBOOK_PRIVACY_CHANNEL_ID") or 0),
        "message_id": int(os.environ.get("AUTOBOOK_PRIVACY_MESSAGE_ID") or 0),
    },
    "terms": {
        "label": "Terms & Conditions",
        "channel_id": int(os.environ.get("AUTOBOOK_TERMS_CHANNEL_ID") or 0),
        "message_id": int(os.environ.get("AUTOBOOK_TERMS_MESSAGE_ID") or 0),
    },
    "transparency": {
        "label": "Transparency",
        "channel_id": int(os.environ.get("AUTOBOOK_TRANSPARENCY_CHANNEL_ID") or 0),
        "message_id": int(os.environ.get("AUTOBOOK_TRANSPARENCY_MESSAGE_ID") or 0),
    },
}


def consent_configured() -> bool:
    """True once every channel has both a channel_id AND a message_id set.
    message_id starts empty until /consent-post has actually posted (or
    someone has manually pasted an existing message's ID into .env)."""
    return all(c["channel_id"] and c["message_id"] for c in CONSENT_CHANNELS.values())


async def get_missing_consents(user_id: int) -> list[tuple[str, dict]]:
    """Fetches each of the 3 pinned messages fresh from Discord right now
    and returns the (key, config) pairs the user has NOT reacted
    CONSENT_EMOJI to yet. No caching — this is meant to be called at the
    exact moments consent matters, not on any kind of interval."""
    missing = []
    for key, cfg in CONSENT_CHANNELS.items():
        channel = client.get_channel(cfg["channel_id"]) or await client.fetch_channel(cfg["channel_id"])
        message = await channel.fetch_message(cfg["message_id"])
        reacted = False
        for reaction in message.reactions:
            if str(reaction.emoji) != CONSENT_EMOJI:
                continue
            async for reactor in reaction.users():
                if reactor.id == user_id:
                    reacted = True
                    break
            if reacted:
                break
        if not reacted:
            missing.append((key, cfg))
    return missing


def consent_message_link(guild_id: int, cfg: dict) -> str:
    return f"https://discord.com/channels/{guild_id}/{cfg['channel_id']}/{cfg['message_id']}"


async def consent_nudge_suffix(user_id: int) -> str:
    """Optional one-line reminder appended to /booking-set walkthrough
    confirmations. Silently returns "" if consent gating isn't configured
    or the live check fails for any reason — this is a nudge, not a gate,
    so it must never block or break the booking-set flow itself."""
    if not consent_configured():
        return ""
    try:
        missing = await get_missing_consents(user_id)
    except discord.HTTPException:
        return ""
    if not missing:
        return ""
    names = ", ".join(cfg["label"] for _, cfg in missing)
    return f"\n\n⚠️ Heads up: you still need to react {CONSENT_EMOJI} to **{names}** before `/credentials-set` will work."


_CREDENTIALS_KEY = os.environ.get("AUTOBOOK_CREDENTIALS_KEY", "")
_fernet = None
if Fernet and _CREDENTIALS_KEY:
    try:
        _fernet = Fernet(_CREDENTIALS_KEY.encode())
    except Exception as e:
        print(f"WARNING: AUTOBOOK_CREDENTIALS_KEY is set but invalid ({e}) — "
              f"/credentials-set will be disabled until it's fixed.", file=sys.stderr)


def credentials_path(discord_id: int) -> Path:
    d = PROFILES_DIR / str(discord_id)
    d.mkdir(parents=True, exist_ok=True)
    return d / "credentials.enc"


def save_credentials(discord_id: int, email: str, password: str) -> None:
    """Encrypts and writes {email, password} plus consent metadata.
    Raises if encryption isn't configured — callers must check
    credentials_available() first and message the user accordingly."""
    if not _fernet:
        raise RuntimeError("Credentials encryption is not configured (AUTOBOOK_CREDENTIALS_KEY missing/invalid).")
    payload = json.dumps({
        "email": email,
        "password": password,
        "consent": {
            "terms_version": TERMS_VERSION,
            "privacy_version": PRIVACY_VERSION,
            "agreed_at": int(time.time()),
        },
    }).encode("utf-8")
    encrypted = _fernet.encrypt(payload)
    path = credentials_path(discord_id)
    path.write_bytes(encrypted)
    try:
        os.chmod(path, 0o600)  # best-effort; harmless if the OS/filesystem ignores it
    except OSError:
        pass


def load_credentials(discord_id: int) -> dict | None:
    """Returns the decrypted {email, password, consent} dict, or None if
    nothing is saved or it fails to decrypt (e.g. key rotated)."""
    path = credentials_path(discord_id)
    if not path.exists() or not _fernet:
        return None
    try:
        return json.loads(_fernet.decrypt(path.read_bytes()).decode("utf-8"))
    except (InvalidToken, ValueError, json.JSONDecodeError):
        return None


def clear_credentials(discord_id: int) -> bool:
    path = credentials_path(discord_id)
    if path.exists():
        path.unlink()
        return True
    return False


def credentials_available() -> bool:
    return _fernet is not None


class CredentialsModal(discord.ui.Modal, title="Site Login (encrypted)"):
    """Shown only after all three consent checks are confirmed. Values are
    encrypted immediately on submit and never appear in any bot message."""

    email = discord.ui.TextInput(
        label="feua.kliquep2p.com email",
        placeholder="you@example.com",
        required=True,
        max_length=200,
    )
    password = discord.ui.TextInput(
        label="feua.kliquep2p.com password",
        placeholder="Your account password",
        style=discord.TextStyle.short,
        required=True,
        max_length=200,
    )

    async def on_submit(self, interaction: discord.Interaction):
        try:
            save_credentials(interaction.user.id, str(self.email), str(self.password))
        except RuntimeError as e:
            await interaction.response.send_message(
                f"Couldn't save your credentials: {e} Ask whoever runs the bot to set "
                "AUTOBOOK_CREDENTIALS_KEY, then try again.",
                ephemeral=True,
            )
            return
        await interaction.response.send_message(
            "Credentials saved, encrypted at rest. Use /credentials-status anytime to check, "
            "or /credentials-clear to remove them.",
            ephemeral=True,
        )


intents = discord.Intents.default()
# Allow the bot to read message content so it can detect mentions in plain messages
intents.message_content = True
client = discord.Client(intents=intents)
tree = app_commands.CommandTree(client)


def profile_path(discord_id: int) -> Path:
    return PROFILES_DIR / f"{discord_id}.yaml"


def count_profiles() -> int:
    return len(list(PROFILES_DIR.glob("*.yaml")))


def signatures_dir(discord_id: int) -> Path:
    d = PROFILES_DIR / str(discord_id) / "signatures"
    d.mkdir(parents=True, exist_ok=True)
    return d


def list_signature_files(discord_id: int) -> list:
    return sorted(signatures_dir(discord_id).glob("sig_*.json"))


def next_signature_slot(discord_id: int) -> int:
    """Returns the next free slot number 1..MAX, or None if all slots are full."""
    used = set()
    for f in list_signature_files(discord_id):
        try:
            used.add(int(f.stem.split("_")[1]))
        except (IndexError, ValueError):
            continue
    for slot in range(1, MAX_SIGNATURES_PER_PROFILE + 1):
        if slot not in used:
            return slot
    return None


def load_profile(discord_id: int) -> dict:
    """Returns the saved profile dict, or a fresh skeleton if none exists yet."""
    path = profile_path(discord_id)
    if not path.exists():
        return {"id": str(discord_id), "booking": {}}
    with open(path) as f:
        data = yaml.safe_load(f) or {}
    data.setdefault("booking", {})
    return data


def write_profile(discord_id: int, display_name: str, profile: dict) -> None:
    profile["id"] = str(discord_id)
    profile["name"] = display_name
    with open(profile_path(discord_id), "w") as f:
        yaml.safe_dump(profile, f, sort_keys=False)


def validate_day_config(day: str, mode: str, morning_origin, morning_time, afternoon_dropoff, afternoon_time) -> list:
    """mode-aware validation for one day's config — mirrors the old
    validate_morning/validate_afternoon but only requires the fields the
    chosen mode actually needs, since the modal always shows all 5 fields
    regardless of mode (see DayConfigModal)."""
    errors = []
    label = DAY_LABELS[day]
    if mode not in ("roundtrip", "morning", "afternoon"):
        return [f"{label}: mode must be Roundtrip, Morning only, or Afternoon only"]

    if mode in ("morning", "roundtrip"):
        if not morning_origin:
            errors.append(f"{label}: morning origin is required for this mode")
        if not morning_time:
            errors.append(f"{label}: morning time is required for this mode")
        elif not TIME_RE.match(morning_time):
            errors.append(f'{label}: morning time must be 24h HH:MM, got "{morning_time}"')

    if mode in ("afternoon", "roundtrip"):
        if not afternoon_dropoff:
            errors.append(f"{label}: afternoon dropoff is required for this mode")
        if not afternoon_time:
            errors.append(f"{label}: afternoon time is required for this mode")
        elif not TIME_RE.match(afternoon_time):
            errors.append(f'{label}: afternoon time must be 24h HH:MM, got "{afternoon_time}"')

    return errors


def build_day_booking_dict(mode: str, morning_origin=None, morning_time=None,
                            afternoon_dropoff=None, afternoon_time=None) -> dict:
    """Builds one day's booking sub-dict — same shape the old flat schema
    used for its single mode/morning/afternoon, just nested under a
    weekday key now (see DayConfigModal.on_submit)."""
    day_config = {"enabled": True, "mode": mode}
    if mode in ("morning", "roundtrip"):
        day_config["morning"] = {"origin": morning_origin, "dropoff": FEU_ALABANG, "time": morning_time}
    if mode in ("afternoon", "roundtrip"):
        day_config["afternoon"] = {"origin": FEU_ALABANG, "dropoff": afternoon_dropoff, "time": afternoon_time}
    return day_config


def _check_profile_slot(discord_id: int) -> str | None:
    """No profile-count cap anymore — anyone can create one. Kept as a
    function (rather than deleting every call site) since it's the one
    place that decision lives; always returns None (never blocks) now."""
    return None


class DayConfigModal(discord.ui.Modal):
    """Step 2 — one day's route + times. Built fresh per day so the
    afternoon-time Select can offer that specific day's list (Monday's
    3:15/4:15 vs Wed/Thu's 4:10/5:10) — a single shared modal couldn't do
    this, since Discord doesn't let one field's options depend on
    another field live within the same modal (see design discussion).

    All 5 fields are always shown regardless of mode (Roundtrip needs
    all 5, which is exactly Discord's 5-component modal cap — no room
    to spare) — validate_day_config() below only requires the ones the
    chosen mode actually needs, same "offer everything, validate after"
    pattern the old flat commands used.
    """

    def __init__(self, day: str, existing: dict):
        super().__init__(title=f"{DAY_LABELS[day]} booking"[:45])
        self.day = day
        existing_mode = existing.get("mode")
        existing_morning = existing.get("morning") or {}
        existing_afternoon = existing.get("afternoon") or {}

        self.mode_select = discord.ui.Select(
            custom_id="mode",
            options=[
                discord.SelectOption(label=name, value=value, default=(value == existing_mode))
                for name, value in MODE_CHOICES
            ],
        )
        self.morning_origin_select = discord.ui.Select(
            custom_id="morning_origin",
            required=False,
            options=[
                discord.SelectOption(label=s, value=s, default=(s == existing_morning.get("origin")))
                for s in OTHER_STOPS
            ],
        )
        self.afternoon_dropoff_select = discord.ui.Select(
            custom_id="afternoon_dropoff",
            required=False,
            options=[
                discord.SelectOption(label=s, value=s, default=(s == existing_afternoon.get("dropoff")))
                for s in OTHER_STOPS
            ],
        )
        self.morning_time_select = discord.ui.Select(
            custom_id="morning_time",
            required=False,
            options=[
                discord.SelectOption(label=name, value=value, default=(value == existing_morning.get("time")))
                for name, value in MORNING_TIME_CHOICES_BY_DAY[day]
            ],
        )
        self.afternoon_time_select = discord.ui.Select(
            custom_id="afternoon_time",
            required=False,
            options=[
                discord.SelectOption(label=name, value=value, default=(value == existing_afternoon.get("time")))
                for name, value in AFTERNOON_TIME_CHOICES_BY_DAY[day]
            ],
        )

        self.add_item(discord.ui.Label(text="Mode", component=self.mode_select))
        self.add_item(discord.ui.Label(text="Morning origin", description=f"Dropoff is always {FEU_ALABANG}. Ignored if mode is Afternoon only.", component=self.morning_origin_select))
        self.add_item(discord.ui.Label(text="Afternoon dropoff", description=f"Origin is always {FEU_ALABANG}. Ignored if mode is Morning only.", component=self.afternoon_dropoff_select))
        self.add_item(discord.ui.Label(text="Morning time", component=self.morning_time_select))
        self.add_item(discord.ui.Label(text="Afternoon time", component=self.afternoon_time_select))

    async def on_submit(self, interaction: discord.Interaction):
        # NOTE: .values is the standard discord.py convention for reading
        # back a submitted Select's picks (same attribute Select has used
        # for years outside modals) — worth confirming on first real test
        # since Select-in-modal is a very recent addition and this exact
        # detail wasn't directly spelled out anywhere I could verify.
        mode = self.mode_select.values[0] if self.mode_select.values else None
        morning_origin = self.morning_origin_select.values[0] if self.morning_origin_select.values else None
        afternoon_dropoff = self.afternoon_dropoff_select.values[0] if self.afternoon_dropoff_select.values else None
        morning_time = self.morning_time_select.values[0] if self.morning_time_select.values else None
        afternoon_time = self.afternoon_time_select.values[0] if self.afternoon_time_select.values else None

        errors = validate_day_config(self.day, mode, morning_origin, morning_time, afternoon_dropoff, afternoon_time)
        if errors:
            bullet_list = "\n".join(f"- {e}" for e in errors)
            await interaction.response.send_message(f"Couldn't save {DAY_LABELS[self.day]} — fix these first:\n{bullet_list}", ephemeral=True)
            return

        profile = load_profile(interaction.user.id)
        profile["booking"].setdefault(self.day, {"enabled": True})
        day_config = build_day_booking_dict(mode, morning_origin, morning_time, afternoon_dropoff, afternoon_time)
        day_config["enabled"] = profile["booking"][self.day].get("enabled", True)  # don't silently re-enable via this screen
        profile["booking"][self.day] = day_config
        write_profile(interaction.user.id, interaction.user.display_name, profile)

        mode_label = next(name for name, value in MODE_CHOICES if value == mode)
        nudge = await consent_nudge_suffix(interaction.user.id)
        await interaction.response.send_message(
            f"Saved {DAY_LABELS[self.day]}: **{mode_label}**.\n"
            "This stores booking preferences only. Site login is separate — use /credentials-set "
            "when you're ready to enable automated booking." + nudge,
            ephemeral=True,
        )


class ConfigureDayButton(discord.ui.Button):
    def __init__(self, day: str, existing_day_config: dict):
        super().__init__(label=f"Configure {DAY_LABELS[day]}", style=discord.ButtonStyle.secondary)
        self.day = day
        self.existing_day_config = existing_day_config

    async def callback(self, interaction: discord.Interaction):
        await interaction.response.send_modal(DayConfigModal(self.day, self.existing_day_config))


class DaySelectModal(discord.ui.Modal, title="Which days do you autobook?"):
    """Step 1 — the checkbox-group day toggle. Unchecking a day here does
    NOT delete its saved route/time config, only flips enabled off, so
    re-checking it later restores whatever was last configured without
    redoing Step 2."""

    def __init__(self, existing_booking: dict):
        super().__init__()
        self.existing_booking = existing_booking
        self.day_checkboxes = discord.ui.CheckboxGroup(
            custom_id="days",
            required=False,
            min_values=0,
            max_values=len(DAY_KEYS),
            options=[
                discord.CheckboxGroupOption(
                    label=DAY_LABELS[d], value=d,
                    default=existing_booking.get(d, {}).get("enabled", False),
                )
                for d in DAY_KEYS
            ],
        )
        self.add_item(discord.ui.Label(text="Days", component=self.day_checkboxes))

    async def on_submit(self, interaction: discord.Interaction):
        selected_days = list(self.day_checkboxes.values)  # see .values note in DayConfigModal.on_submit

        profile = load_profile(interaction.user.id)
        for d in DAY_KEYS:
            entry = profile["booking"].setdefault(d, {"enabled": False})
            entry["enabled"] = d in selected_days
        write_profile(interaction.user.id, interaction.user.display_name, profile)

        if not selected_days:
            await interaction.response.send_message(
                "No days enabled. Run /booking-set again whenever you want to turn one on.", ephemeral=True
            )
            return

        view = discord.ui.View(timeout=300)
        for d in selected_days:
            view.add_item(ConfigureDayButton(d, profile["booking"].get(d, {})))
        nudge = await consent_nudge_suffix(interaction.user.id)
        await interaction.response.send_message(
            "Tap a day to set (or review) its route and times:" + nudge, view=view, ephemeral=True
        )


@tree.command(name="booking-set", description="Choose which days to autobook, then configure each one")
async def booking_set(interaction: discord.Interaction):
    slot_error = _check_profile_slot(interaction.user.id)
    if slot_error:
        await interaction.response.send_message(slot_error, ephemeral=True)
        return
    profile = load_profile(interaction.user.id)
    await interaction.response.send_modal(DaySelectModal(profile["booking"]))


@tree.command(name="booking-view", description="View your saved Autobook profile config")
async def booking_view(interaction: discord.Interaction):
    path = profile_path(interaction.user.id)
    if not path.exists():
        await interaction.response.send_message(
            "You don't have a profile yet. Use /booking-set to create one.", ephemeral=True
        )
        return
    profile = load_profile(interaction.user.id)
    status_line = "🟢 **Active**" if profile_is_active(profile) else "⏸️ **Inactive** (run `/booking-status active` to resume)"
    if profile_is_locked(profile):
        reason = profile.get("locked_reason")
        status_line += f"\n🔒 **Locked by admin**{f' — {reason}' if reason else ''} (contact them to unlock — you can still edit your config below, it just won't be booked while locked)"
    with open(path) as f:
        content = f.read()
    await interaction.response.send_message(f"{status_line}\n```yaml\n{content}\n```", ephemeral=True)


def profile_is_configured(profile: dict) -> bool:
    """Mirrors app/queue/requirements.js's hasAnyEnabledDay() — at least
    one weekday enabled with a mode chosen, or the older flat schema's
    booking.mode. Kept as a plain function (not a slash command) so
    /requirements and /booking-view can both use it."""
    booking = profile.get("booking") or {}
    if any((booking.get(d) or {}).get("enabled") and (booking.get(d) or {}).get("mode") for d in DAY_KEYS):
        return True
    return bool(booking.get("mode"))


@tree.command(name="requirements", description="Check what's still needed before Autobook will actually book for you")
async def requirements(interaction: discord.Interaction):
    discord_id = interaction.user.id
    profile_path_ = profile_path(discord_id)
    profile = load_profile(discord_id) if profile_path_.exists() else None

    checks = [
        ("Booking profile", bool(profile) and profile_is_configured(profile), "/booking-set"),
        ("Signature", len(list_signature_files(discord_id)) > 0, "/signature-link"),
        ("Site login (credentials)", load_credentials(discord_id) is not None, "/credentials-set"),
    ]

    # Consent reactions aren't a real /command to "fix" — the fix is
    # reacting in the linked channels — so this is checked and rendered
    # separately rather than forced into the (label, ok, fix_cmd) shape above.
    consent_line = None
    if consent_configured():
        try:
            missing_consents = await get_missing_consents(discord_id)
        except discord.HTTPException:
            missing_consents = None  # couldn't verify right now — don't falsely fail the user
        if missing_consents is not None:
            if missing_consents:
                links = ", ".join(
                    f"[{cfg['label']}]({consent_message_link(interaction.guild_id, cfg)})"
                    for _, cfg in missing_consents
                )
                consent_line = f"❌ **REQUIRED** — Consent reactions (react {CONSENT_EMOJI} to: {links})"
            else:
                consent_line = "✅ — Consent reactions"

    lines = []
    all_ready = True
    for label, ok, fix_cmd in checks:
        mark = "✅" if ok else "❌ **REQUIRED**"
        line = f"{mark} — {label}"
        if not ok:
            line += f" (run `{fix_cmd}`)"
            all_ready = False
        lines.append(line)

    if consent_line is not None:
        lines.append(consent_line)
        if consent_line.startswith("❌"):
            all_ready = False

    header = "**You're all set — Autobook will book for you when a slot opens.**" if all_ready else \
        "**Autobook will NOT book for you yet** — finish the items marked REQUIRED below:"
    status_line = "🟢 Autobook status: **Active**" if profile_is_active(profile or {}) else \
        "⏸️ Autobook status: **Inactive** — you won't be booked even once the items below are done. Run `/booking-status active` when you're ready."
    if profile_is_locked(profile or {}):
        reason = (profile or {}).get("locked_reason")
        status_line += (
            f"\n🔒 **Locked by admin**{f' — {reason}' if reason else ''} — you won't be booked while locked, "
            "regardless of your own active/inactive setting or the items below. Contact them to unlock."
        )
    await interaction.response.send_message(status_line + "\n" + header + "\n" + "\n".join(lines), ephemeral=True)


@tree.command(name="booking-status", description="Turn your Autobook profile on or off")
@app_commands.describe(status="active = eligible to be booked when a slot opens; inactive = paused, never booked")
@app_commands.choices(status=[
    app_commands.Choice(name="active", value="active"),
    app_commands.Choice(name="inactive", value="inactive"),
])
async def booking_status(interaction: discord.Interaction, status: app_commands.Choice[str]):
    path = profile_path(interaction.user.id)
    if not path.exists():
        await interaction.response.send_message(
            "You don't have a profile yet. Use /booking-set to create one first.", ephemeral=True
        )
        return

    profile = load_profile(interaction.user.id)
    profile["active"] = (status.value == "active")
    write_profile(interaction.user.id, interaction.user.display_name, profile)

    locked_note = ""
    if profile_is_locked(profile):
        reason = profile.get("locked_reason")
        locked_note = (
            f"\n🔒 Note: your profile is currently **locked by admin**{f' ({reason})' if reason else ''} — "
            "this setting is saved, but you still won't be booked until they unlock you."
        )

    if profile["active"]:
        await interaction.response.send_message(
            "✅ Autobook is now **active** for you — you'll be booked automatically when a slot you're configured for opens "
            "(as long as your requirements are complete — check with /requirements)." + locked_note,
            ephemeral=True,
        )
    else:
        await interaction.response.send_message(
            "⏸️ Autobook is now **inactive** for you — your profile stays saved, but you won't be booked until you "
            "run `/booking-status active` again." + locked_note,
            ephemeral=True,
        )


def profile_is_active(profile: dict) -> bool:
    """Mirrors app/queue/requirements.js's isProfileActive() — opt-in.
    The field must be explicitly True. Missing it entirely (a new or
    never-confirmed profile) is treated as inactive, so nobody gets
    auto-booked until they deliberately run /booking-status active."""
    return bool(profile) and profile.get("active") is True


def profile_is_locked(profile: dict) -> bool:
    """Mirrors app/queue/requirements.js's isProfileLocked() — the ADMIN
    override, set only via the admin panel (app/webserver/admin_server.js),
    never by the user themselves. Always wins over `active` regardless of
    what the user has set, without touching/overwriting it — unlocking
    restores whatever the user had, no reconfiguration needed."""
    
    return bool(profile) and profile.get("locked") is not False


@tree.command(name="booking-delete", description="Delete your Autobook profile config")
async def booking_delete(interaction: discord.Interaction):
    path = profile_path(interaction.user.id)
    if not path.exists():
        await interaction.response.send_message("You don't have a profile to delete.", ephemeral=True)
        return
    path.unlink()
    await interaction.response.send_message("Profile deleted.", ephemeral=True)


@tree.command(name="credentials-set", description="Securely save your feua.kliquep2p.com login for automated booking")
async def credentials_set(interaction: discord.Interaction):
    if not profile_path(interaction.user.id).exists():
        await interaction.response.send_message(
            "Create your profile first with /booking-set.", ephemeral=True
        )
        return

    if not credentials_available():
        await interaction.response.send_message(
            "Credential storage isn't set up yet (AUTOBOOK_CREDENTIALS_KEY missing/invalid on the bot's "
            "side). Ask whoever runs the bot to fix that first.",
            ephemeral=True,
        )
        return

    if not consent_configured():
        await interaction.response.send_message(
            "Consent verification isn't set up yet (the Privacy/Terms/Transparency channel or message "
            "IDs aren't configured on the bot's side — run /consent-post first). Ask whoever runs the "
            "bot to finish that.",
            ephemeral=True,
        )
        return

    try:
        missing = await get_missing_consents(interaction.user.id)
    except discord.HTTPException:
        await interaction.response.send_message(
            "Couldn't check your consent reactions right now (Discord API error) — try again in a bit.",
            ephemeral=True,
        )
        return

    if missing:
        lines = "\n".join(
            f"- **{cfg['label']}** — react with {CONSENT_EMOJI} here: "
            f"{consent_message_link(interaction.guild_id, cfg)}"
            for _, cfg in missing
        )
        await interaction.response.send_message(
            f"Before you can save your site login, finish reacting {CONSENT_EMOJI} to:\n{lines}\n\n"
            "Then run /credentials-set again.",
            ephemeral=True,
        )
        return

    # All three already reacted — skip straight to the private form, no
    # extra confirmation screen needed.
    await interaction.response.send_modal(CredentialsModal())


@tree.command(name="consent-post", description="[admin] Post the Privacy/Terms/Transparency consent messages once")
@app_commands.default_permissions(administrator=True)
async def consent_post(interaction: discord.Interaction):
    """One-time setup helper: posts a message in each of the 3 configured
    channels asking people to react CONSENT_EMOJI, then reports back the
    message IDs so you can paste them into .env as
    AUTOBOOK_<X>_MESSAGE_ID. Safe to re-run — it always posts fresh
    messages rather than editing/deduping, so only run it once per
    channel (or update the channel IDs in .env first if you want new ones).
    """
    if not any(c["channel_id"] for c in CONSENT_CHANNELS.values()):
        await interaction.response.send_message(
            "No consent channel IDs are set yet — set AUTOBOOK_PRIVACY_CHANNEL_ID, "
            "AUTOBOOK_TERMS_CHANNEL_ID, and AUTOBOOK_TRANSPARENCY_CHANNEL_ID in .env first, "
            "then restart the bot and run this again.",
            ephemeral=True,
        )
        return

    await interaction.response.defer(ephemeral=True)
    results = []
    for key, cfg in CONSENT_CHANNELS.items():
        if not cfg["channel_id"]:
            results.append(f"- {cfg['label']}: **skipped** — no channel ID configured")
            continue
        try:
            channel = client.get_channel(cfg["channel_id"]) or await client.fetch_channel(cfg["channel_id"])
            message = await channel.send(
                f"**{cfg['label']}**\n\n"
                f"React with {CONSENT_EMOJI} below to confirm you've read this and agree, "
                "before using `/credentials-set`."
            )
            await message.add_reaction(CONSENT_EMOJI)
            results.append(f"- {cfg['label']}: posted — set `AUTOBOOK_{key.upper()}_MESSAGE_ID={message.id}`")
        except discord.HTTPException as e:
            results.append(f"- {cfg['label']}: **failed** ({e})")

    await interaction.followup.send(
        "Posted. Add these to .env then restart the bot:\n" + "\n".join(results),
        ephemeral=True,
    )


@tree.command(name="credentials-status", description="Check whether Autobook has your site login saved (never shows the values)")
async def credentials_status(interaction: discord.Interaction):
    creds = load_credentials(interaction.user.id)
    if not creds:
        await interaction.response.send_message(
            "No credentials on file. Use /credentials-set to add them.", ephemeral=True
        )
        return
    consent = creds.get("consent", {})
    agreed_at = consent.get("agreed_at")
    agreed_str = time.strftime("%Y-%m-%d %H:%M UTC", time.gmtime(agreed_at)) if agreed_at else "unknown"
    await interaction.response.send_message(
        f"Credentials are on file. Consented to Terms v{consent.get('terms_version', '?')} / "
        f"Privacy v{consent.get('privacy_version', '?')} on {agreed_str}. "
        "Use /credentials-clear to remove.",
        ephemeral=True,
    )


@tree.command(name="credentials-clear", description="Delete your saved feua.kliquep2p.com login")
async def credentials_clear(interaction: discord.Interaction):
    deleted = clear_credentials(interaction.user.id)
    await interaction.response.send_message(
        "Credentials deleted." if deleted else "No credentials were on file.", ephemeral=True
    )


@tree.command(name="signature-link", description="Get a one-time link to draw a signature variant on your phone")
async def signature_link(interaction: discord.Interaction):
    discord_id = interaction.user.id

    if not profile_path(discord_id).exists():
        await interaction.response.send_message(
            "Create your profile first with /booking-set.", ephemeral=True
        )
        return

    if not SIGNATURE_BASE_URL:
        await interaction.response.send_message(
            "The signature web link isn't set up yet (AUTOBOOK_SIGNATURE_BASE_URL is unset) — "
            "there's currently no way to add a signature until that's configured. "
            "Ping whoever's running the bot.",
            ephemeral=True,
        )
        return

    slot = next_signature_slot(discord_id)
    if slot is None:
        await interaction.response.send_message(
            f"You already have {MAX_SIGNATURES_PER_PROFILE} signature variants saved "
            "(the max, for randomization). Delete one with /signature-delete first.",
            ephemeral=True,
        )
        return

    try:
        token = issue_signature_token(discord_id)
    except OSError as e:
        print(f"Failed to write signature token: {e}", file=sys.stderr)
        await interaction.response.send_message(
            "Couldn't create a signature link (couldn't write to the profiles folder — "
            "check permissions). Ping whoever's running the bot.",
            ephemeral=True,
        )
        return

    url = f"{SIGNATURE_BASE_URL}/s/{token}"
    await interaction.response.send_message(
        f"Draw signature variant {slot}/{MAX_SIGNATURES_PER_PROFILE} here (link expires in ~15 min, "
        f"one-time use):\n{url}",
        ephemeral=True,
    )


@tree.command(name="signature-list", description="List your saved signature variants")
async def signature_list(interaction: discord.Interaction):
    files = list_signature_files(interaction.user.id)
    if not files:
        await interaction.response.send_message(
            "No signature variants saved yet. Use /signature-link to draw one.", ephemeral=True
        )
        return
    lines = []
    for f in files:
        with open(f) as fh:
            data = json.load(fh)
        lines.append(f"- {f.stem}: {len(data.get('strokes', []))} stroke(s)")
    await interaction.response.send_message(
        f"You have {len(files)}/{MAX_SIGNATURES_PER_PROFILE} signature variants:\n" + "\n".join(lines),
        ephemeral=True,
    )


@tree.command(name="signature-delete", description="Delete a signature variant by slot number (1-3)")
@app_commands.describe(slot="Which variant to delete")
async def signature_delete(interaction: discord.Interaction, slot: int):
    path = signatures_dir(interaction.user.id) / f"sig_{slot}.json"
    if not path.exists():
        await interaction.response.send_message(f"No signature in slot {slot}.", ephemeral=True)
        return
    path.unlink()
    await interaction.response.send_message(f"Deleted signature variant {slot}.", ephemeral=True)


@client.event
async def on_ready():
    test_guild_id = os.environ.get("AUTOBOOK_TEST_GUILD_ID")
    if test_guild_id:
        guild = discord.Object(id=int(test_guild_id))
        tree.copy_global_to(guild=guild)
        await tree.sync(guild=guild)
        # Clear any lingering GLOBAL registration so Discord doesn't show
        # both the global copy and the guild-local copy side by side in
        # this server (that's what duplicate commands in the picker means).
        # Global sync can take up to ~1hr to actually clear on Discord's
        # side even though this call itself returns immediately.
        tree.clear_commands(guild=None)
        await tree.sync()
        print(f"Synced commands instantly to test guild {test_guild_id} "
              f"(cleared global registration to avoid duplicates — may take "
              f"up to ~1hr to fully disappear from other servers).")
    else:
        await tree.sync()
        print("Synced commands globally (can take up to ~1hr to propagate).")
    print(f"Autobook config bot logged in as {client.user} ({count_profiles()} profiles saved)")
    print(f"  .env loaded from: {DOTENV_PATH} (exists: {DOTENV_PATH.exists()})")
    print(f"  AUTOBOOK_SIGNATURE_BASE_URL: {SIGNATURE_BASE_URL or '(not set — /signature-link disabled)'}")
    print(f"  AUTOBOOK_TEST_GUILD_ID: {test_guild_id or '(not set — using global sync)'}")
    print(f"  AUTOBOOK_CREDENTIALS_KEY: {'set, encryption ready' if credentials_available() else '(not set — /credentials-set disabled)'}")


@client.event
async def on_message(message: discord.Message):
    """Simple handler: when a non-bot user mentions the bot in a channel,
    reply and mention the user so they see the response.
    """
    # Ignore messages from bots (including self)
    if message.author is None or message.author.bot:
        return

    # Detect direct mentions (both <@id> and <@!id>) or resolved mention in message.mentions
    bot_mentioned = False
    try:
        if client.user in message.mentions:
            bot_mentioned = True
        else:
            # fallback: literal mention forms in content
            bot_mentioned = f"<@{client.user.id}>" in message.content or f"<@!{client.user.id}>" in message.content
    except Exception:
        bot_mentioned = False

    if not bot_mentioned:
        return

    # Short helpful reply — adjust text to taste
    reply_text = (
        f"Heyyy {message.author.mention}! It's so awesome to see you! "
        "I'm Stella, your cheerful Autobook assistant! "
        "Want to get your ride preferences set up? Just use /booking-set! "
        "Need to add your signature? /signature-link has you covered! "
        "And if you're not sure what to do, don't worry! Just tell me what you need or do /requirements"
        "and I'll be right here to help!"
    )
    try:
        # reply without also auto-mentioning the author (we already include their mention)
        await message.reply(reply_text, mention_author=False)
    except Exception:
        # fallback to channel send if reply fails for any reason
        await message.channel.send(reply_text)


def main():
    token = os.environ.get("AUTOBOOK_DISCORD_TOKEN")
    if not token:
        print("Set AUTOBOOK_DISCORD_TOKEN before running.", file=sys.stderr)
        sys.exit(1)
    client.run(token)


if __name__ == "__main__":
    main()