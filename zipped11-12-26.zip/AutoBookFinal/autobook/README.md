# Autobook — Phase 1 pieces

This is just the first two pieces from the prototype spec:

1. **`tools/inspect_page.py`** — points at the real booking site and reports
   every dropdown, radio group, checkbox, text input, and button it finds.
   Run this against the actual site before writing any automation, so
   selectors and origin lists come from the real DOM, not guesses.

2. **`bot/bot.py`** — a Discord bot that is the shared "place for you and
   your friends" to enter booking config. It only writes profile YAML
   files (`profiles/<discord_id>.yaml`) — origin, dropoff, time, mode.
   It never touches credentials, the browser, or the job queue. Those stay
   separate, per the spec's security boundary (section 41).

## Install

```bash
pip install -r requirements.txt --break-system-packages
playwright install chromium
```

## 1. Inspect the real booking site

```bash
python tools/inspect_page.py https://the-real-booking-site.example
```

If the form is behind a login:

```bash
export AUTOBOOK_INSPECT_USER="you@example.com"
export AUTOBOOK_INSPECT_PASS="..."
python tools/inspect_page.py https://the-real-booking-site.example \
    --login-url https://the-real-booking-site.example/login \
    --username-env AUTOBOOK_INSPECT_USER \
    --password-env AUTOBOOK_INSPECT_PASS \
    --username-selector "#email" \
    --password-selector "#password" \
    --submit-selector "#login-btn"
```

Run with `--headed` the first time so you can watch it and confirm the
selectors are right. This tool never submits a booking — it only reads
the page.

## 2. Run the Discord config bot

1. Create a Discord application + bot at https://discord.com/developers/applications,
   enable it, and invite it to your server (just yours, for now — no
   special scopes needed beyond `applications.commands` and `bot`).
2. Set the token:
   ```bash
   export AUTOBOOK_DISCORD_TOKEN="your-bot-token"
   ```
3. Run it:
   ```bash
   python bot/bot.py
   ```
4. In Discord, use `/booking-set`, `/booking-view`, `/booking-delete`.

Since you're testing solo first, just you using `/booking-set` will
create `profiles/<your-discord-id>.yaml` — the same file format the
booking engine will eventually consume. The 5-profile cap is enforced
so you can safely invite friends later without exceeding the prototype's
limit.

## 3. Per-profile signatures (randomized, real handwriting)

The old prototype drew the exact same zig-zag stroke for every booking — same
signature every time, for every profile, which is exactly the "suspicious"
pattern worth avoiding. The fix:

1. Send friends `tools/signature_capture.html` — they open it in any browser,
   draw their real signature, and it downloads `signature.json` (their actual
   stroke path, not just a flat image — nothing is uploaded from that page).
2. They send you that file, you (or they, once the bot's in their server)
   run `/signature-add` with it attached. Up to 3 variants per profile.
3. `app/workflow/signature.js` picks one variant at random per booking and
   replays the real stroke path onto the site's signature canvas via genuine
   mouse events — same mechanism the old prototype used, so the site's
   own signature library (jquery.signature.js) captures it exactly as if
   they'd drawn it live. Small random jitter (position/scale/timing) means
   even reusing the same variant twice won't produce an identical result.

`/signature-list` and `/signature-delete <slot>` manage saved variants.

Note: `app/workflow/signature.js` is written against Playwright's `Page` API
(not yet wired into a full runnable app — that's the next piece, porting the
rest of the old Puppeteer workflow to Playwright).

## 4. Connecting Monitor Booking → Autobook (the "signal")

Monitor Booking already watches the calendar every 5 minutes and knows the
instant a new date opens — Autobook has no reason to poll it too. Instead,
Monitor pushes a signal, and Autobook turns it into booking jobs:

```
Monitor detects new date
        |
        v
POST http://127.0.0.1:4790/trigger/date-open
   header: x-trigger-secret
   body:   { dates: [...], detectedAt, source: "monitor" }
        |
        v
Autobook's trigger server (app/trigger/server.js)
        |
        v
One BookingJob per active profile per date (roundtrip stays atomic)
        |
        v
Shared queue (app/queue/queue.js) → picked up by the 2 workers
```

**On the Autobook side:**
- `app/trigger/server.js` — a small HTTP server (no Express, matches the
  "avoid unnecessary infrastructure" principle) listening on **loopback
  only** by default, since a hit to this endpoint creates real bookings.
  Requires a shared-secret header (`x-trigger-secret`) on every request.
- `app/queue/queue.js` / `app/queue/job.js` — the actual shared queue and
  BookingJob model from spec sections 19–21 (priority = roundtrip first,
  FIFO within a priority so one-way jobs can't starve).
- Config via Autobook's `.env` (see `.env.example`): `AUTOBOOK_TRIGGER_PORT`,
  `AUTOBOOK_TRIGGER_SECRET`, `AUTOBOOK_TRIGGER_HOST`.

**On the Monitor Booking side** (in the zip you sent):
- `src/notifier/autobook.js` — new module, same pattern as
  `discord.js`/`philsms.js`. POSTs only *genuinely new* dates (not the full
  currently-open list), fails soft — if Autobook is down or misconfigured,
  it logs and moves on without breaking your existing Discord/SMS alerts.
- `src/notifier/index.js` and `main.js` — updated to call it alongside the
  existing notifiers whenever `sendMessage()` fires.
- `.env.example` — new `AUTOBOOK_TRIGGER_*` vars. **`AUTOBOOK_TRIGGER_ENABLED`
  defaults to `false`**, so nothing changes in Monitor's behavior until you
  turn it on and set a matching secret on both sides.

Tested end-to-end against the queue: a POST with the right secret enqueues
a job per active profile; a wrong secret gets a clean 401, nothing enqueued.

**Not yet wired up:** the workers that actually pull jobs off this queue
and run the booking (that's the Playwright port of `login.js` /
`selectOptions.js` / `submit.js` / `confirm.js` from the old prototype —
still the next piece).

## What's intentionally NOT here yet

- The actual browser automation / booking engine (needs real selectors
  from step 1 first).
- The 2-worker queue (code for it is straightforward once the engine
  exists — happy to scaffold it next; the spec's design keeps it
  decoupled from this config layer, so no changes here will be needed
  when it's added).
- Credential storage/encryption — deliberately kept out of the bot, per
  the spec's security boundary. That'll need its own flow (likely a DM-based
  bot command with immediate encryption, never plaintext in a channel).
