// Trigger server — the "signal" endpoint. Monitor Booking already watches
// the calendar; Autobook has no business polling it too. Instead, Monitor
// POSTs here whenever it detects a genuinely new date, and Autobook turns
// that into booking jobs on the shared queue for every active profile.
//
// Deliberately built on Node's built-in http module rather than Express —
// this is one small endpoint, not a web app, and the spec's design
// principle #7 is "avoid unnecessary infrastructure."
//
// Security: loopback-only by default (not reachable from outside this
// machine) PLUS a shared-secret header, since a hit to this endpoint
// creates real bookings. Never logs the secret itself.

const http = require('http');
const path = require('path');
require('../lib/logTee').installFileLogging('trigger'); // tees console.log/warn/error to logs/trigger.log for the admin panel's Logs page
const { sharedQueue } = require('../queue/queue');
const { listActiveProfiles, validateProfile, buildJob } = require('../queue/job');
const { isProfileLocked } = require('../queue/requirements');
const { isSubscriptionActive, isOperatorProfile } = require('../queue/subscription');
const { registerBatch } = require('./batchTracker');

const PROFILES_DIR = path.join(__dirname, '..', '..', 'profiles');
const PORT = parseInt(process.env.AUTOBOOK_TRIGGER_PORT, 10) || 4790;
const SECRET = process.env.AUTOBOOK_TRIGGER_SECRET;
const HOST = process.env.AUTOBOOK_TRIGGER_HOST || '127.0.0.1'; // loopback-only by default

function readBody(req) {
    return new Promise((resolve, reject) => {
        let data = '';
        let size = 0;
        req.on('data', chunk => {
            size += chunk.length;
            if (size > 100_000) { // guard against absurd payloads
                reject(new Error('Payload too large'));
                req.destroy();
                return;
            }
            data += chunk;
        });
        req.on('end', () => resolve(data));
        req.on('error', reject);
    });
}

function sendJson(res, status, body) {
    const payload = JSON.stringify(body);
    res.writeHead(status, { 'Content-Type': 'application/json' });
    res.end(payload);
}

/**
 * Given newly-opened dates, enqueue one job per active, valid profile per
 * date. Roundtrip profiles get one atomic job (never split), per spec
 * section 7. isTest tags every resulting job so tools/test_worker.js can
 * safely act only on explicitly-test-tagged jobs and leave real ones
 * alone (no production/real-submit worker exists yet).
 */
function enqueueForNewDates(dates, isTest = false) {
    const profiles = listActiveProfiles(PROFILES_DIR);
    const enqueued = [];
    const skipped = [];
    // Groups every job this call produces so app/trigger/batchTracker.js
    // can tell when they've ALL finished and worker.js can post one
    // combined Stella channel summary — see buildJob()'s batchId doc
    // comment in app/queue/job.js.
    const batchId = `batch-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;

    for (const profile of profiles) {
        // Distinct from listActiveProfiles() above (which just means "a
        // profile YAML file exists on disk") — this is the user's own
        // on/off switch, set via /booking-status in Discord. Opt-in: the
        // field must be explicitly `true`. Missing it entirely (a new or
        // never-confirmed profile) is treated as inactive, so nothing gets
        // auto-booked until someone deliberately runs /booking-status active.
        if (profile.active !== true) {
            skipped.push({ profileId: profile.id, profileName: profile.name || null, reason: 'inactive', errors: ['not active — run /booking-status active to enable autobooking'] });
            continue;
        }

        // Admin override (app/webserver/admin_server.js) — checked
        // separately from, and BEFORE, the user's own active flag matters
        // at all conceptually, though the order here doesn't matter since
        // either one alone is enough to skip. Kept as its own distinct
        // skip reason (not folded into 'inactive') so it's never ambiguous
        // whether the USER paused themselves or an ADMIN froze them.
        if (isProfileLocked(profile)) {
            skipped.push({
                profileId: profile.id, profileName: profile.name || null, reason: 'locked',
                errors: [`locked by admin${profile.locked_reason ? ` (${profile.locked_reason})` : ''} — contact them to unlock`],
            });
            continue;
        }

        // THIRD independent gate — billing. A profile can be active and
        // unlocked and still not be eligible if it has no currently-paid
        // (or complimentary/gifted) subscription. See
        // app/queue/subscription.js's header comment for the full
        // active/locked/subscription gate model. Kept as its own skip
        // reason, distinct from 'inactive'/'locked', so it's never
        // ambiguous whether the USER paused themselves, an ADMIN froze
        // them, or their PLAN simply isn't active/has expired.
        //
        // Operator bypass: the operator's own profile(s)
        // (AUTOBOOK_OPERATOR_PROFILE_IDS) never need a subscription at
        // all — they're not a customer, so there's nothing to bill. This
        // is deliberately a full bypass of the gate, not just an
        // exclusion from the capacity COUNT (see subscription.js's
        // listCapacityOccupants) — without this, the operator's own
        // profile would silently stop being bookable the moment this
        // gate shipped, since it will never have a subscription block.
        if (!isOperatorProfile(profile.id) && !isSubscriptionActive(profile)) {
            skipped.push({
                profileId: profile.id, profileName: profile.name || null, reason: 'no_active_subscription',
                errors: ['no active subscription — profile is not currently a paid/complimentary/gifted customer'],
            });
            continue;
        }

        // Validation now depends on the DATE, not just the profile —
        // per-weekday configs mean "is this profile valid" is really "is
        // this profile valid FOR THIS WEEKDAY" (resolved in Philippine
        // time; see app/queue/job.js's resolveWeekday). So the date loop
        // moved from buildJob-only to wrapping validateProfile too.
        for (const date of dates) {
            const errors = validateProfile(profile, date, PROFILES_DIR);
            if (errors.length > 0) {
                // Tag the machine-readable reason separately from the
                // human-readable error strings, so a consumer like Monitor
                // Booking's notifier (see monitor-booking/src/notifier/
                // autobook.js) can reliably detect each case without
                // string-matching English error text.
                //
                // 'day_not_configured' is deliberately its own category,
                // not lumped into 'invalid' — it fires for the ordinary,
                // expected case of a date that isn't a Mon/Wed/Thu (or a
                // Mon/Wed/Thu this profile just hasn't set up), which
                // happens for most profiles on most dates. Reporting that
                // as "incomplete config" in a Discord alert would flag
                // basically everyone as broken every time a Fri/Sat/Sun
                // date opens. 'invalid' is reserved for a real problem:
                // the weekday IS configured but is missing a required
                // field (origin/dropoff/time).
                let reason = 'invalid';
                if (errors.some(e => e.includes('already has a logged booking'))) {
                    reason = 'already_booked';
                } else if (errors.some(e => e.includes('no booking config applies to'))) {
                    reason = 'day_not_configured';
                }
                skipped.push({ profileId: profile.id, profileName: profile.name || null, date, reason, errors });
                continue;
            }
            const job = buildJob(profile, date, 'trigger', isTest, batchId);
            sharedQueue.enqueue(job);
            enqueued.push({ jobId: job.job_id, profileId: profile.id, profileName: profile.name || null, mode: job.mode, weekday: job.weekday, date, isTest });
        }
    }

    // Registered even for isTest batches — recordJobResult()/worker.js
    // decide separately whether a test-tagged batch should actually post
    // to the channel (it shouldn't; see worker.js), but the tracker still
    // needs to see every job report in so it doesn't leak a Map entry
    // that never gets cleaned up.
    if (enqueued.length > 0) {
        registerBatch(batchId, enqueued.map(e => e.jobId));
    }

    return { enqueued, skipped };
}

async function handleTrigger(req, res) {
    if (!SECRET) {
        console.error('AUTOBOOK_TRIGGER_SECRET is not set — refusing all trigger requests.');
        return sendJson(res, 503, { error: 'Trigger server misconfigured' });
    }

    const providedSecret = req.headers['x-trigger-secret'];
    if (providedSecret !== SECRET) {
        // Never log the secret itself, just that a mismatch happened.
        console.warn(`Trigger request rejected: bad or missing x-trigger-secret from ${req.socket.remoteAddress}`);
        return sendJson(res, 401, { error: 'Unauthorized' });
    }

    let body;
    try {
        body = JSON.parse(await readBody(req));
    } catch (e) {
        return sendJson(res, 400, { error: 'Invalid JSON body' });
    }

    const dates = Array.isArray(body.dates) ? body.dates.filter(d => typeof d === 'string' && d.trim()) : [];
    if (dates.length === 0) {
        return sendJson(res, 400, { error: '"dates" must be a non-empty array of strings' });
    }
    const isTest = body.test === true;

    console.log(`Trigger: received ${dates.length} new date(s) from source="${body.source || 'unknown'}"${isTest ? ' [TEST]' : ''}`);
    const result = enqueueForNewDates(dates, isTest);
    console.log(`Trigger: enqueued ${result.enqueued.length} job(s)${isTest ? ' (test-tagged)' : ''}, skipped ${result.skipped.length} invalid profile(s)`);
    // The count alone isn't enough to debug a skip from `docker compose
    // logs` — the actual reason (from validateProfile()/the active-flag
    // check in enqueueForNewDates()) was already being sent back in the
    // HTTP response's `skipped` array, but never printed to the container
    // log itself, which is the only place anyone watching `logs -f`
    // actually sees. Printed here too now, one line per skipped profile.
    result.skipped.forEach(s => {
        console.log(`  ⤷ skipped profile ${s.profileId}${s.date ? ` for ${s.date}` : ''}: ${s.errors.join('; ')}`);
    });

    return sendJson(res, 200, {
        ok: true,
        enqueuedCount: result.enqueued.length,
        enqueued: result.enqueued,
        skipped: result.skipped,
        queueSize: sharedQueue.size(),
    });
}

function startTriggerServer() {
    const server = http.createServer((req, res) => {
        if (req.method === 'POST' && req.url === '/trigger/date-open') {
            handleTrigger(req, res).catch(err => {
                console.error('Trigger handler error:', err.message);
                sendJson(res, 500, { error: 'Internal error' });
            });
            return;
        }
        sendJson(res, 404, { error: 'Not found' });
    });

    server.listen(PORT, HOST, () => {
        console.log(`Autobook trigger server listening on ${HOST}:${PORT} (loopback-only unless overridden)`);
        if (!SECRET) {
            console.warn('WARNING: AUTOBOOK_TRIGGER_SECRET is not set. All trigger requests will be rejected until it is.');
        }
    });

    return server;
}

module.exports = { startTriggerServer, enqueueForNewDates };

if (require.main === module) {
    startTriggerServer();
}