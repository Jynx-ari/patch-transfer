// In-memory tracker for "how many jobs from THIS trigger batch are still
// outstanding" — lets app/worker/worker.js know exactly when to post the
// Stella channel summary (see app/notify/discord.js's sendChannelMessage)
// instead of firing once per job. One trigger POST from Monitor Booking
// can fan out into many jobs across profiles/dates (see
// app/trigger/server.js's enqueueForNewDates()); the summary is meant to
// cover all of them together.
//
// Per-process in-memory only, same as app/queue/queue.js's sharedQueue —
// fine here because the trigger server and worker loop run in the SAME
// Node process (see worker.js's QUEUE OWNERSHIP note), so both always see
// the same Map. This does NOT persist across restarts — a batch that was
// still in flight when the worker process restarts simply never reports
// a summary for the jobs it lost, same as any other in-memory queue state
// in this project.

const batches = new Map(); // batchId -> { remaining: Set<jobId>, results: [] }

/**
 * @param {string} batchId
 * @param {string[]} jobIds - every job_id enqueued as part of this batch
 */
function registerBatch(batchId, jobIds) {
    if (!batchId || !Array.isArray(jobIds) || jobIds.length === 0) return;
    batches.set(batchId, { remaining: new Set(jobIds), results: [] });
}

/**
 * Call once per job as it finishes (success, failure, or blocked) —
 * see app/worker/worker.js's postBatchSummaryIfComplete().
 *
 * @returns {object[]|null} the full results array for the batch, ONLY on
 *   the call that completes it (every job has now reported in) — null
 *   otherwise, including for a batchId that was never registered (e.g.
 *   a job built without one, or a stray isTest job).
 */
function recordJobResult(batchId, jobId, result) {
    const batch = batches.get(batchId);
    if (!batch) return null;
    batch.remaining.delete(jobId);
    batch.results.push(result);
    if (batch.remaining.size > 0) return null;
    batches.delete(batchId);
    return batch.results;
}

module.exports = { registerBatch, recordJobResult };
