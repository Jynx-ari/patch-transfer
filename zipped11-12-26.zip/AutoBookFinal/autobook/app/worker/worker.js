// Unified worker — ONE file, ONE mode switch (AUTOBOOK_MODE), same idea
// as monitor-booking/main.js's MODE/DEBUG/HEADLESS pattern: you flip an
// env var and restart, instead of running a different script or building
// a different image.
//
//   AUTOBOOK_MODE=test         (default — safe) dry-run only, NEVER
//                               clicks submit — but processes EVERY job,
//                               real ones from Monitor Booking included.
//                               This is the mode for safely watching a
//                               real date-open trigger flow all the way
//                               through the real form without any risk
//                               of it actually booking anything.
//   AUTOBOOK_MODE=production   clicks the real submit button, and ONLY
//                               for real (non-test-tagged) jobs.
//                               Test-tagged jobs (from tools/fake_trigger.js)
//                               are always dropped here — this is a
//                               deliberate, hardcoded safety property:
//                               a stray/leftover fake_trigger.js call can
//                               NEVER cause a real submission, no matter
//                               what mode the worker is in. ALSO requires
//                               AUTOBOOK_ALLOW_REAL_SUBMIT=true as a
//                               second, independent confirmation — a
//                               stray/mistyped AUTOBOOK_MODE alone can
//                               never cause a real submission either.
//
// This supersedes tools/test_worker.js as the thing you actually deploy —
// test_worker.js still works standalone for ad-hoc/manual dry-run use,
// but this is the one file/container/npm-script you flip back and forth
// day to day between test and production.
//
// QUEUE OWNERSHIP: sharedQueue is in-memory, scoped to ONE Node process.
// This worker starts the trigger HTTP server ITSELF, in-process, so
// whichever mode is active shares the exact same queue Monitor Booking's
// requests land in. In production, Monitor Booking's AUTOBOOK_TRIGGER_URL
// should point at wherever THIS process/container is running — not the
// standalone autobook-trigger dev container, which has its own separate
// queue and must not run alongside this one.
//
// SUBMIT-MODE SAFETY (only relevant when AUTOBOOK_MODE=production):
//   - Once a submit button is actually clicked for a job, this worker
//     NEVER retries that click, under any outcome. A duplicate click on
//     a submission that may have already gone through risks a duplicate
//     real booking — worse than a booking that needs a human to glance
//     at a screenshot. Retries are only allowed for PRE-submit failures
//     (login, field selection, etc.), capped, with backoff.
//   - Per-profile locking: a profile's browser context is only ever
//     driven by one job at a time, even with multiple worker loops
//     running concurrently.
//   - Roundtrip jobs stay atomic: one worker call owns both legs
//     start-to-finish, never split across workers.
//   - Every attempt (success, failure, or uncertain) gets a screenshot
//     AND a JSON result file under profiles/<id>/booking-results/
//     (production) or profiles/<id>/test-results/ (test mode).

const path = require('path');
const fs = require('fs');
require('../lib/logTee').installFileLogging('worker'); // tees console.log/warn/error to logs/worker.log for the admin panel's Logs page — behavior of the calls themselves is unchanged
require('dotenv').config({ path: path.join(__dirname, '..', '..', '.env'), quiet: true });

const { chromium } = require('playwright');
const { sharedQueue } = require('../queue/queue');
const { loadProfile } = require('../queue/job');
const { checkRequirements, MISSING_LABELS, isProfileActive, isProfileLocked } = require('../queue/requirements');
const { isSubscriptionActive, isOperatorProfile } = require('../queue/subscription');
const { appendBooking, getBookedLegsForDate } = require('../queue/bookingLog');
const { sendDM, sendChannelMessage } = require('../notify/discord');
const { startTriggerServer } = require('../trigger/server');
const { recordJobResult } = require('../trigger/batchTracker');
const {
    runLeg,
    ensureLoggedIn,
    PROFILES_DIR,
    SCREENSHOTS_DIR,
    FullyBookedError,
    buildScreenshotPath,
} = require('../../tools/dry_run_booking.js');

const RAW_MODE = String(process.env.AUTOBOOK_MODE || 'test').toLowerCase();
if (!['test', 'production'].includes(RAW_MODE)) {
    console.error(`AUTOBOOK_MODE="${RAW_MODE}" is not recognized — must be exactly "test" or "production". Defaulting to "test" (safe).`);
}
const MODE = RAW_MODE === 'production' ? 'production' : 'test'; // any typo/unset falls back to the safe option, never the other way around

const NUM_WORKERS = parseInt(process.env.AUTOBOOK_WORKER_COUNT, 10) || 2; // configurable — see FEU_AutoBook_Production_Booking_Fixes.md section 8: production has run at 7, currently being tuned down (4, possibly 3) to isolate concurrency as a variable. No longer "exactly 2" in practice.
const REQUEUE_DELAY_MS = 250;
const MAX_PRE_SUBMIT_ATTEMPTS = 2; // conservative retry — pre-submit steps only, never the submit/dry-run-complete click itself

const RESULTS_DIR_NAME = MODE === 'production' ? 'booking-results' : 'test-results';
const RUN_MODE = MODE === 'production' ? 'submit' : 'dry-run'; // passed straight into runLeg()

// Text channel Stella posts the post-batch "who actually got booked"
// summary to — see postBatchSummaryIfComplete() below. Separate from
// Monitor Booking's own Discord webhook (which posts the "a date just
// opened" alert) on purpose: this is the bot's own REST client/token
// (app/notify/discord.js), posting to whatever channel you point it at,
// which can be the same channel or a different one — your call.
const SUMMARY_CHANNEL_ID = process.env.AUTOBOOK_SUMMARY_CHANNEL_ID || '';

function sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}

function resultsDir(profileId) {
    const d = path.join(PROFILES_DIR, String(profileId), RESULTS_DIR_NAME);
    fs.mkdirSync(d, { recursive: true });
    return d;
}

function writeJobResult(job, result) {
    try {
        const outPath = path.join(resultsDir(job.profile_id), `${job.job_id}.json`);
        fs.writeFileSync(outPath, JSON.stringify(result, null, 2));
    } catch (e) {
        console.error(`Failed to write result file for job ${job.job_id}:`, e.message);
    }
}

// ---- post-batch Stella channel summary ---------------------------------
//
// Complements the per-profile DM sendDM() already sends after each leg
// (search this file for "Submitted your") — this is the OTHER half of
// what was asked for: a single combined message in a text channel,
// posted by the bot itself (not Monitor Booking's webhook), once every
// job from the SAME trigger batch has finished. See app/trigger/
// batchTracker.js for how "every job from the same batch" is tracked,
// and app/trigger/server.js's enqueueForNewDates() for where a batch id
// gets assigned in the first place.
//
// Test-tagged batches (AUTOBOOK_MODE=test, or a real trigger being
// dry-run) deliberately never post here — a summary that reads "booked!"
// for a dry run would be actively misleading in a channel other people
// read, even though the identical message going out as an individual DM
// would just be confusing at worst. isTest jobs still get recorded in
// the tracker (so the Map entry doesn't leak — see registerBatch()'s doc
// comment) — they just don't trigger a channel post.
function summarizeLegsForBatch(job, status, legResults) {
    return {
        profileId: job.profile_id,
        profileName: job.profile_name || String(job.profile_id),
        date: job.date,
        mode: job.mode,
        status, // 'done' | 'partial' | 'needs_manual_check' | 'failed' | 'blocked_incomplete_requirements'
        legs: legResults, // [{ leg, ok, confirmed?, bookingRef?, error? }]
    };
}

function formatBatchSummaryLine(entry) {
    const mention = `<@${entry.profileId}>`;
    if (entry.status === 'blocked_incomplete_requirements') {
        return `⚠️ ${mention} — **${entry.date}**: not booked, profile is missing requirements (told via DM)`;
    }
    if (entry.status === 'skipped_inactive') {
        return `⏸️ ${mention} — **${entry.date}**: skipped, profile set to inactive`;
    }
    if (entry.status === 'skipped_locked') {
        return `🔒 ${mention} — **${entry.date}**: skipped, locked by admin`;
    }
    if (entry.status === 'skipped_no_subscription') {
        return `💳 ${mention} — **${entry.date}**: skipped, no active subscription`;
    }
    if (entry.status === 'no_availability') {
        return `🚫 ${mention} — **${entry.date}**: no seats available (fully booked) — not a failure, nothing to retry`;
    }
    if (entry.status === 'failed' && (!entry.legs || entry.legs.length === 0)) {
        return `❌ ${mention} — **${entry.date}**: booking FAILED, needs a look`;
    }
    const legParts = (entry.legs || []).map(l => {
        if (!l.ok) return `${l.leg}: failed`;
        if (MODE !== 'production') return `${l.leg}: dry-run OK`;
        return `${l.leg}: ${l.confirmed ? 'confirmed' : 'submitted, UNCERTAIN'}`;
    });
    const marker = entry.status === 'needs_manual_check' ? '⚠️' : '✅';
    return `${marker} ${mention} — **${entry.date}**: ${legParts.join(', ')}`;
}

async function postBatchSummaryIfComplete(job, status, legResults) {
    if (!job.trigger_batch_id) return; // job wasn't built as part of a trigger batch (e.g. a one-off manual tool run) — nothing to complete
    const entry = summarizeLegsForBatch(job, status, legResults);
    const finishedBatch = recordJobResult(job.trigger_batch_id, job.job_id, entry);
    if (!finishedBatch) return; // batch still has other jobs outstanding

    if (job.isTest) return; // see doc comment above — dry-run batches never post to the channel
    if (!SUMMARY_CHANNEL_ID) {
        console.warn(`Batch ${job.trigger_batch_id} finished but AUTOBOOK_SUMMARY_CHANNEL_ID is not set — skipping channel summary. Set it in autobook/.env to enable this.`);
        return;
    }

    const lines = finishedBatch.map(formatBatchSummaryLine);
    const content = `**Autobook results for this trigger:**\n${lines.join('\n')}`;
    const res = await sendChannelMessage(SUMMARY_CHANNEL_ID, { content });
    if (!res.ok) console.warn(`Failed to post batch summary to channel ${SUMMARY_CHANNEL_ID}: ${res.error}`);
}

// ---- per-profile session + locking -----------------------------------
//
// One persistent context per profile, reused across jobs for that
// profile (matches the spec's "persistent browser sessions" / "isolated
// profile contexts" architecture). lockedProfiles ensures only one
// worker loop drives a given profile's session at a time, regardless of
// mode.
const profileSessions = new Map(); // profileId -> { context, page }
const lockedProfiles = new Set();

async function getProfileSession(browser, profileId) {
    let session = profileSessions.get(profileId);
    if (!session) {
        const context = await browser.newContext();
        const page = await context.newPage();
        session = { context, page };
        profileSessions.set(profileId, session);
    }
    return session;
}

// ---- job processing -----------------------------------------------------

async function processJob(browser, job) {
    const profile = loadProfile(job.profile_id, PROFILES_DIR);
    if (!profile) {
        const result = {
            job_id: job.job_id, profile_id: job.profile_id, date: job.date, mode: MODE,
            status: 'failed', reason: `Profile ${job.profile_id} not found on disk — cannot process.`,
            finished_at: new Date().toISOString(),
        };
        console.error(`Job ${job.job_id}: ${result.reason}`);
        writeJobResult(job, result);
        await postBatchSummaryIfComplete(job, 'failed', []);
        return;
    }

    // /booking-status inactive gate — checked here too as defense-in-depth
    // even though app/trigger/server.js already filters paused profiles
    // out before jobs are even built, since tools/test_worker.js can queue
    // jobs directly, bypassing the trigger server entirely. No DM here —
    // this is the user's own deliberate choice, not something to nag them
    // about like a missing requirement is.
    if (!isProfileActive(profile)) {
        job.status = 'skipped_inactive';
        job.finished_at = new Date().toISOString();
        console.log(`Job ${job.job_id}: profile ${job.profile_id} is set to inactive (/booking-status) — skipping.`);
        writeJobResult(job, {
            job_id: job.job_id, profile_id: job.profile_id, date: job.date, mode: job.mode, worker_mode: MODE,
            status: 'skipped_inactive', finished_at: job.finished_at,
        });
        await postBatchSummaryIfComplete(job, 'skipped_inactive', []);
        return;
    }

    // Admin lock (app/webserver/admin_server.js) — reloaded fresh from
    // profile.yaml right here rather than trusted from whatever
    // app/trigger/server.js saw at enqueue time, same reasoning as the
    // active-flag check just above: tools/test_worker.js can enqueue jobs
    // directly, bypassing the trigger server's own check, AND an admin
    // could lock someone in the gap between a job being enqueued and a
    // worker actually picking it up. Re-checking here closes both gaps
    // with one check. No DM — same as inactive, this isn't something to
    // proactively nag the user about; they'll see it via /requirements or
    // /booking-view if they look.
    if (isProfileLocked(profile)) {
        job.status = 'skipped_locked';
        job.finished_at = new Date().toISOString();
        console.log(`Job ${job.job_id}: profile ${job.profile_id} is locked by admin${profile.locked_reason ? ` (${profile.locked_reason})` : ''} — skipping.`);
        writeJobResult(job, {
            job_id: job.job_id, profile_id: job.profile_id, date: job.date, mode: job.mode, worker_mode: MODE,
            status: 'skipped_locked', locked_reason: profile.locked_reason || null, finished_at: job.finished_at,
        });
        await postBatchSummaryIfComplete(job, 'skipped_locked', []);
        return;
    }

    // THIRD gate — billing, re-checked fresh here for the same reason
    // active/locked are re-checked above: tools/test_worker.js can
    // enqueue jobs directly, bypassing app/trigger/server.js's own copy
    // of this check, and a subscription can lapse in the gap between
    // enqueue and a worker picking the job up. No DM here, same as
    // inactive/locked — this isn't a "requirement to fix" nag, it's
    // billing status the profile owner already has visibility into via
    // the admin panel / (future) /subscription-status command.
    //
    // Operator bypass — same reasoning as app/trigger/server.js: the
    // operator's own profile never needs a subscription, so it's fully
    // exempt from this gate, not just excluded from the capacity count.
    if (!isOperatorProfile(profile.id) && !isSubscriptionActive(profile)) {
        job.status = 'skipped_no_subscription';
        job.finished_at = new Date().toISOString();
        console.log(`Job ${job.job_id}: profile ${job.profile_id} has no active subscription — skipping.`);
        writeJobResult(job, {
            job_id: job.job_id, profile_id: job.profile_id, date: job.date, mode: job.mode, worker_mode: MODE,
            status: 'skipped_no_subscription', finished_at: job.finished_at,
        });
        await postBatchSummaryIfComplete(job, 'skipped_no_subscription', []);
        return;
    }

    // Pre-flight requirements gate — deliberately BEFORE any browser
    // session is opened. Missing signature/credentials used to only
    // surface as an opaque pre-submit failure deep inside runLeg() after
    // a full login+form-fill pass was already burned (see requirements.js
    // header comment). Blocking here instead means: no wasted browser
    // pass, a clear reason in the result file, and the profile owner gets
    // told exactly what to fix instead of just seeing their date silently
    // not get booked.
    const { ready, missing } = checkRequirements(job.profile_id, profile, PROFILES_DIR);
    if (!ready) {
        job.status = 'blocked_incomplete_requirements';
        job.finished_at = new Date().toISOString();
        const missingLabels = missing.map(m => MISSING_LABELS[m] || m);
        console.warn(`Job ${job.job_id}: profile ${job.profile_id} is missing requirements — skipping without opening a browser. Missing: ${missing.join(', ')}`);
        writeJobResult(job, {
            job_id: job.job_id, profile_id: job.profile_id, date: job.date, mode: job.mode, worker_mode: MODE,
            status: 'blocked_incomplete_requirements', missing, missing_labels: missingLabels,
            finished_at: job.finished_at,
        });

        const dm = await sendDM(job.profile_id, {
            content:
                `⚠️ **Your ${job.date} ${job.mode} ride was NOT booked** — your Autobook profile is missing:\n` +
                missingLabels.map(l => `• ${l}`).join('\n') +
                `\n\nFinish these and you'll be covered next time a slot opens. Use /requirements anytime to check your status.`,
        });
        if (!dm.ok) console.warn(`  (also failed to DM profile ${job.profile_id} about it: ${dm.error})`);
        await postBatchSummaryIfComplete(job, 'blocked_incomplete_requirements', []);
        return;
    }

    job.status = 'in_progress';
    job.started_at = new Date().toISOString();
    console.log(`\n=== [${MODE}] Worker: starting job ${job.job_id} — profile ${job.profile_id}, ${job.mode}, ${job.date} (source: ${job.isTest ? 'fake_trigger.js' : 'real trigger'}) ===`);

    const { context, page } = await getProfileSession(browser, job.profile_id);

    const legResults = [];
    for (const leg of job.processes) {
        // Per-leg already-booked guard. validateProfile() in job.js
        // already skips a job entirely when every required leg for this
        // date is logged, but a PARTIAL roundtrip (e.g. morning went
        // through on an earlier run, afternoon didn't) still lets the
        // job through so the missing leg can be attempted — that means
        // the loop here needs its own check so it doesn't blindly
        // re-submit the leg that already succeeded. Only meaningful in
        // production (test/dry-run legs never write to bookings.json).
        if (MODE === 'production' && getBookedLegsForDate(job.profile_id, PROFILES_DIR, job.date).has(leg)) {
            console.log(`Job ${job.job_id}: ${leg} leg for ${job.date} is already logged in bookings.json — skipping to avoid a duplicate submission.`);
            legResults.push({ leg, ok: true, skipped: true, reason: 'already_booked' });
            continue;
        }

        // Resolved once at build time in app/queue/job.js's buildJob(),
        // against this exact date's weekday in Philippine time — NOT
        // re-derived here from profile.booking[leg] directly, which is
        // what used to silently break for per-day profiles (that flat
        // key doesn't exist at all under the nested
        // monday/wednesday/thursday schema bot.py now saves).
        const legConfig = job.legConfigs[leg];
        let attempt = 0;
        let lastError = null;
        let legResult = null;
        let reachedSubmit = false;

        // In 'production' mode, retries only cover getting TO the submit
        // click safely — once SELECTORS.finalSubmitButton is actually
        // clicked inside runLeg, that's final, here and inside runLeg
        // itself. In 'test' mode there's no real submit to worry about,
        // but the same capped-retry shape is reused for consistency and
        // because a flaky pre-submit step is worth one retry either way.
        while (attempt < MAX_PRE_SUBMIT_ATTEMPTS && !legResult) {
            attempt += 1;
            try {
                await ensureLoggedIn(context, page, job.profile_id, { headed: false });
                legResult = await runLeg(page, profile, leg, legConfig, { date: job.date }, RUN_MODE);
                reachedSubmit = legResult.submitted === true;
            } catch (err) {
                lastError = err;
                if (reachedSubmit) break; // should be unreachable; never retry past an actual click
                if (err instanceof FullyBookedError) {
                    // Legitimately no seats — not a bug, not worth retrying
                    // (the seat count won't change in the next 1.5s), and
                    // NOT the generic 'failed' bucket. See
                    // FEU_AutoBook_Production_Booking_Fixes.md section 1.
                    console.log(`Job ${job.job_id}, ${leg} leg: fully booked — ${err.message}`);
                    break;
                }
                console.warn(`Job ${job.job_id}, ${leg} leg, attempt ${attempt}/${MAX_PRE_SUBMIT_ATTEMPTS} failed pre-submit: ${err.message}`);
                if (attempt < MAX_PRE_SUBMIT_ATTEMPTS) await sleep(1500 * attempt);
            }
        }

        if (legResult) {
            legResults.push({ leg, ok: true, ...legResult });

            // Real submission in production mode -> log it to this
            // profile's bookings.json (there's no real DB yet — see
            // app/queue/bookingLog.js) THEN DM the invoice screenshot,
            // leg by leg (not batched to end-of-job), so a morning-leg DM
            // still goes out even if the afternoon leg later fails.
            // legResult.screenshot is runLeg's post-submit capture, which
            // now lands on the site's real /client/success/<ref> page
            // when the redirect happens — see tools/dry_run_booking.js.
            if (MODE === 'production' && legResult.submitted) {
                appendBooking(job.profile_id, PROFILES_DIR, {
                    job_id: job.job_id,
                    leg,
                    date: job.date,
                    origin: legResult.origin,
                    dropoff: legResult.dropoff,
                    departureTime: legResult.departureTime,
                    confirmed: legResult.confirmed,
                    bookingRef: legResult.bookingRef || null,
                    successUrl: legResult.successUrl || null,
                    screenshot: legResult.screenshot || null,
                    submitted_at: new Date().toISOString(),
                });

                if (legResult.screenshot) {
                    const when = legResult.confirmed ? 'looks confirmed' : 'UNCERTAIN — please check';
                    const refLine = legResult.bookingRef ? `\nBooking ref: \`${legResult.bookingRef}\`` : '';
                    sendDM(job.profile_id, {
                        content:
                            `✅ Submitted your **${leg}** ride for ${job.date} (${when}).\n` +
                            `Origin: ${legResult.origin} → Dropoff: ${legResult.dropoff}, ${legResult.departureTime}` +
                            refLine,
                        filePath: legResult.screenshot,
                        fileName: `invoice-${leg}-${job.date}.png`,
                    }).then(dm => {
                        if (!dm.ok) console.warn(`  (failed to DM invoice screenshot to profile ${job.profile_id}: ${dm.error})`);
                    });
                }
            }
        } else {
            const fullyBooked = lastError instanceof FullyBookedError;
            legResults.push({
                leg, ok: false, submitted: false, fullyBooked,
                error: lastError ? lastError.message : 'unknown error',
            });
            if (!fullyBooked) {
                const failScreenshot = buildScreenshotPath(job.profile_id, job.date, leg, 'failed');
                await page.screenshot({ path: failScreenshot }).catch(() => {});
                console.error(`Job ${job.job_id}, ${leg} leg: gave up after ${MAX_PRE_SUBMIT_ATTEMPTS} attempts. Screenshot: ${failScreenshot}`);
            }
            // Fully-booked already has its own evidence screenshot from
            // inside runLeg() (see FullyBookedError's throw site) — no
            // need for a second, differently-named one here.
        }
        // Roundtrip legs are independent one-way submissions on the real
        // site — keep going to the next leg even if this one failed.
    }

    job.finished_at = new Date().toISOString();
    const anyRan = legResults.some(r => r.ok);
    // A leg that's legitimately fully booked is neither a submitted leg
    // nor a real failure — see FEU_AutoBook_Production_Booking_Fixes.md
    // section 1. If EVERY non-ok leg was fully-booked (none were actual
    // errors) and nothing submitted, that's 'no_availability', not
    // 'failed' — the distinction matters for anyone reading the Discord
    // summary or the job history later.
    const nonOkLegs = legResults.filter(r => !r.ok);
    const allNonOkAreFullyBooked = nonOkLegs.length > 0 && nonOkLegs.every(r => r.fullyBooked);
    let status;
    if (MODE === 'production') {
        const anySubmitted = legResults.some(r => r.submitted);
        const allSubmitted = legResults.every(r => r.submitted);
        const allConfirmed = legResults.every(r => r.confirmed);
        status = !anySubmitted
            ? (allNonOkAreFullyBooked ? 'no_availability' : 'failed')
            : (allSubmitted && allConfirmed) ? 'done' : 'needs_manual_check';
    } else {
        status = anyRan
            ? (legResults.every(r => r.ok) ? 'done' : 'partial')
            : (allNonOkAreFullyBooked ? 'no_availability' : 'failed');
    }
    job.status = status;

    const result = {
        job_id: job.job_id, profile_id: job.profile_id, mode: job.mode, worker_mode: MODE,
        source_is_test: job.isTest,
        date: job.date, status, legs: legResults,
        started_at: job.started_at, finished_at: job.finished_at,
    };
    writeJobResult(job, result);
    await postBatchSummaryIfComplete(job, status, legResults);

    console.log(`=== [${MODE}] Job ${job.job_id} finished: ${status} ===`);
    for (const r of legResults) {
        const marker = MODE === 'production'
            ? (r.confirmed ? '✅' : (r.submitted ? '⚠️ ' : (r.fullyBooked ? '🚫' : '❌')))
            : (r.ok ? '✅' : (r.fullyBooked ? '🚫' : '❌'));
        console.log(`  ${marker} ${r.leg}: ${r.ok ? (MODE === 'production' ? `submitted, confirmed=${r.confirmed}` : 'dry-run OK') : (r.fullyBooked ? `fully booked (${r.error})` : `FAILED (${r.error})`)}`);
    }
    if (status === 'needs_manual_check') {
        console.warn(`  >>> Job ${job.job_id} needs a human to check profiles/${job.profile_id}/${RESULTS_DIR_NAME}/ and profiles/${job.profile_id}/booking-screenshots/${job.date}/ before assuming it worked. <<<`);
    }
}

async function workerLoop(workerId, browser) {
    console.log(`Worker ${workerId} [${MODE}]: started`);
    for (;;) {
        const job = await sharedQueue.dequeue();

        // Eligibility is intentionally NOT symmetric between modes:
        //   - production mode ONLY takes real jobs. A test-tagged job
        //     (isTest: true, meaning it came from tools/fake_trigger.js,
        //     never from the real Monitor Booking) is dropped here no
        //     matter what — this is a hardcoded safety property, not a
        //     preference, so a stray/leftover fake_trigger.js call can
        //     never cause a real submission.
        //   - test mode takes EVERYTHING — real jobs from Monitor
        //     Booking included — and always runs them as a dry run
        //     (RUN_MODE is derived from MODE alone, not from job.isTest;
        //     see above). This is what makes AUTOBOOK_MODE=test useful
        //     for watching a REAL date-open trigger flow all the way
        //     through the real form with zero risk, instead of real
        //     triggers just being silently dropped while testing.
        const wantsThisJob = MODE === 'production' ? !job.isTest : true;
        if (!wantsThisJob) {
            console.warn(`Worker ${workerId} [${MODE}]: dropping test-tagged job ${job.job_id} — production mode never processes test-tagged jobs, even if AUTOBOOK_MODE was just changed. Use tools/fake_trigger.js against a test-mode worker instead.`);
            continue;
        }

        if (lockedProfiles.has(job.profile_id)) {
            sharedQueue.enqueue(job);
            await sleep(REQUEUE_DELAY_MS);
            continue;
        }

        lockedProfiles.add(job.profile_id);
        try {
            await processJob(browser, job);
        } catch (err) {
            console.error(`Worker ${workerId} [${MODE}]: unexpected error processing job ${job.job_id}:`, err);
            writeJobResult(job, {
                job_id: job.job_id, profile_id: job.profile_id, date: job.date, worker_mode: MODE,
                status: 'failed', reason: `Unexpected worker error: ${err.message}`,
                finished_at: new Date().toISOString(),
            });
            await postBatchSummaryIfComplete(job, 'failed', [{ leg: job.mode, ok: false, error: err.message }]);
        } finally {
            lockedProfiles.delete(job.profile_id);
        }
    }
}

async function startWorker() {
    if (MODE === 'production' && process.env.AUTOBOOK_ALLOW_REAL_SUBMIT !== 'true') {
        console.error(
            'AUTOBOOK_MODE=production but AUTOBOOK_ALLOW_REAL_SUBMIT is not "true" — refusing to start. ' +
            'Production mode clicks the REAL submit button on REAL bookings. Both AUTOBOOK_MODE=production ' +
            'AND AUTOBOOK_ALLOW_REAL_SUBMIT=true are required together, deliberately — flipping one alone ' +
            'is never enough, so a copy-pasted or half-updated .env can\'t submit anything real by accident.'
        );
        process.exit(1);
    }

    console.log(`Starting Autobook worker — AUTOBOOK_MODE=${MODE}, ${NUM_WORKERS} worker loop(s)` +
        (MODE === 'production' ? ', AUTOBOOK_ALLOW_REAL_SUBMIT=true' : ' (dry-run only, nothing real-submits)'));
    fs.mkdirSync(SCREENSHOTS_DIR, { recursive: true });

    const triggerServer = startTriggerServer(); // in-process — see QUEUE OWNERSHIP note above
    const browser = await chromium.launch({ headless: true });

    const loops = [];
    for (let i = 1; i <= NUM_WORKERS; i++) loops.push(workerLoop(i, browser));

    const shutdown = async (sig) => {
        console.log(`${sig} — closing...`);
        triggerServer.close();
        await browser.close();
        process.exit(0);
    };
    process.on('SIGINT', () => shutdown('SIGINT'));
    process.on('SIGTERM', () => shutdown('SIGTERM'));

    await Promise.all(loops); // loops run forever; this just keeps the process alive
}

module.exports = { startWorker, processJob, MODE };

if (require.main === module) {
    startWorker();
}