// Pre-flight "is this profile actually bookable" check.
//
// Two things were already silent failure modes before this file existed:
//   - no signature  -> applySignature() throws deep inside runLeg(), after
//     login + form-fill has already burned a full browser pass
//   - no credentials -> ensureLoggedIn() throws the same way
// Both got treated as ordinary pre-submit failures: retried
// MAX_PRE_SUBMIT_ATTEMPTS times, then silently logged to a screenshot
// nobody was watching for. checkRequirements() below lets worker.js catch
// this BEFORE opening a browser session at all, so it can skip the job and
// tell the profile owner exactly what's missing instead.
//
// Kept dependency-free (fs/path only) and mirrors the checks bot.py's
// /requirements command does — the two aren't code-shared (Python vs
// Node), but they agree on-disk: profiles/<id>/signatures/sig_*.json and
// profiles/<id>/credentials.enc are the two source-of-truth locations.

const fs = require('fs');
const path = require('path');

const DAY_KEYS = ['monday', 'wednesday', 'thursday'];

function hasAnyEnabledDay(profile) {
    const booking = profile && profile.booking;
    if (!booking) return false;
    // Nested per-day schema (bot.py's current DaySelectModal/DayConfigModal
    // shape): booking.<day>.enabled + booking.<day>.mode.
    const nested = DAY_KEYS.some(d => booking[d] && booking[d].enabled && booking[d].mode);
    if (nested) return true;
    // Fall back to the older flat schema (booking.mode directly), in case
    // this profile predates the per-day rework — see job.js's
    // validateProfile(), which still only understands this flat shape.
    return Boolean(booking.mode);
}

function hasSignature(profileId, profilesDir) {
    const dir = path.join(profilesDir, String(profileId), 'signatures');
    if (!fs.existsSync(dir)) return false;
    return fs.readdirSync(dir).some(f => /^sig_\d+\.json$/.test(f));
}

function hasCredentials(profileId, profilesDir) {
    return fs.existsSync(path.join(profilesDir, String(profileId), 'credentials.enc'));
}

function isProfileActive(profile) {
    // The /booking-status on/off switch — distinct from listActiveProfiles()
    // in job.js, which just means "a profile YAML exists on disk". This is
    // opt-in: the field must be explicitly `true` for a profile to be
    // eligible for autobooking. A missing field (unconfigured profile, or
    // one predating this feature) defaults to INACTIVE, so nothing gets
    // booked without someone deliberately running /booking-status active.
    return !!profile && profile.active === true;
}

function isProfileLocked(profile) {
    // The ADMIN override (app/webserver/admin_server.js) — deliberately a
    // SEPARATE field from `active`, not the same switch. `active` is the
    // user's own preference; `locked` always wins regardless of what the
    // user has set, and doesn't touch/overwrite their `active` value —
    // unlocking instantly restores whatever they had, no reconfiguration
    // needed. A profile is only ever locked by an explicit admin action
    // (see app/webserver/admin_server.js's /api/profiles/:id/lock), so
    // missing/absent defaults to NOT locked, same direction as a brand
    // new profile always defaulting to unlocked until someone deliberately
    // locks it.
    return !!profile && profile.locked !== false;
}

/**
 * @param {string|number} profileId
 * @param {object|null} profile - already-loaded profile YAML (or null/missing)
 * @param {string} profilesDir
 * @returns {{ ready: boolean, missing: string[] }} missing is a subset of
 *   ['booking_profile', 'signature', 'credentials'], each also usable
 *   directly as a user-facing label via MISSING_LABELS below.
 */
function checkRequirements(profileId, profile, profilesDir) {
    const missing = [];
    if (!profile || !hasAnyEnabledDay(profile)) missing.push('booking_profile');
    if (!hasSignature(profileId, profilesDir)) missing.push('signature');
    if (!hasCredentials(profileId, profilesDir)) missing.push('credentials');
    return { ready: missing.length === 0, missing };
}

const MISSING_LABELS = {
    booking_profile: 'Booking profile (no day enabled/configured — run /booking-set)',
    signature: 'Signature (no variants saved — run /signature-link)',
    credentials: 'Site login (no credentials saved — run /credentials-set)',
};
module.exports = { checkRequirements, MISSING_LABELS, hasSignature, hasCredentials, hasAnyEnabledDay, isProfileActive, isProfileLocked, DAY_KEYS };
