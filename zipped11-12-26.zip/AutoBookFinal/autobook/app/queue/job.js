const fs = require('fs');
const path = require('path');
const yaml = require('js-yaml');
const { getBookedLegsForDate } = require('./bookingLog');

let _seqCounter = 0;

const PRIORITY_RANK = { roundtrip: 0, morning: 1, afternoon: 1 };

// The only weekdays bot.py's DaySelectModal ever lets someone configure
// (see DAY_KEYS in bot/bot.py) — Autobook only runs Mon/Wed/Thu.
const CONFIGURABLE_DAY_KEYS = ['monday', 'wednesday', 'thursday'];

// Every booking date, weekday config, and schedule in this whole project
// is meant in Philippine time (the shuttle runs out of FEU Alabang) — but
// Docker base images default their system clock to UTC, and this worker
// can end up deployed on a host set to anything. Resolving "what weekday
// is this date" against the CONTAINER's ambient timezone would silently
// depend on wherever this happens to run; resolving it explicitly against
// Asia/Manila via Intl (below) doesn't, regardless of what TZ the
// container/host is actually set to. AUTOBOOK_TIMEZONE lets this be
// overridden if ever needed, but the default is deliberately hardcoded to
// PH time rather than trusting an unset env var to imply UTC is fine.
const DEFAULT_TIMEZONE = process.env.AUTOBOOK_TIMEZONE || 'Asia/Manila';

/**
 * @returns {string|null} lowercase weekday name ('monday', 'tuesday', ...)
 *   for the given date STRING, resolved against `timezone` regardless of
 *   the machine's own local time — or null if dateStr doesn't parse.
 */
function resolveWeekday(dateStr, timezone = DEFAULT_TIMEZONE) {
    const d = new Date(dateStr);
    if (isNaN(d.getTime())) return null;
    return new Intl.DateTimeFormat('en-US', { timeZone: timezone, weekday: 'long' }).format(d).toLowerCase();
}

/**
 * Resolves which booking config actually applies to a given date, per the
 * per-weekday profile schema bot.py's /booking-set now saves (each of
 * monday/wednesday/thursday has its own enabled/mode/morning/afternoon —
 * see profiles/*.yaml for real examples). Falls back to the older flat
 * schema (booking.mode directly, no weekday nesting) for any profile that
 * predates the per-day rework, applied regardless of weekday — matching
 * exactly how those profiles always behaved before per-day configs
 * existed, so nothing already working breaks.
 *
 * @returns {{ mode: string, morning?: object, afternoon?: object, weekday: string|null } | null}
 *   null if NOTHING applies to this date — e.g. a per-day profile where
 *   this weekday is disabled/unconfigured (a Tuesday/Friday/weekend, or a
 *   Mon/Wed/Thu the user hasn't set up yet) and there's no legacy flat
 *   schema to fall back to either. This is an ordinary, expected outcome
 *   (most dates aren't Mon/Wed/Thu), not a validation error by itself.
 */
function resolveDayBooking(profile, dateStr, timezone = DEFAULT_TIMEZONE) {
    const booking = profile && profile.booking;
    if (!booking) return null;

    const weekday = resolveWeekday(dateStr, timezone);
    const dayConfig = weekday && booking[weekday];
    if (dayConfig && dayConfig.enabled && dayConfig.mode) {
        return { mode: dayConfig.mode, morning: dayConfig.morning, afternoon: dayConfig.afternoon, weekday };
    }

    if (booking.mode) {
        return { mode: booking.mode, morning: booking.morning, afternoon: booking.afternoon, weekday };
    }

    return null;
}

function loadProfile(profileId, profilesDir) {
    const file = path.join(profilesDir, `${profileId}.yaml`);
    if (!fs.existsSync(file)) return null;
    return yaml.load(fs.readFileSync(file, 'utf8'));
}

function listActiveProfiles(profilesDir) {
    if (!fs.existsSync(profilesDir)) return [];
    return fs.readdirSync(profilesDir)
        .filter(f => f.endsWith('.yaml'))
        .map(f => yaml.load(fs.readFileSync(path.join(profilesDir, f), 'utf8')))
        .filter(Boolean);
}

/**
 * Validates whichever booking config applies to `dateStr` for this
 * profile (spec section 28, updated for per-weekday configs — see
 * resolveDayBooking() above). Each leg still requires an explicit
 * origin + dropoff + time — spec update patch, section 8. `dropoff` is
 * the canonical term for the rider's endpoint; `origin` is where the
 * rider boards. Returns error strings; resolveDayBooking() returning
 * null (nothing configured for this weekday) is also reported here as
 * an error string, since the caller (app/trigger/server.js) needs a
 * reason to skip either way.
 *
 * @param {string|null} profilesDir - when provided, also guards against
 *   re-booking a leg that already has a confirmed (or attempted)
 *   bookings.json record for this exact date — see bookingLog.js's
 *   getBookedLegsForDate(). Optional and defaults to null (no check) so
 *   callers that don't care about real booking history — e.g.
 *   tools/dry_run_booking.js testing against a scratch date — aren't
 *   forced to pass one.
 */
function validateProfile(profile, dateStr, profilesDir = null, timezone = DEFAULT_TIMEZONE) {
    const errors = [];
    const resolved = resolveDayBooking(profile, dateStr, timezone);
    if (!resolved) {
        const weekday = resolveWeekday(dateStr, timezone);
        errors.push(
            `Profile ${profile?.id}: no booking config applies to ${dateStr}` +
            (weekday ? ` (${weekday} is not enabled/configured, and no legacy booking.mode is set)` : ' (unparseable date)')
        );
        return errors;
    }
    const { mode, morning, afternoon, weekday } = resolved;
    if (!mode || !['morning', 'afternoon', 'roundtrip'].includes(mode)) {
        errors.push(`Profile ${profile?.id}: invalid booking mode "${mode}" for ${weekday || dateStr}`);
        return errors;
    }
    if (mode === 'morning' || mode === 'roundtrip') {
        if (!morning?.origin) errors.push(`Profile ${profile.id}: ${weekday || dateStr} morning.origin required`);
        if (!morning?.dropoff) errors.push(`Profile ${profile.id}: ${weekday || dateStr} morning.dropoff required`);
        if (!morning?.time) errors.push(`Profile ${profile.id}: ${weekday || dateStr} morning.time required`);
    }
    if (mode === 'afternoon' || mode === 'roundtrip') {
        if (!afternoon?.origin) errors.push(`Profile ${profile.id}: ${weekday || dateStr} afternoon.origin required`);
        if (!afternoon?.dropoff) errors.push(`Profile ${profile.id}: ${weekday || dateStr} afternoon.dropoff required`);
        if (!afternoon?.time) errors.push(`Profile ${profile.id}: ${weekday || dateStr} afternoon.time required`);
    }
    if (errors.length > 0) return errors;

    // Already-booked guard (see bookingLog.js's getBookedLegsForDate doc
    // comment for why `confirmed` is ignored). A roundtrip only skips
    // once BOTH legs are already logged for this date — if e.g. the
    // morning leg went through on a prior run but the afternoon leg
    // never did, this still lets the job through so the missing leg can
    // be attempted; app/worker/worker.js's per-leg loop already books
    // legs independently and would just re-log a leg that's already
    // present, so re-running an already-complete leg here is harmless
    // in the worst case and prevents a stuck half-booked roundtrip in
    // the common case.
    if (profilesDir) {
        const bookedLegs = getBookedLegsForDate(profile.id, profilesDir, dateStr);
        const requiredLegs = mode === 'roundtrip' ? ['morning', 'afternoon'] : [mode];
        const stillMissing = requiredLegs.filter(leg => !bookedLegs.has(leg));
        if (stillMissing.length === 0) {
            errors.push(
                `Profile ${profile.id}: ${weekday || dateStr} already has a logged booking for ${requiredLegs.join(' + ')} — skipping to avoid a duplicate submission`
            );
        }
    }

    return errors;
}

/**
 * Builds a BookingJob for one profile on one date. Roundtrip stays one
 * atomic job (spec section 6.3/7) — never split into two jobs. Assumes
 * validateProfile(profile, date) already passed for this exact date —
 * callers (app/trigger/server.js) always validate first.
 *
 * legConfigs is resolved ONCE here (at build time, against `date`'s
 * actual weekday in Philippine time) and carried on the job itself,
 * rather than re-derived later in app/worker/worker.js from a bare
 * leg name — that's what used to silently break for per-day profiles
 * (worker.js used to look up `profile.booking[leg]` directly, which
 * doesn't exist at all under the nested monday/wednesday/thursday
 * schema). Baking it into the job also means the job result file is a
 * complete, self-contained record of exactly which config was used.
 *
 * @param {boolean} isTest - true only when the originating trigger request
 *   explicitly marked itself as a test (see app/trigger/server.js). Lets
 *   tools/test_worker.js safely dry-run ONLY test-tagged jobs and leave
 *   real ones alone, since there's no production (real-submit) worker yet.
 * @param {string|null} batchId - groups every job built from the same
 *   trigger POST (see app/trigger/server.js's enqueueForNewDates()) so
 *   app/trigger/batchTracker.js can tell when they've ALL finished and
 *   post one combined Stella channel summary instead of one per job.
 *   null for jobs built outside a trigger batch (e.g. a one-off manual
 *   tools/ call) — those just never get a summary posted for them.
 */
function buildJob(profile, date, source = 'manual', isTest = false, batchId = null, timezone = DEFAULT_TIMEZONE) {
    const resolved = resolveDayBooking(profile, date, timezone);
    if (!resolved) {
        throw new Error(`buildJob: no booking config applies to ${date} for profile ${profile?.id} — call validateProfile() first and skip on failure instead of calling buildJob().`);
    }
    const { mode, morning, afternoon, weekday } = resolved;
    const processes = mode === 'roundtrip' ? ['morning', 'afternoon'] : [mode];

    _seqCounter += 1;
    return {
        job_id: `job-${Date.now()}-${_seqCounter}`,
        profile_id: profile.id,
        profile_name: profile.name || null,
        trigger_batch_id: batchId,
        mode,
        weekday,              // e.g. 'monday' — resolved against AUTOBOOK_TIMEZONE (default Asia/Manila), never the host's ambient TZ
        date,
        priorityRank: PRIORITY_RANK[mode],
        processes,
        legConfigs: { morning, afternoon }, // whichever of these apply to `mode`; worker.js reads job.legConfigs[leg], not profile.booking[leg]
        status: 'queued',
        source,               // 'manual' (UI push) or 'trigger' (monitor signal)
        isTest,                // true only for explicitly test-tagged trigger requests
        created_at: new Date().toISOString(),
        started_at: null,
        finished_at: null,
        _seq: _seqCounter,
    };
}

module.exports = {
    loadProfile, listActiveProfiles, validateProfile, buildJob,
    resolveWeekday, resolveDayBooking, DEFAULT_TIMEZONE, CONFIGURABLE_DAY_KEYS,
};
