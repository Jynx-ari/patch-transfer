// Subscription + customer-capacity gate — the THIRD independent
// eligibility gate, alongside isProfileActive() and isProfileLocked()
// from ./requirements.js.
//
//   active   — user's own opt-in switch (/booking-status)
//   locked   — admin override (admin panel)
//   subscription — billing: does this profile currently have paid,
//                  complimentary, or gifted access?
//
// All three are checked independently and in this order at both
// app/trigger/server.js (before a job is even built) and
// app/worker/worker.js (defense-in-depth, since tools/test_worker.js can
// enqueue jobs directly and bypass the trigger server).
//
// Schema written onto profile YAMLs (additive — does not touch or
// replace any existing field):
//
//   subscription:
//     type: paid                 # paid | complimentary | gifted
//     plan: weekly                # day_pass | weekly | biweekly | monthly
//                                  #   | legacy_supporter | gifted_custom
//     status: active               # active | expired | none
//     amount_paid: 30
//     start_date: "2026-09-12"     # ISO date (YYYY-MM-DD), Asia/Manila
//     expiry_date: "2026-09-19"    # ISO date (YYYY-MM-DD), Asia/Manila
//     granted_by: null              # "admin", or an order/claim id for paid
//     reason: null                   # free text, gifted/complimentary only
//     note: null
//
// IMPORTANT: `status` is not blindly trusted. A background expiry sweep
// (future work — see spec patch section 14) is *supposed* to flip
// `status` to 'expired' automatically once `expiry_date` passes, but
// until that sweep exists (or if it's ever late/down), this module
// re-derives the effective status from `expiry_date` every time it's
// asked — same "recheck fresh, don't trust a possibly-stale flag"
// pattern requirements.js already uses for locked/active. This means the
// gate is correct from day one even before the sweep job is built, and
// the sweep job becomes a pure optimization (keeping the on-disk
// `status` field tidy for humans reading the YAML/admin panel) rather
// than something correctness depends on.

const fs = require('fs');
const path = require('path');
const yaml = require('js-yaml');

const DEFAULT_TIMEZONE = process.env.AUTOBOOK_TIMEZONE || 'Asia/Manila';
const MAX_CUSTOMER_CAPACITY = parseInt(process.env.AUTOBOOK_CUSTOMER_CAPACITY, 10) || 7;

/**
 * @returns {string} today's date as YYYY-MM-DD, resolved in `timezone`
 *   regardless of the host/container's own local time — same reasoning
 *   as app/queue/job.js's resolveWeekday().
 */
function todayISO(timezone = DEFAULT_TIMEZONE) {
    // en-CA gives YYYY-MM-DD directly, no manual string surgery needed.
    return new Intl.DateTimeFormat('en-CA', { timeZone: timezone }).format(new Date());
}

/**
 * Operator/admin profile(s) — never consume customer capacity, per spec
 * patch section 1.1. Comma-separated Discord snowflakes.
 * e.g. AUTOBOOK_OPERATOR_PROFILE_IDS=833692577324466186
 */
function getOperatorProfileIds() {
    return new Set(
        String(process.env.AUTOBOOK_OPERATOR_PROFILE_IDS || '')
            .split(',')
            .map(s => s.trim())
            .filter(Boolean)
    );
}

function isOperatorProfile(profileId) {
    return getOperatorProfileIds().has(String(profileId));
}

/**
 * Re-derives the EFFECTIVE subscription status (not just whatever's
 * written on disk) — see header comment for why.
 * @returns {'active'|'expired'|'none'}
 */
function resolveSubscriptionStatus(profile, referenceDateISO = todayISO()) {
    const sub = profile && profile.subscription;
    if (!sub || !sub.status || sub.status === 'none') return 'none';
    if (!sub.expiry_date) return 'none'; // malformed/incomplete record — fail closed, never assume active
    if (sub.status !== 'active') return 'expired'; // explicit non-active status (e.g. already marked expired/revoked) always wins
    // Lexical comparison is safe here: both sides are YYYY-MM-DD.
    return sub.expiry_date >= referenceDateISO ? 'active' : 'expired';
}

/**
 * The gate itself — used by app/trigger/server.js and
 * app/worker/worker.js exactly like isProfileActive()/isProfileLocked().
 * A profile with NO subscription block at all (brand new, never
 * claimed/granted anything) is simply not eligible — same fail-closed
 * default as the other two gates.
 */
function isSubscriptionActive(profile, referenceDateISO = todayISO()) {
    return resolveSubscriptionStatus(profile, referenceDateISO) === 'active';
}

// ---- capacity -----------------------------------------------------------

/**
 * Every profile currently occupying one of the 7 customer slots — i.e.
 * has an effectively-active subscription AND isn't the operator profile.
 * Complimentary and gifted subscriptions count exactly like paid ones
 * (spec patch sections 8 and 9.3).
 */
function listCapacityOccupants(profilesDir, referenceDateISO = todayISO()) {
    if (!fs.existsSync(profilesDir)) return [];
    return fs.readdirSync(profilesDir)
        .filter(f => f.endsWith('.yaml'))
        .map(f => {
            const id = f.replace(/\.yaml$/, '');
            if (isOperatorProfile(id)) return null;
            let profile;
            try {
                profile = yaml.load(fs.readFileSync(path.join(profilesDir, f), 'utf8'));
            } catch {
                return null; // corrupt YAML — never let a bad file crash a capacity check
            }
            if (!isSubscriptionActive(profile, referenceDateISO)) return null;
            return {
                id,
                name: profile.name || null,
                type: profile.subscription.type || null,
                plan: profile.subscription.plan || null,
                expiryDate: profile.subscription.expiry_date || null,
            };
        })
        .filter(Boolean);
}

/**
 * @returns {{ used: number, max: number, available: number, atCapacity: boolean, occupants: object[] }}
 */
function getCapacitySummary(profilesDir, referenceDateISO = todayISO()) {
    const occupants = listCapacityOccupants(profilesDir, referenceDateISO);
    const used = occupants.length;
    const available = Math.max(0, MAX_CUSTOMER_CAPACITY - used);
    return { used, max: MAX_CUSTOMER_CAPACITY, available, atCapacity: available === 0, occupants };
}

/**
 * Whether a NEW subscription (claim approval, direct grant, or gift-code
 * redemption) can be granted to `profileId` right now. A profile that
 * ALREADY occupies a slot (e.g. renewing/extending) is always allowed —
 * this only blocks genuinely NEW occupants once all 7 slots are taken.
 * Capacity is enforced here, at subscription-creation time — NOT
 * re-checked against the live count at every booking trigger (see header
 * comment: an already-active subscription implies its slot was valid
 * when granted; shrinking AUTOBOOK_CUSTOMER_CAPACITY later is an admin
 * decision to reconcile manually, not something that silently evicts
 * people mid-run).
 */
function hasCapacityFor(profilesDir, profileId, referenceDateISO = todayISO()) {
    const { used, max, occupants } = getCapacitySummary(profilesDir, referenceDateISO);
    if (occupants.some(o => o.id === String(profileId))) return true; // already occupying a slot — renewal, not new
    return used < max;
}

// ---- applying a subscription (shared by tools/grant_subscription.js AND
// the claims-approval flow in app/queue/orders.js — one code path for
// "give this profile access", whether triggered by a CLI command or an
// automated claim approval) --------------------------------------------

const PLAN_PRICES = { day_pass: 15, weekly: 30, biweekly: 55, monthly: 100 };

function addDays(isoDate, days) {
    const d = new Date(isoDate + 'T00:00:00Z');
    d.setUTCDate(d.getUTCDate() + days);
    return d.toISOString().slice(0, 10);
}

function addOneMonth(isoDate) {
    const d = new Date(isoDate + 'T00:00:00Z');
    d.setUTCMonth(d.getUTCMonth() + 1);
    return d.toISOString().slice(0, 10);
}

function computePlanExpiry(plan, startDate, customDays) {
    if (plan === 'custom') {
        if (!customDays || customDays <= 0) throw new Error('plan=custom requires a positive day count');
        return addDays(startDate, customDays);
    }
    if (plan === 'monthly') return addOneMonth(startDate);
    if (plan === 'day_pass') return startDate;
    if (plan === 'weekly') return addDays(startDate, 7);
    if (plan === 'biweekly') return addDays(startDate, 14);
    throw new Error(`Unknown plan "${plan}". Use one of: day_pass, weekly, biweekly, monthly, custom`);
}

/**
 * Writes a subscription block onto a profile — THE single place this
 * happens outside the one-time backfill script. Handles renewal-stacking
 * (extends from the existing expiry instead of today, if still active)
 * and the 7-slot capacity ceiling (refuses new occupants at capacity
 * unless forceCapacity is explicitly set).
 *
 * @throws if the profile doesn't exist, the plan is invalid, or capacity
 *   is full and forceCapacity wasn't passed.
 * @returns the new subscription record that was written.
 */
function applySubscription(profilesDir, profileId, {
    type = 'paid',
    plan,
    amountPaid,
    customDays,
    expiryDate: explicitExpiryDate,
    grantedBy = 'admin',
    reason = null,
    forceCapacity = false,
    dryRun = false,
} = {}) {
    const file = path.join(profilesDir, `${profileId}.yaml`);
    if (!fs.existsSync(file)) {
        throw new Error(`No profile YAML found for ${profileId}.`);
    }

    const profile = yaml.load(fs.readFileSync(file, 'utf8')) || {};
    const today = todayISO();

    let startDate = today;
    const existing = profile.subscription;
    if (existing && existing.expiry_date && existing.expiry_date >= today) {
        startDate = existing.expiry_date; // renewal — stack on top, never shorten paid time
    }

    // Normally the expiry is derived from `plan` (+ customDays for plan=custom).
    // An admin extending/correcting a specific profile from the panel can
    // instead pass an exact `expiryDate` directly, bypassing plan math
    // entirely — e.g. "just set this to 2026-10-01" rather than counting
    // days. `plan` still gets recorded (falls back to the existing plan,
    // or "custom") purely as a label; it plays no role in the date math
    // when expiryDate is given explicitly.
    let expiryDate;
    let resolvedPlan;
    if (explicitExpiryDate) {
        if (!/^\d{4}-\d{2}-\d{2}$/.test(explicitExpiryDate)) {
            throw new Error('expiryDate must be in YYYY-MM-DD format');
        }
        expiryDate = explicitExpiryDate;
        resolvedPlan = plan || (existing && existing.plan) || 'custom';
    } else {
        expiryDate = computePlanExpiry(plan, startDate, customDays);
        resolvedPlan = plan;
    }
    const amount = amountPaid !== undefined ? amountPaid : (PLAN_PRICES[resolvedPlan] ?? null);

    const capacity = getCapacitySummary(profilesDir);
    const alreadyOccupying = capacity.occupants.some(o => o.id === String(profileId));
    if (!alreadyOccupying && capacity.atCapacity && !forceCapacity) {
        throw new Error(`Capacity is full (${capacity.used}/${capacity.max}) and profile ${profileId} would be a NEW occupant. Pass forceCapacity to override.`);
    }

    const newSub = {
        type, plan: resolvedPlan, status: 'active',
        amount_paid: amount,
        start_date: startDate,
        expiry_date: expiryDate,
        granted_by: grantedBy,
        reason,
        note: null,
    };

    profile.subscription = newSub;
    if (!dryRun) {
        fs.writeFileSync(file, yaml.dump(profile, { lineWidth: -1 }));
    }
    return newSub;
}

module.exports = {
    MAX_CUSTOMER_CAPACITY,
    PLAN_PRICES,
    todayISO,
    isOperatorProfile,
    getOperatorProfileIds,
    resolveSubscriptionStatus,
    isSubscriptionActive,
    listCapacityOccupants,
    getCapacitySummary,
    hasCapacityFor,
    computePlanExpiry,
    applySubscription,
};