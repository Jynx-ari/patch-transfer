// Shared job queue. In-memory, single-process — matches the spec (section 20):
// no persistent queue needed unless crash recovery becomes a requirement.
//
// Priority policy (section 21): roundtrip jobs are preferred over one-way
// jobs, but within the same priority level jobs are FIFO, so a steady
// stream of roundtrips can never fully starve one-way jobs — a one-way job
// only waits behind roundtrips that were already queued before it, not
// ones that show up after.

class JobQueue {
    constructor() {
        this._jobs = [];
        this._waiters = [];
    }

    /** @param {object} job - see app/queue/job.js buildJob() for shape */
    enqueue(job) {
        this._jobs.push(job);
        this._jobs.sort((a, b) => {
            if (a.priorityRank !== b.priorityRank) return a.priorityRank - b.priorityRank;
            return a._seq - b._seq; // FIFO tiebreak, prevents starvation
        });
        this._drainWaiters();
    }

    /** Resolves with the next job once one is available. */
    async dequeue() {
        if (this._jobs.length > 0) {
            return this._jobs.shift();
        }
        return new Promise(resolve => this._waiters.push(resolve));
    }

    _drainWaiters() {
        while (this._waiters.length > 0 && this._jobs.length > 0) {
            const resolve = this._waiters.shift();
            resolve(this._jobs.shift());
        }
    }

    size() {
        return this._jobs.length;
    }

    /** Debug/testing helper — does not remove anything. */
    peekAll() {
        return [...this._jobs];
    }
}

// One shared queue per process, matching "Shared Queue" in the spec's
// architecture diagram — workers and the trigger server both import this
// same instance rather than each holding their own.
const sharedQueue = new JobQueue();

module.exports = { JobQueue, sharedQueue };
