// There's no real database in this project yet (profiles are YAML files,
// job outcomes are one-off result JSON files). This gives confirmed
// bookings a durable home that isn't "only in a Discord DM the user might
// delete" — profiles/<id>/bookings.json, a plain JSON array, append-only.
// If/when a real DB gets introduced, this is the one place that needs to
// change call sites for.

const fs = require('fs');
const path = require('path');

function bookingsFile(profileId, profilesDir) {
    return path.join(profilesDir, String(profileId), 'bookings.json');
}

/**
 * @param {string|number} profileId
 * @param {string} profilesDir
 * @param {object} record - e.g. { job_id, leg, date, bookingRef, successUrl, screenshot, submitted_at }
 */
function appendBooking(profileId, profilesDir, record) {
    const file = bookingsFile(profileId, profilesDir);
    let history = [];
    if (fs.existsSync(file)) {
        try {
            history = JSON.parse(fs.readFileSync(file, 'utf8'));
            if (!Array.isArray(history)) history = [];
        } catch {
            history = []; // corrupt file — don't crash the worker over a log
        }
    }
    history.push(record);
    fs.mkdirSync(path.dirname(file), { recursive: true });
    fs.writeFileSync(file, JSON.stringify(history, null, 2));
}

/**
 * Reads back this profile's bookings.json (append-only log written by
 * app/worker/worker.js after a real production submit) and returns the
 * set of legs ('morning' | 'afternoon') that already have a record for
 * `date`. Used as a pre-enqueue guard so a redeploy, a re-run trigger, or
 * a stray manual trigger for a date that's already been submitted can't
 * silently double-book someone — see app/queue/job.js's validateProfile().
 *
 * Deliberately ignores the `confirmed` flag: even an "uncertain, please
 * check" submission still means the site was actually clicked through,
 * so it's not safe to try again automatically either way. A human
 * clearing that up is a manual override, not something this guard
 * should second-guess.
 *
 * @param {string|number} profileId
 * @param {string} profilesDir
 * @param {string} date
 * @returns {Set<string>} legs already booked for this date, e.g. {'morning'}
 */
function getBookedLegsForDate(profileId, profilesDir, date) {
    const file = bookingsFile(profileId, profilesDir);
    if (!fs.existsSync(file)) return new Set();
    let history = [];
    try {
        history = JSON.parse(fs.readFileSync(file, 'utf8'));
        if (!Array.isArray(history)) history = [];
    } catch {
        return new Set(); // corrupt file — don't block booking over a log read failure
    }
    return new Set(
        history.filter(r => r && r.date === date && r.leg).map(r => r.leg)
    );
}

module.exports = { appendBooking, bookingsFile, getBookedLegsForDate };
