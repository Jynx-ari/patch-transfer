// Order/claim state machine — spec patch sections 4 (state machine) and
// 6 (fraud protection). Orders are stored as a single flat JSON array
// at profiles/_orders/orders.json — nested under profiles/ deliberately,
// same reasoning as app/queue/subscription.js's capacity logic and the
// booking-screenshot reorg: /app/profiles is already bind-mounted, so
// this rides along for free without a new mount. `_orders` can never
// collide with a real profile id (profile ids are Discord snowflakes,
// which are all-digit).
//
// Canonical state machine:
//
//   PENDING (claim reserved, awaiting payment)
//     -> PAYMENT_SUBMITTED (screenshot/reference submitted)
//     -> AWAITING_VERIFICATION (queued for operator review)
//     -> PAID (approved) -> ACTIVE (subscription applied)
//     -> REJECTED (operator declined)
//   PENDING -> RESERVATION_EXPIRED (payment window lapsed, no submission)
//
// PAYMENT_SUBMITTED and AWAITING_VERIFICATION are collapsed into one
// transition here (submitPayment() moves straight to
// AWAITING_VERIFICATION) since nothing in this system currently needs to
// observe the brief in-between moment — see spec section 4's own
// "PAYMENT_SUBMITTED ≠ PAYMENT_CONFIRMED" rule, which this preserves:
// nothing here ever grants access on submission alone, only on
// approveOrder().

const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { applySubscription, getCapacitySummary, todayISO } = require('./subscription');

const ORDERS_DIR = path.join(__dirname, '..', '..', 'profiles', '_orders');
const ORDERS_FILE = path.join(ORDERS_DIR, 'orders.json');

const DEFAULT_RESERVATION_WINDOW_MS = (parseInt(process.env.AUTOBOOK_CLAIM_WINDOW_MINUTES, 10) || 15) * 60_000;

// ---- storage ---------------------------------------------------------------

function loadOrders() {
    if (!fs.existsSync(ORDERS_FILE)) return [];
    try {
        const data = JSON.parse(fs.readFileSync(ORDERS_FILE, 'utf8'));
        return Array.isArray(data) ? data : [];
    } catch {
        return []; // corrupt file should never crash the whole claims system
    }
}

function saveOrders(orders) {
    fs.mkdirSync(ORDERS_DIR, { recursive: true });
    fs.writeFileSync(ORDERS_FILE, JSON.stringify(orders, null, 2));
}

function generateOrderId() {
    const date = todayISO().replace(/-/g, '');
    const suffix = crypto.randomBytes(3).toString('hex').toUpperCase().slice(0, 4);
    return `STELLA-${date}-${suffix}`;
}

function hashFile(filePath) {
    const buf = fs.readFileSync(filePath);
    return crypto.createHash('sha256').update(buf).digest('hex');
}

// ---- reads ------------------------------------------------------------------

function getOrder(orderId) {
    return loadOrders().find(o => o.order_id === orderId) || null;
}

function listOrdersByStatus(status) {
    return loadOrders().filter(o => o.status === status);
}

function listOrdersForProfile(profileId) {
    return loadOrders().filter(o => o.profile_id === String(profileId));
}

// ---- fraud checks (spec section 6.2) ----------------------------------------

/**
 * Reference-reuse block: true if `referenceNumber` is already attached
 * to a PAID order (any profile). Only ever checked against PAID orders —
 * a reference tied to a rejected/expired claim was never a real payment
 * match, so it must stay reusable.
 */
function isReferenceReused(referenceNumber) {
    if (!referenceNumber) return false;
    return loadOrders().some(o => o.status === 'PAID' && o.payment_reference === referenceNumber);
}

/**
 * Screenshot image-hash dedup: true if this exact screenshot file
 * (by content hash) is already attached to a PAID order. Catches the
 * laziest fraud (resubmitting the same screenshot) independent of
 * whether a reference number was given at all.
 */
function isScreenshotReused(screenshotHash) {
    if (!screenshotHash) return false;
    return loadOrders().some(o => o.status === 'PAID' && o.screenshot_hash === screenshotHash);
}

// ---- state transitions -------------------------------------------------------

/**
 * Step 1 — customer claims a plan. Reserves a capacity slot for
 * AUTOBOOK_CLAIM_WINDOW_MINUTES (default 15). Spec section 5.2: only one
 * PENDING/AWAITING_VERIFICATION claim per profile at a time, and only
 * one claim can occupy "the" open slot when the profile isn't already a
 * subscriber — first claim wins, no ordered queue.
 */
function createClaim(profilesDir, profileId, plan, amountExpected) {
    const orders = loadOrders();

    const alreadyClaiming = orders.find(o =>
        o.profile_id === String(profileId) &&
        ['PENDING', 'AWAITING_VERIFICATION'].includes(o.status)
    );
    if (alreadyClaiming) {
        throw new Error(`Profile ${profileId} already has an in-progress claim (${alreadyClaiming.order_id}, status ${alreadyClaiming.status}).`);
    }

    const capacity = getCapacitySummary(profilesDir);
    const alreadyOccupying = capacity.occupants.some(o => o.id === String(profileId));
    const reservedByOtherClaims = orders.filter(o =>
        ['PENDING', 'AWAITING_VERIFICATION'].includes(o.status) && o.profile_id !== String(profileId)
    ).length;
    if (!alreadyOccupying && (capacity.used + reservedByOtherClaims) >= capacity.max) {
        throw new Error(`No capacity available right now (${capacity.used}/${capacity.max}, plus ${reservedByOtherClaims} other pending claim(s)).`);
    }

    const now = Date.now();
    const order = {
        order_id: generateOrderId(),
        profile_id: String(profileId),
        plan,
        amount_expected: amountExpected,
        status: 'PENDING',
        created_at: new Date(now).toISOString(),
        reservation_expires_at: new Date(now + DEFAULT_RESERVATION_WINDOW_MS).toISOString(),
        payment_submitted_at: null,
        screenshot_path: null,
        screenshot_hash: null,
        payment_reference: null,
        verification_status: null,
        verified_by: null,
        verified_at: null,
        rejection_reason: null,
        activated_at: null,
    };
    orders.push(order);
    saveOrders(orders);
    return order;
}

/**
 * Step 2 — customer submits payment proof. Runs BOTH fraud checks before
 * accepting (spec 6.2) — a reused reference or an exact-duplicate
 * screenshot is rejected outright, never even reaching
 * AWAITING_VERIFICATION for a human to look at.
 */
function submitPayment(orderId, { screenshotPath, referenceNumber }) {
    if (!screenshotPath) throw new Error('A screenshot is required (spec section 6.1) — reference number alone is not accepted as proof.');

    const orders = loadOrders();
    const order = orders.find(o => o.order_id === orderId);
    if (!order) throw new Error(`No such order ${orderId}.`);
    if (order.status !== 'PENDING') throw new Error(`Order ${orderId} is ${order.status}, not PENDING — cannot submit payment.`);
    if (new Date(order.reservation_expires_at).getTime() < Date.now()) {
        order.status = 'RESERVATION_EXPIRED';
        saveOrders(orders);
        throw new Error(`Order ${orderId}'s reservation window expired before payment was submitted.`);
    }

    const screenshotHash = fs.existsSync(screenshotPath) ? hashFile(screenshotPath) : null;

    if (referenceNumber && isReferenceReused(referenceNumber)) {
        throw new Error('This payment reference has already been used on a confirmed order. If you believe this is an error, contact the operator directly.');
    }
    if (screenshotHash && isScreenshotReused(screenshotHash)) {
        throw new Error('This screenshot has already been used on a confirmed order. If you believe this is an error, contact the operator directly.');
    }

    order.status = 'AWAITING_VERIFICATION';
    order.payment_submitted_at = new Date().toISOString();
    order.screenshot_path = screenshotPath;
    order.screenshot_hash = screenshotHash;
    order.payment_reference = referenceNumber || null;
    saveOrders(orders);
    return order;
}

/**
 * Step 3a — operator approves. This is the ONLY place a claim actually
 * grants access — see the module header's "PAYMENT_SUBMITTED ≠
 * PAYMENT_CONFIRMED" note. Calls the exact same applySubscription() the
 * CLI grant tool uses (one code path).
 */
function approveOrder(profilesDir, orderId, verifiedBy) {
    const orders = loadOrders();
    const order = orders.find(o => o.order_id === orderId);
    if (!order) throw new Error(`No such order ${orderId}.`);
    if (order.status !== 'AWAITING_VERIFICATION') throw new Error(`Order ${orderId} is ${order.status}, not AWAITING_VERIFICATION — cannot approve.`);

    // Applied BEFORE flipping the order to PAID, so if applySubscription
    // throws (e.g. a capacity race), the order stays AWAITING_VERIFICATION
    // rather than silently ending up PAID with no actual subscription.
    applySubscription(profilesDir, order.profile_id, {
        type: 'paid',
        plan: order.plan,
        amountPaid: order.amount_expected,
        grantedBy: `order:${order.order_id}`,
        reason: `Approved by ${verifiedBy}`,
    });

    order.status = 'PAID';
    order.verified_by = verifiedBy;
    order.verified_at = new Date().toISOString();
    order.activated_at = new Date().toISOString();
    saveOrders(orders);
    return order;
}

/** Step 3b — operator rejects. Releases the reservation; capacity opens back up. */
function rejectOrder(orderId, verifiedBy, reason) {
    const orders = loadOrders();
    const order = orders.find(o => o.order_id === orderId);
    if (!order) throw new Error(`No such order ${orderId}.`);
    if (order.status !== 'AWAITING_VERIFICATION') throw new Error(`Order ${orderId} is ${order.status}, not AWAITING_VERIFICATION — cannot reject.`);

    order.status = 'REJECTED';
    order.verified_by = verifiedBy;
    order.verified_at = new Date().toISOString();
    order.rejection_reason = reason || null;
    saveOrders(orders);
    return order;
}

/**
 * Sweep for stale reservations — no payment submitted within the
 * window. Safe to call on any schedule (cron, or just at the top of
 * every admin-panel claims-queue fetch); idempotent, only ever touches
 * PENDING orders past their own expiry.
 */
function expireStaleReservations() {
    const orders = loadOrders();
    const now = Date.now();
    let changed = 0;
    for (const order of orders) {
        if (order.status === 'PENDING' && new Date(order.reservation_expires_at).getTime() < now) {
            order.status = 'RESERVATION_EXPIRED';
            changed += 1;
        }
    }
    if (changed > 0) saveOrders(orders);
    return changed;
}

module.exports = {
    ORDERS_FILE,
    loadOrders,
    getOrder,
    listOrdersByStatus,
    listOrdersForProfile,
    isReferenceReused,
    isScreenshotReused,
    hashFile,
    createClaim,
    submitPayment,
    approveOrder,
    rejectOrder,
    expireStaleReservations,
};
