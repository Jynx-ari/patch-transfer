// Admin panel server — Express-based (migrated from raw http; the panel
// grew from "lock/unlock + profile list" to a full multi-section
// dashboard — Claims Queue, Subscriptions, screenshot browsing — and
// hand-rolling routing/parsing for every new endpoint stopped being
// worth it. Same auth model as before: one shared admin password,
// stateless HMAC-signed session cookie, no database, no per-account
// login (there's one admin).
//
// Put this behind Cloudflare Tunnel on its own subdomain, same as
// app/webserver/signature_server.js.

const express = require('express');
const fs = require('fs');
const os = require('os');
const path = require('path');
const crypto = require('crypto');
const yaml = require('js-yaml');
const { spawn } = require('child_process');

const { installFileLogging, LOG_DIR } = require('../lib/logTee');
installFileLogging('admin'); // tees this process's own console.log/warn/error to logs/admin.log

const {
    checkRequirements,
    hasAnyEnabledDay,
    hasSignature,
    hasCredentials,
    isProfileActive,
    isProfileLocked,
    DAY_KEYS,
} = require('../queue/requirements');
const { bookingsFile } = require('../queue/bookingLog');
const {
    MAX_CUSTOMER_CAPACITY,
    resolveSubscriptionStatus,
    isOperatorProfile,
    getOperatorProfileIds,
    getCapacitySummary,
    applySubscription,
} = require('../queue/subscription');
const orders = require('../queue/orders');

const PROFILES_DIR = path.join(__dirname, '..', '..', 'profiles');
const LOGIN_HTML_PATH = path.join(__dirname, '..', '..', 'tools', 'admin_login.html');
const DASHBOARD_HTML_PATH = path.join(__dirname, '..', '..', 'tools', 'admin_dashboard.html');

const PROJECT_ROOT = path.join(__dirname, '..', '..');
const PORT = parseInt(process.env.AUTOBOOK_ADMIN_PORT, 10) || 4792;
const HOST = process.env.AUTOBOOK_ADMIN_HOST || '0.0.0.0';
const PASSWORD = process.env.AUTOBOOK_ADMIN_PASSWORD || '';
const SESSION_SECRET = process.env.AUTOBOOK_ADMIN_SESSION_SECRET || '';
const SESSION_TTL_MS = (parseInt(process.env.AUTOBOOK_ADMIN_SESSION_TTL_HOURS, 10) || 12) * 3600_000;
const IDLE_TIMEOUT_MS = (parseInt(process.env.AUTOBOOK_ADMIN_IDLE_TIMEOUT_MINUTES, 10) || 15) * 60_000;

const COOKIE_NAME = 'autobook_admin_session';

// ---- auth helpers ---------------------------------------------------------

// nonce -> last-seen timestamp. This is what makes the idle timeout REAL
// rather than just a client-side JS trick: the admin session cookie's own
// expiresAt is an absolute ceiling (SESSION_TTL_MS, e.g. 12h) set once at
// login and baked into the signed cookie, so it can't shrink on its own.
// To actually log someone out after N minutes of no activity — even if
// they never touch the "Log out" button and the tab is just left open —
// the server has to track activity itself and reject an otherwise
// still-valid, still-correctly-signed cookie once it's gone idle too
// long. In-memory/per-process, like the rest of this panel's session
// state — resets on restart, which just means "everyone gets a fresh
// idle clock," not a security hole.
const adminSessionActivity = new Map();

function safeEqual(a, b) {
    const bufA = Buffer.from(String(a));
    const bufB = Buffer.from(String(b));
    if (bufA.length !== bufB.length) return false;
    return crypto.timingSafeEqual(bufA, bufB);
}

function signSession(expiresAt, nonce) {
    return crypto.createHmac('sha256', SESSION_SECRET).update(`admin:${expiresAt}:${nonce}`).digest('hex');
}

function makeSessionCookieValue() {
    const expiresAt = Date.now() + SESSION_TTL_MS;
    const nonce = crypto.randomBytes(12).toString('hex');
    adminSessionActivity.set(nonce, Date.now());
    return { value: `${expiresAt}.${nonce}.${signSession(expiresAt, nonce)}`, expiresAt };
}

/** @returns the session nonce if valid AND not idle-expired, else null. */
function verifySessionCookie(cookieValue) {
    if (!cookieValue) return null;
    const [expiresAtStr, nonce, sig] = cookieValue.split('.');
    if (!expiresAtStr || !nonce || !sig) return null;
    const expiresAt = parseInt(expiresAtStr, 10);
    if (!Number.isFinite(expiresAt) || Date.now() > expiresAt) return null; // absolute ceiling
    if (!safeEqual(sig, signSession(expiresAt, nonce))) return null;
    const lastSeen = adminSessionActivity.get(nonce);
    if (lastSeen === null) return null; // explicitly revoked below — must stay revoked, never re-treated as "fresh"
    // lastSeen === undefined happens right after a server restart (the
    // Map is empty but the cookie is still validly signed) — treat that
    // as "not idle yet" rather than force everyone to re-login on every
    // deploy; the idle clock starts fresh from here.
    if (lastSeen !== undefined && Date.now() - lastSeen > IDLE_TIMEOUT_MS) {
        adminSessionActivity.set(nonce, null); // revoke — NOT delete(): deleting would make the very next
        return null;                           // check see `undefined` again and treat this cookie as fresh
    }
    adminSessionActivity.set(nonce, Date.now()); // touch — sliding window
    return nonce;
}

function parseCookies(req) {
    const header = req.headers.cookie || '';
    const out = {};
    header.split(';').forEach(part => {
        const idx = part.indexOf('=');
        if (idx === -1) return;
        out[part.slice(0, idx).trim()] = decodeURIComponent(part.slice(idx + 1).trim());
    });
    return out;
}

function requireAuth(req, res, next) {
    const cookies = parseCookies(req);
    if (verifySessionCookie(cookies[COOKIE_NAME])) return next();
    if (req.method === 'GET' && !req.path.startsWith('/api/') && !req.path.startsWith('/screenshots/')) {
        return res.redirect('/login?reason=idle');
    }
    return res.status(401).json({ ok: false, error: 'Not logged in' });
}

// ---- console (full shell) — a SECOND, independent password on top of the
// admin login above. A leaked admin session should not, by itself, be
// enough to get a shell on the host. Deliberately its own short-lived
// cookie/secret/session rather than reusing the admin one, so unlocking
// the console can't be forged just by having a valid admin cookie, and a
// console session expires (default 15 min) much sooner than the admin
// session does. Every command that actually runs is written to
// logs/admin.log (via the existing console.log tee) so there's a trail of
// what was run, when, from where. -----------------------------------------

const CONSOLE_PASSWORD = process.env.AUTOBOOK_CONSOLE_PASSWORD || '';
const CONSOLE_SESSION_SECRET = process.env.AUTOBOOK_CONSOLE_SESSION_SECRET || SESSION_SECRET;
const CONSOLE_SESSION_TTL_MS = (parseInt(process.env.AUTOBOOK_CONSOLE_SESSION_TTL_MINUTES, 10) || 15) * 60_000;
const CONSOLE_COMMAND_TIMEOUT_MS = (parseInt(process.env.AUTOBOOK_CONSOLE_COMMAND_TIMEOUT_SECONDS, 10) || 60) * 1000;
const CONSOLE_MAX_OUTPUT_BYTES = 200_000;
const CONSOLE_COOKIE_NAME = 'autobook_console_session';

// profileId -> { count, resetAt } — deliberately in-memory/per-process
// (resets on restart), same tradeoff as the rest of this panel's "no
// database" design. Good enough to blunt online guessing, not meant to
// survive a distributed attack.
const consoleUnlockAttempts = new Map();
const CONSOLE_MAX_ATTEMPTS = 5;
const CONSOLE_LOCKOUT_WINDOW_MS = 15 * 60_000;

// sessionId -> { cwd } — the working directory a console session's `cd`
// commands have accumulated, since each executed command is its own
// short-lived child process and can't otherwise "remember" a directory
// change the way a real interactive shell would.
const consoleSessionState = new Map();

function consoleRateLimited(key) {
    const entry = consoleUnlockAttempts.get(key);
    if (!entry) return false;
    if (Date.now() > entry.resetAt) { consoleUnlockAttempts.delete(key); return false; }
    return entry.count >= CONSOLE_MAX_ATTEMPTS;
}
function recordConsoleFailure(key) {
    const entry = consoleUnlockAttempts.get(key);
    if (!entry || Date.now() > entry.resetAt) {
        consoleUnlockAttempts.set(key, { count: 1, resetAt: Date.now() + CONSOLE_LOCKOUT_WINDOW_MS });
    } else {
        entry.count += 1;
    }
}
function clearConsoleFailures(key) {
    consoleUnlockAttempts.delete(key);
}

function signConsoleSession(expiresAt, nonce) {
    return crypto.createHmac('sha256', CONSOLE_SESSION_SECRET).update(`console:${expiresAt}:${nonce}`).digest('hex');
}
function makeConsoleCookieValue() {
    const expiresAt = Date.now() + CONSOLE_SESSION_TTL_MS;
    const nonce = crypto.randomBytes(12).toString('hex');
    const sig = signConsoleSession(expiresAt, nonce);
    consoleSessionState.set(nonce, { cwd: PROJECT_ROOT });
    return { value: `${expiresAt}.${nonce}.${sig}`, expiresAt, nonce };
}
/**
 * Unlike verifySessionCookie, a well-signed-but-never-seen nonce here is
 * NOT treated as valid — every console cookie must trace back to an actual
 * /api/console/unlock call that populated consoleSessionState. That means
 * a server restart forces re-entry of the console password (no "grace"
 * window), which is the right tradeoff for shell access: stricter than
 * the main admin session on purpose. It also closes the replay hole that
 * existed here before — explicitly revoking (Lock console, or idle/log
 * out) now actually invalidates the token instead of merely asking the
 * browser to forget it.
 */
function verifyConsoleCookie(cookieValue) {
    if (!cookieValue) return null;
    const [expiresAtStr, nonce, sig] = cookieValue.split('.');
    if (!expiresAtStr || !nonce || !sig) return null;
    const expiresAt = parseInt(expiresAtStr, 10);
    if (!Number.isFinite(expiresAt) || Date.now() > expiresAt) return null;
    if (!safeEqual(sig, signConsoleSession(expiresAt, nonce))) return null;
    const state = consoleSessionState.get(nonce);
    if (!state) return null; // never issued, already revoked, or server restarted since — all fail closed
    return nonce;
}

/** Applied only to /api/console/* routes past unlock/status — requires BOTH the admin cookie (via requireAuth, already applied globally) AND a valid, unexpired console cookie. */
function requireConsoleAuth(req, res, next) {
    const nonce = verifyConsoleCookie(parseCookies(req)[CONSOLE_COOKIE_NAME]);
    if (!nonce) return res.status(403).json({ ok: false, error: 'Console is locked.', needsConsolePassword: true });
    req.consoleSessionId = nonce;
    next();
}

// ---- profile helpers --------------------------------------------------------

function isValidProfileId(id) {
    return /^\d{5,25}$/.test(String(id)); // Discord snowflake — also blocks path traversal via the id param
}

/**
 * A single safe path segment — for URL params that name a real thing on
 * disk (a date folder, a filename) whose exact shape we don't want to
 * over-constrain, but which must never be able to escape the directory
 * it's joined into. Blocks the only things that actually matter for
 * traversal (`/`, `\`, null bytes, `.` / `..`) and leaves everything else
 * — spaces, commas, whatever a date label happens to look like — alone.
 */
function isSafePathSegment(s) {
    return typeof s === 'string' && s.length > 0 && s.length < 200 &&
        !s.includes('/') && !s.includes('\\') && !s.includes('\0') &&
        s !== '.' && s !== '..';
}

function profilePath(profileId) {
    if (!isValidProfileId(profileId)) return null;
    return path.join(PROFILES_DIR, `${profileId}.yaml`);
}

function loadProfile(profileId) {
    const p = profilePath(profileId);
    if (!p || !fs.existsSync(p)) return null;
    return yaml.load(fs.readFileSync(p, 'utf8')) || {};
}

function saveProfile(profileId, profile) {
    const p = profilePath(profileId);
    if (!p) throw new Error('invalid profile id');
    fs.writeFileSync(p, yaml.dump(profile, { lineWidth: -1 }));
}

function bookingsCount(profileId) {
    try {
        const file = bookingsFile(profileId, PROFILES_DIR);
        if (!fs.existsSync(file)) return 0;
        const history = JSON.parse(fs.readFileSync(file, 'utf8'));
        return Array.isArray(history) ? history.length : 0;
    } catch {
        return 0;
    }
}

/**
 * Booking schedule for the profile overview page — the actual days/times/
 * origin+dropoff, so a booking that misfires (or doesn't fire) can be
 * checked against what's actually configured without opening the YAML by
 * hand. Supports both the current nested per-day schema
 * (booking.<day>.enabled/mode/morning/afternoon) and the older flat schema
 * (booking.mode/morning/afternoon directly, no per-day nesting) that
 * hasAnyEnabledDay() above also still falls back to.
 */
function buildScheduleSummary(profile) {
    const booking = profile && profile.booking;
    if (!booking) return [];

    const legSummary = (leg) => leg && (leg.origin || leg.dropoff || leg.time)
        ? { origin: leg.origin || null, dropoff: leg.dropoff || null, time: leg.time || null }
        : null;

    const nestedDays = DAY_KEYS
        .filter(day => booking[day])
        .map(day => ({
            day,
            enabled: !!booking[day].enabled,
            mode: booking[day].mode || null,
            morning: legSummary(booking[day].morning),
            afternoon: legSummary(booking[day].afternoon),
        }));
    if (nestedDays.length) return nestedDays;

    // Flat/legacy schema fallback — one entry, no specific weekday attached.
    if (booking.mode) {
        return [{
            day: null,
            enabled: true, // flat-schema profiles have no separate enabled flag — presence of a mode means configured
            mode: booking.mode,
            morning: legSummary(booking.morning),
            afternoon: legSummary(booking.afternoon),
        }];
    }
    return [];
}

function listProfileSummaries() {
    if (!fs.existsSync(PROFILES_DIR)) return [];
    return fs.readdirSync(PROFILES_DIR)
        .filter(f => f.endsWith('.yaml'))
        .map(f => {
            const id = f.replace(/\.yaml$/, '');
            const profile = loadProfile(id);
            if (!profile) return null;
            const { ready, missing } = checkRequirements(id, profile, PROFILES_DIR);
            const sub = profile.subscription || null;
            return {
                id,
                name: profile.name || null,
                active: isProfileActive(profile),
                locked: isProfileLocked(profile),
                lockedReason: profile.locked_reason || null,
                lockedBy: profile.locked_by || null,
                lockedAt: profile.locked_at || null,
                configured: hasAnyEnabledDay(profile),
                schedule: buildScheduleSummary(profile),
                hasSignature: hasSignature(id, PROFILES_DIR),
                hasCredentials: hasCredentials(id, PROFILES_DIR),
                ready,
                missing,
                bookingsCount: bookingsCount(id),
                isOperator: isOperatorProfile(id),
                subscription: sub && {
                    type: sub.type || null,
                    plan: sub.plan || null,
                    status: resolveSubscriptionStatus(profile),
                    startDate: sub.start_date || null,
                    expiryDate: sub.expiry_date || null,
                    amountPaid: sub.amount_paid ?? null,
                    grantedBy: sub.granted_by || null,
                    reason: sub.reason || null,
                },
            };
        })
        .filter(Boolean)
        .sort((a, b) => (a.name || a.id).localeCompare(b.name || b.id));
}

// ---- booking-screenshot browsing ---------------------------------------------

/** profiles/{id}/booking-screenshots/{date}/{leg}_{kind}_{ts}.png — see tools/dry_run_booking.js's buildScreenshotPath(). */
function listBookingScreenshots(profileId) {
    if (!isValidProfileId(profileId)) return [];
    const root = path.join(PROFILES_DIR, String(profileId), 'booking-screenshots');
    if (!fs.existsSync(root)) return [];
    const out = [];
    for (const date of fs.readdirSync(root)) {
        const dateDir = path.join(root, date);
        if (!fs.statSync(dateDir).isDirectory()) continue;
        for (const filename of fs.readdirSync(dateDir)) {
            if (!filename.endsWith('.png')) continue;
            const [leg, kind] = filename.split('_');
            out.push({ date, leg, kind, filename, url: `/screenshots/${profileId}/${encodeURIComponent(date)}/${encodeURIComponent(filename)}` });
        }
    }
    return out.sort((a, b) => (a.date < b.date ? 1 : a.date > b.date ? -1 : 0));
}

// ---- booking history (per-profile bookings.json) -----------------------------

/** profiles/{id}/bookings.json — see app/queue/bookingLog.js. Newest first. */
function listBookingHistory(profileId) {
    if (!isValidProfileId(profileId)) return [];
    const file = bookingsFile(profileId, PROFILES_DIR);
    if (!fs.existsSync(file)) return [];
    try {
        const history = JSON.parse(fs.readFileSync(file, 'utf8'));
        if (!Array.isArray(history)) return [];
        return [...history].reverse();
    } catch {
        return [];
    }
}

// ---- system / settings (read-only) --------------------------------------------

function getSystemHealth() {
    const health = {
        nodeVersion: process.version,
        platform: `${os.platform()} ${os.release()}`,
        uptimeSeconds: Math.floor(process.uptime()),
        hostUptimeSeconds: Math.floor(os.uptime()),
        loadAverage: os.loadavg(),
        disk: null,
    };
    try {
        const stats = fs.statfsSync(PROFILES_DIR);
        const totalBytes = stats.blocks * stats.bsize;
        const freeBytes = stats.bfree * stats.bsize;
        const availBytes = stats.bavail * stats.bsize;
        health.disk = {
            totalBytes,
            freeBytes,
            usedBytes: totalBytes - freeBytes,
            availableBytes: availBytes,
        };
    } catch (e) {
        health.diskError = e.message;
    }
    return health;
}

function getSettingsSummary() {
    return {
        timezone: process.env.AUTOBOOK_TIMEZONE || 'Asia/Manila',
        customerCapacity: MAX_CUSTOMER_CAPACITY,
        claimWindowMinutes: parseInt(process.env.AUTOBOOK_CLAIM_WINDOW_MINUTES, 10) || 15,
        adminSessionTtlHours: parseInt(process.env.AUTOBOOK_ADMIN_SESSION_TTL_HOURS, 10) || 12,
        idleTimeoutMinutes: Math.round(IDLE_TIMEOUT_MS / 60000),
        workerCount: parseInt(process.env.AUTOBOOK_WORKER_COUNT, 10) || 2,
        operatorProfileIds: Array.from(getOperatorProfileIds()),
        adminPort: PORT,
    };
}

// ---- logs (beautified view over logs/<component>.log, written by app/lib/logTee.js) --

const LOG_COMPONENTS = ['admin', 'worker', 'trigger', 'signature'];
const LOG_LINE_RE = /^(\S+) \[(INFO|WARN|ERROR)\] \[(\w+)\] ([\s\S]*)$/;

/**
 * Parses logs/<component>.log into structured entries, newest first.
 * Lines that don't start with a timestamp (e.g. the rest of a multi-line
 * stack trace) are folded into the previous entry's message rather than
 * treated as their own malformed entry.
 */
function readLogFile(component, limit = 200) {
    if (!LOG_COMPONENTS.includes(component)) return [];
    const file = path.join(LOG_DIR, `${component}.log`);
    if (!fs.existsSync(file)) return [];
    let raw;
    try {
        raw = fs.readFileSync(file, 'utf8');
    } catch {
        return [];
    }
    const lines = raw.split('\n');
    const entries = [];
    for (const line of lines) {
        if (!line) continue;
        const m = line.match(LOG_LINE_RE);
        if (m) {
            entries.push({ ts: m[1], level: m[2], component: m[3], message: m[4] });
        } else if (entries.length > 0) {
            entries[entries.length - 1].message += `\n${line}`;
        }
    }
    return entries.reverse().slice(0, limit);
}

// ---- console command execution ------------------------------------------

const CD_RE = /^\s*cd(?:\s+(.*))?\s*$/;

/**
 * Runs one command against a console session's tracked cwd. `cd` is
 * intercepted and handled in-process (a spawned child can't change the
 * parent's directory for next time) — everything else goes through
 * `/bin/sh -c` so the usual shell features (pipes, &&, redirects, globs)
 * work as expected.
 */
function runConsoleCommand(sessionId, command) {
    const state = consoleSessionState.get(sessionId) || { cwd: PROJECT_ROOT };
    consoleSessionState.set(sessionId, state);

    const cdMatch = command.match(CD_RE);
    if (cdMatch) {
        const target = (cdMatch[1] || '').trim() || PROJECT_ROOT;
        const resolved = path.resolve(state.cwd, target.replace(/^~(?=$|\/)/, PROJECT_ROOT));
        if (!fs.existsSync(resolved) || !fs.statSync(resolved).isDirectory()) {
            return Promise.resolve({ stdout: '', stderr: `cd: no such directory: ${target}`, exitCode: 1, cwd: state.cwd, timedOut: false });
        }
        state.cwd = resolved;
        return Promise.resolve({ stdout: '', stderr: '', exitCode: 0, cwd: state.cwd, timedOut: false });
    }

    return new Promise((resolve) => {
        // detached:true puts the shell in its own process group, so on
        // timeout we can kill(-pid) to take the WHOLE group with it —
        // plain child.kill() only signals the /bin/sh process itself and
        // leaves whatever it actually forked (e.g. `sleep 10`) running
        // to completion, which defeats the point of a timeout.
        const child = spawn('/bin/sh', ['-c', command], { cwd: state.cwd, env: process.env, detached: true });
        let stdout = '', stderr = '', bytes = 0, timedOut = false, truncated = false;

        const timer = setTimeout(() => {
            timedOut = true;
            try { process.kill(-child.pid, 'SIGKILL'); } catch { try { child.kill('SIGKILL'); } catch { /* already gone */ } }
        }, CONSOLE_COMMAND_TIMEOUT_MS);

        function collect(chunk, which) {
            bytes += chunk.length;
            if (bytes > CONSOLE_MAX_OUTPUT_BYTES) {
                if (!truncated) { truncated = true; stderr += '\n[output truncated — exceeded 200KB]'; }
                return;
            }
            if (which === 'out') stdout += chunk; else stderr += chunk;
        }
        child.stdout.on('data', d => collect(d.toString(), 'out'));
        child.stderr.on('data', d => collect(d.toString(), 'err'));
        child.on('close', (code) => {
            clearTimeout(timer);
            resolve({ stdout, stderr, exitCode: timedOut ? null : code, cwd: state.cwd, timedOut });
        });
        child.on('error', (err) => {
            clearTimeout(timer);
            resolve({ stdout, stderr: `${stderr}\n${err.message}`, exitCode: 1, cwd: state.cwd, timedOut: false });
        });
    });
}

// ---- claims/orders ------------------------------------------------------------

function serializeOrder(order) {
    const profile = loadProfile(order.profile_id);
    return {
        ...order,
        profileName: profile?.name || null,
        screenshotUrl: order.screenshot_path && fs.existsSync(order.screenshot_path)
            ? `/claim-screenshots/${encodeURIComponent(order.order_id)}`
            : null,
    };
}

// ---- route handlers ----------------------------------------------------------

async function handleLogin(req, res) {
    const provided = (req.body && req.body.password) || '';
    if (!PASSWORD) return res.status(503).json({ ok: false, error: 'Admin panel misconfigured — AUTOBOOK_ADMIN_PASSWORD not set.' });
    if (!provided || !safeEqual(provided, PASSWORD)) {
        console.warn(`Admin login rejected from ${req.ip}`);
        return res.status(401).json({ ok: false, error: 'Wrong password.' });
    }
    const { value, expiresAt } = makeSessionCookieValue();
    res.setHeader('Set-Cookie', `${COOKIE_NAME}=${encodeURIComponent(value)}; HttpOnly; Path=/; SameSite=Lax; Max-Age=${Math.floor((expiresAt - Date.now()) / 1000)}`);
    res.json({ ok: true });
}

function handleLogout(req, res) {
    const [, nonce] = (parseCookies(req)[COOKIE_NAME] || '').split('.');
    if (nonce) adminSessionActivity.set(nonce, null); // revoke, don't delete — see verifySessionCookie's comment on why
    res.setHeader('Set-Cookie', `${COOKIE_NAME}=; HttpOnly; Path=/; SameSite=Lax; Max-Age=0`);
    const reason = req.query && req.query.reason === 'idle' ? '?reason=idle' : '';
    res.redirect(`/login${reason}`);
}

// ---- server ------------------------------------------------------------------

function startAdminServer() {
    if (!PASSWORD || !SESSION_SECRET) {
        console.warn('WARNING: AUTOBOOK_ADMIN_PASSWORD and/or AUTOBOOK_ADMIN_SESSION_SECRET is not set. The admin panel will refuse all logins until both are set in autobook/.env.');
    }

    const app = express();
    app.use(express.json({ limit: '20kb' }));
    app.disable('x-powered-by');

    // ---- public routes ----
    app.get('/login', (req, res) => res.sendFile(LOGIN_HTML_PATH));
    app.post('/login', (req, res, next) => handleLogin(req, res).catch(next));
    app.get('/logout', handleLogout);

    // ---- everything past here requires a session ----
    app.use(requireAuth);

    app.get('/', (req, res) => res.sendFile(DASHBOARD_HTML_PATH));

    app.get('/api/profiles', (req, res) => {
        res.json({ ok: true, profiles: listProfileSummaries() });
    });

    app.get('/api/capacity', (req, res) => {
        res.json({ ok: true, capacity: getCapacitySummary(PROFILES_DIR) });
    });

    app.post('/api/profiles/:id/lock', (req, res) => {
        const profile = loadProfile(req.params.id);
        if (!profile) return res.status(404).json({ ok: false, error: 'Profile not found' });
        const reason = typeof req.body?.reason === 'string' ? req.body.reason.slice(0, 300) : null;
        profile.locked = true;
        profile.locked_reason = reason || null;
        profile.locked_by = 'admin panel';
        profile.locked_at = new Date().toISOString();
        saveProfile(req.params.id, profile);
        console.log(`Admin panel: locked profile ${req.params.id}${reason ? ` (${reason})` : ''}`);
        res.json({ ok: true });
    });

    app.post('/api/profiles/:id/unlock', (req, res) => {
        const profile = loadProfile(req.params.id);
        if (!profile) return res.status(404).json({ ok: false, error: 'Profile not found' });
        profile.locked = false;
        profile.locked_reason = null;
        profile.locked_by = null;
        profile.locked_at = null;
        saveProfile(req.params.id, profile);
        console.log(`Admin panel: unlocked profile ${req.params.id}`);
        res.json({ ok: true });
    });

    // ---- subscriptions / grants ----

    app.post('/api/profiles/:id/grant', (req, res) => {
        const { type = 'paid', plan, amountPaid, customDays, expiryDate, reason, forceCapacity } = req.body || {};
        try {
            const sub = applySubscription(PROFILES_DIR, req.params.id, {
                type, plan, amountPaid, customDays, expiryDate, reason,
                grantedBy: 'admin panel', forceCapacity: !!forceCapacity,
            });
            console.log(`Admin panel: granted ${plan || '(exact date)'} (${type}) to ${req.params.id}, now expires ${sub.expiry_date}`);
            res.json({ ok: true, subscription: sub });
        } catch (e) {
            res.status(400).json({ ok: false, error: e.message });
        }
    });

    // ---- claims queue ----

    app.get('/api/claims', (req, res) => {
        orders.expireStaleReservations();
        const status = req.query.status || 'AWAITING_VERIFICATION';
        const list = status === 'all' ? orders.loadOrders() : orders.listOrdersByStatus(status);
        res.json({ ok: true, claims: list.map(serializeOrder) });
    });

    app.post('/api/profiles/:id/claims', (req, res) => {
        const { plan, amountExpected } = req.body || {};
        try {
            const claim = orders.createClaim(PROFILES_DIR, req.params.id, plan, amountExpected);
            res.json({ ok: true, claim: serializeOrder(claim) });
        } catch (e) {
            res.status(400).json({ ok: false, error: e.message });
        }
    });

    app.post('/api/claims/:orderId/approve', (req, res) => {
        try {
            const order = orders.approveOrder(PROFILES_DIR, req.params.orderId, 'admin panel');
            console.log(`Admin panel: approved claim ${req.params.orderId}`);
            res.json({ ok: true, claim: serializeOrder(order) });
        } catch (e) {
            res.status(400).json({ ok: false, error: e.message });
        }
    });

    app.post('/api/claims/:orderId/reject', (req, res) => {
        try {
            const order = orders.rejectOrder(req.params.orderId, 'admin panel', req.body?.reason);
            console.log(`Admin panel: rejected claim ${req.params.orderId}${req.body?.reason ? ` (${req.body.reason})` : ''}`);
            res.json({ ok: true, claim: serializeOrder(order) });
        } catch (e) {
            res.status(400).json({ ok: false, error: e.message });
        }
    });

    // ---- booking screenshots + history (per-profile Booking History tab) ----

    app.get('/api/profiles/:id/screenshots', (req, res) => {
        res.json({ ok: true, screenshots: listBookingScreenshots(req.params.id) });
    });

    app.get('/api/profiles/:id/bookings', (req, res) => {
        res.json({ ok: true, bookings: listBookingHistory(req.params.id) });
    });

    // ---- system health / settings (read-only) ----

    app.get('/api/system', (req, res) => {
        res.json({ ok: true, system: getSystemHealth() });
    });

    app.get('/api/settings', (req, res) => {
        res.json({ ok: true, settings: getSettingsSummary() });
    });

    app.get('/api/logs', (req, res) => {
        const component = LOG_COMPONENTS.includes(req.query.component) ? req.query.component : 'admin';
        const limit = Math.min(parseInt(req.query.limit, 10) || 200, 1000);
        res.json({ ok: true, component, entries: readLogFile(component, limit) });
    });

    // ---- console (full shell, gated by a second password) ----

    app.get('/api/console/status', (req, res) => {
        const nonce = verifyConsoleCookie(parseCookies(req)[CONSOLE_COOKIE_NAME]);
        if (!nonce) return res.json({ ok: true, unlocked: false });
        const state = consoleSessionState.get(nonce) || { cwd: PROJECT_ROOT };
        res.json({ ok: true, unlocked: true, cwd: state.cwd });
    });

    app.post('/api/console/unlock', (req, res) => {
        if (!CONSOLE_PASSWORD) {
            return res.status(503).json({ ok: false, error: 'Console is not configured — set AUTOBOOK_CONSOLE_PASSWORD in autobook/.env to enable it.' });
        }
        const key = req.ip;
        if (consoleRateLimited(key)) {
            return res.status(429).json({ ok: false, error: 'Too many attempts. Try again later.' });
        }
        const provided = (req.body && req.body.password) || '';
        if (!provided || !safeEqual(provided, CONSOLE_PASSWORD)) {
            recordConsoleFailure(key);
            console.warn(`Console unlock rejected from ${req.ip}`);
            return res.status(401).json({ ok: false, error: 'Wrong console password.' });
        }
        clearConsoleFailures(key);
        const { value, expiresAt } = makeConsoleCookieValue();
        res.setHeader('Set-Cookie', `${CONSOLE_COOKIE_NAME}=${encodeURIComponent(value)}; HttpOnly; Path=/; SameSite=Lax; Max-Age=${Math.floor((expiresAt - Date.now()) / 1000)}`);
        console.warn(`Console unlocked from ${req.ip}`);
        res.json({ ok: true, cwd: PROJECT_ROOT });
    });

    app.post('/api/console/lock', (req, res) => {
        const nonce = verifyConsoleCookie(parseCookies(req)[CONSOLE_COOKIE_NAME]);
        if (nonce) consoleSessionState.delete(nonce);
        res.setHeader('Set-Cookie', `${CONSOLE_COOKIE_NAME}=; HttpOnly; Path=/; SameSite=Lax; Max-Age=0`);
        res.json({ ok: true });
    });

    app.post('/api/console/run', requireConsoleAuth, async (req, res) => {
        const command = (req.body && req.body.command || '').toString();
        if (!command.trim()) return res.status(400).json({ ok: false, error: 'No command given.' });
        console.warn(`Console command from ${req.ip} (cwd ${consoleSessionState.get(req.consoleSessionId)?.cwd}): ${command}`);
        try {
            const result = await runConsoleCommand(req.consoleSessionId, command);
            res.json({ ok: true, ...result });
        } catch (e) {
            res.status(500).json({ ok: false, error: e.message });
        }
    });

    // Serves the actual image bytes — auth-gated (sits behind the
    // requireAuth middleware above), and the date/filename are validated
    // rather than trusted, since they come straight off the URL.
    //
    // NOTE: `date` is intentionally NOT restricted to YYYY-MM-DD. It used
    // to be, but listBookingScreenshots() above builds these very URLs
    // from whatever the date folder is ACTUALLY named on disk (raw
    // fs.readdirSync results) — and folders written by an older/skewed
    // worker build (or any date label toISODateFolder() couldn't parse,
    // see tools/dry_run_booking.js) can be non-ISO, e.g. a literal
    // "September 17, 2026". A strict ISO-only regex here rejected those
    // as 400 Bad Request even though the panel's own listing linked
    // straight to them — the exact bug this comment is fixing. What
    // actually matters for safety is blocking path traversal, not the
    // date's shape.
    app.get('/screenshots/:profileId/:date/:filename', (req, res) => {
        const { profileId, date, filename } = req.params;
        if (!isValidProfileId(profileId) || !isSafePathSegment(date) || !/^[\w.-]+\.png$/.test(filename)) {
            return res.status(400).send('Bad request');
        }
        const filePath = path.join(PROFILES_DIR, profileId, 'booking-screenshots', date, filename);
        if (!fs.existsSync(filePath)) return res.status(404).send('Not found');
        res.sendFile(filePath);
    });

    // Payment/transaction screenshot for a specific claim.
    app.get('/claim-screenshots/:orderId', (req, res) => {
        const order = orders.getOrder(req.params.orderId);
        if (!order || !order.screenshot_path || !fs.existsSync(order.screenshot_path)) {
            return res.status(404).send('Not found');
        }
        res.sendFile(path.resolve(order.screenshot_path));
    });

    app.use((req, res) => res.status(404).json({ ok: false, error: 'Not found' }));
    // eslint-disable-next-line no-unused-vars
    app.use((err, req, res, next) => {
        console.error('Admin server error:', err);
        res.status(500).json({ ok: false, error: 'Internal error' });
    });

    const server = app.listen(PORT, HOST, () => {
        console.log(`Autobook admin panel listening on ${HOST}:${PORT}`);
    });

    return server;
}

module.exports = { startAdminServer };

if (require.main === module) {
    startAdminServer();
}