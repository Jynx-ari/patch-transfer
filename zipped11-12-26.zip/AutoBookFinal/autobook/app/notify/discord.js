// Lets app/worker/worker.js DM a profile owner directly, without routing
// through bot/bot.py (which is a separate process/container and has no
// queue of its own to receive "please DM this person" requests from). The
// worker already has AUTOBOOK_DISCORD_TOKEN in its .env (same token
// bot.py uses — see autobook/.env.example), and Discord's REST API allows
// any request carrying a valid bot token to open/send to a DM channel, so
// no coordination with the bot process is needed.
//
// Uses Node's built-in fetch (Node 18+ — this container is Playwright's
// official image, which ships a recent enough Node; see Dockerfile.worker).
//
// Deliberately silent-fail-safe: a DM failing to send (user has DMs off,
// left the server, bad token, transient API error, etc.) NEVER throws back
// into the job-processing path. Losing a courtesy notification is fine;
// crashing a worker loop over it is not. Callers get a best-effort
// {ok, error?} back and can log it, nothing more.

const DISCORD_API = 'https://discord.com/api/v10';

function token() {
    return process.env.AUTOBOOK_DISCORD_TOKEN || '';
}

async function openDmChannel(discordId) {
    const res = await fetch(`${DISCORD_API}/users/@me/channels`, {
        method: 'POST',
        headers: {
            'Authorization': `Bot ${token()}`,
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({ recipient_id: String(discordId) }),
    });
    if (!res.ok) {
        throw new Error(`open DM channel failed: ${res.status} ${await res.text().catch(() => '')}`);
    }
    const data = await res.json();
    return data.id;
}

/**
 * @param {string|number} discordId
 * @param {object} opts
 * @param {string} [opts.content] - message text (2000 char Discord cap; not enforced here)
 * @param {string} [opts.filePath] - optional local path to attach (e.g. an invoice screenshot)
 * @param {string} [opts.fileName] - filename to present the attachment as
 * @returns {Promise<{ok: boolean, error?: string}>}
 */
async function sendDM(discordId, { content, filePath, fileName } = {}) {
    if (!token()) {
        return { ok: false, error: 'AUTOBOOK_DISCORD_TOKEN not set in autobook/.env' };
    }
    try {
        const channelId = await openDmChannel(discordId);

        let res;
        if (filePath) {
            const fs = require('fs');
            const buf = fs.readFileSync(filePath);
            const name = fileName || require('path').basename(filePath);
            const form = new FormData();
            form.append('payload_json', JSON.stringify({ content: content || '' }));
            form.append('files[0]', new Blob([buf]), name);
            res = await fetch(`${DISCORD_API}/channels/${channelId}/messages`, {
                method: 'POST',
                headers: { 'Authorization': `Bot ${token()}` },
                body: form,
            });
        } else {
            res = await fetch(`${DISCORD_API}/channels/${channelId}/messages`, {
                method: 'POST',
                headers: {
                    'Authorization': `Bot ${token()}`,
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ content: content || '' }),
            });
        }

        if (!res.ok) {
            return { ok: false, error: `send DM failed: ${res.status} ${await res.text().catch(() => '')}` };
        }
        return { ok: true };
    } catch (e) {
        return { ok: false, error: e.message };
    }
}

/**
 * Posts a message to a specific text channel as Stella (the bot), using
 * the same REST client/token as sendDM — NOT the Discord webhook Monitor
 * Booking uses for the "date just opened" alert (see monitor-booking/
 * src/notifier/discord.js). Used for the post-batch booking-results
 * summary (see app/worker/worker.js's postBatchSummaryIfComplete()) so it
 * reads as coming from the bot users already interact with via slash
 * commands and DMs, in a channel rather than scattered across separate
 * DMs only.
 *
 * @param {string} channelId
 * @param {object} opts
 * @param {string} [opts.content]
 * @returns {Promise<{ok: boolean, error?: string}>}
 */
async function sendChannelMessage(channelId, { content } = {}) {
    if (!token()) {
        return { ok: false, error: 'AUTOBOOK_DISCORD_TOKEN not set in autobook/.env' };
    }
    if (!channelId) {
        return { ok: false, error: 'no channel id provided' };
    }
    try {
        const res = await fetch(`${DISCORD_API}/channels/${channelId}/messages`, {
            method: 'POST',
            headers: {
                'Authorization': `Bot ${token()}`,
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ content: content || '' }),
        });
        if (!res.ok) {
            return { ok: false, error: `send channel message failed: ${res.status} ${await res.text().catch(() => '')}` };
        }
        return { ok: true };
    } catch (e) {
        return { ok: false, error: e.message };
    }
}

module.exports = { sendDM, sendChannelMessage };
