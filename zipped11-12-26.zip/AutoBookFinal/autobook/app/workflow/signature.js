// Workflow step: check the terms agreement box, then draw the profile's OWN
// signature onto the real canvas by replaying genuine mouse events — same
// approach as the old prototype's signature.js, except:
//
//   1. The stroke path comes from a real signature the profile owner drew
//      themselves (via tools/signature_capture.html), not a hardcoded
//      zig-zag shared by every profile.
//   2. Each profile can have up to 3 saved variants; one is picked at
//      random per booking.
//   3. Even the SAME variant is replayed with small random jitter
//      (position, scale, timing) each time, so repeated bookings from one
//      profile don't produce byte-identical signatures either.
//
// The site (jquery.signature.js / jSignature per the old prototype's notes)
// listens for real mouse events on the canvas and syncs drawn data into the
// hidden #signature64 textarea itself — we never touch that field directly.

const fs = require('fs');
const path = require('path');

const SIGNATURE_FORMAT = 'autobook-signature-v1';

// Bounds for the per-replay jitter, expressed as fractions of the canvas's
// own width/height (strokes are stored normalized 0..1) rather than raw
// pixels, so jitter scales sensibly regardless of the actual canvas size.
// Kept small: enough that two replays of the same variant aren't identical,
// not so much that the signature stops looking like the person's own
// handwriting.
const JITTER = {
    offsetFraction: 0.015,      // max uniform translation, ~1.5% of canvas size
    scaleRange: 0.05,           // +/- 5% uniform scale, anchored at stroke centroid
    pointNoiseFraction: 0.003,  // small per-point wobble, ~0.3% of canvas size
    timingRange: 0.15           // +/- 15% on inter-point delays
};

function signaturesDir(profileId) {
    return path.join(__dirname, '..', '..', 'profiles', String(profileId), 'signatures');
}

function listSignatureFiles(profileId) {
    const dir = signaturesDir(profileId);
    if (!fs.existsSync(dir)) return [];
    return fs.readdirSync(dir)
        .filter(f => /^sig_\d+\.json$/.test(f))
        .map(f => path.join(dir, f));
}

/**
 * Loads one of the profile's saved signature variants at random.
 * @returns {{ filePath: string, strokes: Array<Array<{x:number,y:number,t:number}>> } | null}
 *   null if the profile has no saved signatures yet (caller should fall
 *   back to something safe or fail loudly rather than silently sharing a
 *   default signature across profiles).
 */
function loadRandomSignature(profileId) {
    const files = listSignatureFiles(profileId);
    if (files.length === 0) return null;

    const chosen = files[Math.floor(Math.random() * files.length)];
    const raw = JSON.parse(fs.readFileSync(chosen, 'utf8'));

    if (raw.format !== SIGNATURE_FORMAT || !Array.isArray(raw.strokes) || raw.strokes.length === 0) {
        throw new Error(`Malformed signature file: ${chosen}`);
    }

    return { filePath: chosen, strokes: raw.strokes };
}

function randRange(min, max) {
    return min + Math.random() * (max - min);
}

/** Applies uniform jitter (offset + scale + per-point noise) to a stroke set.
 *  All jitter is done in normalized (0..1) space, so it scales with the
 *  canvas regardless of its actual on-page pixel size. */
function jitterStrokes(strokes) {
    const dx = randRange(-JITTER.offsetFraction, JITTER.offsetFraction);
    const dy = randRange(-JITTER.offsetFraction, JITTER.offsetFraction);
    const scale = 1 + randRange(-JITTER.scaleRange, JITTER.scaleRange);

    // Anchor scaling at the overall centroid so the signature doesn't drift
    // toward a corner of the canvas.
    let sumX = 0, sumY = 0, n = 0;
    for (const stroke of strokes) {
        for (const p of stroke) { sumX += p.x; sumY += p.y; n++; }
    }
    const cx = sumX / n;
    const cy = sumY / n;

    const clamp01 = (v) => Math.min(1, Math.max(0, v));

    return strokes.map(stroke => stroke.map(p => {
        const scaledX = cx + (p.x - cx) * scale + dx;
        const scaledY = cy + (p.y - cy) * scale + dy;
        return {
            x: clamp01(scaledX + randRange(-JITTER.pointNoiseFraction, JITTER.pointNoiseFraction)),
            y: clamp01(scaledY + randRange(-JITTER.pointNoiseFraction, JITTER.pointNoiseFraction)),
            t: p.t
        };
    }));
}

async function replayStroke(page, stroke, box) {
    const toPixel = (p) => ({
        x: box.x + Math.min(Math.max(p.x, 0), 1) * box.width,
        y: box.y + Math.min(Math.max(p.y, 0), 1) * box.height
    });

    const first = toPixel(stroke[0]);
    await page.mouse.move(first.x, first.y);
    await page.mouse.down();

    let lastT = stroke[0].t;
    for (const p of stroke.slice(1)) {
        const px = toPixel(p);
        await page.mouse.move(px.x, px.y);

        const rawDelay = Math.max(0, p.t - lastT);
        const jittered = rawDelay * (1 + randRange(-JITTER.timingRange, JITTER.timingRange));
        const delay = Math.min(30, Math.max(2, jittered)); // keep replays snappy but non-uniform
        await page.waitForTimeout(delay);
        lastT = p.t;
    }
    await page.mouse.up();
}

/**
 * @param {import('playwright').Page} page
 * @param {string|number} profileId
 * @param {object} selectors - config.SELECTORS (agreementCheckbox, signatureCanvas, signatureHiddenField)
 */
async function applySignature(page, profileId, selectors) {
    const agreementBox = await page.$(selectors.agreementCheckbox);
    if (!agreementBox) throw new Error('Agreement checkbox not found');
    const isChecked = await page.$eval(selectors.agreementCheckbox, el => el.checked);
    if (!isChecked) await page.click(selectors.agreementCheckbox);

    const canvas = await page.$(selectors.signatureCanvas);
    if (!canvas) throw new Error('Canvas not found');
    const box = await canvas.boundingBox();
    if (!box) throw new Error('Canvas not found (not visible / zero size)');

    const loaded = loadRandomSignature(profileId);
    if (!loaded) {
        throw new Error(
            `Profile ${profileId} has no saved signature variants. ` +
            `Have them draw one at tools/signature_capture.html and upload it via /signature-add.`
        );
    }

    const strokes = jitterStrokes(loaded.strokes);
    for (const stroke of strokes) {
        await replayStroke(page, stroke, box);
    }

    const signatureValue = await page.waitForFunction(
        (selector) => {
            const el = document.querySelector(selector);
            return el && el.value ? el.value : false;
        },
        selectors.signatureHiddenField,
        { timeout: 3000 }
    ).then(handle => handle.jsonValue()).catch(() => null);

    if (!signatureValue) {
        throw new Error('Signature was not captured (hidden field still empty)');
    }

    return {
        signatureApplied: true,
        signatureVariant: path.basename(loaded.filePath)
    };
}

module.exports = { applySignature, loadRandomSignature, listSignatureFiles };
