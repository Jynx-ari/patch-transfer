// Manually fires a REAL autobook trigger — isTest:false, using the exact
// same sendAutobookTrigger() function the real polling loop in main.js
// calls when it detects a genuinely new open date. This is NOT a
// simulation: if autobook-worker is running with AUTOBOOK_MODE=production
// (and AUTOBOOK_ALLOW_REAL_SUBMIT=true), this WILL cause a real booking
// attempt that clicks the real submit button and reserves a real seat.
//
// Deliberately separate from src/notifier/index.js's notify() — this
// calls sendAutobookTrigger() directly, so it does NOT also fire Discord
// or SMS notifications, and does NOT touch the alerted-dates dedup
// database. It's a narrow, single-purpose tool: send exactly one real
// trigger for a date YOU choose, nothing else.
//
// Usage:
//   node tools/manual_autobook_trigger.js "September 2, 2026"
//
// Requires typing the date back exactly to confirm, since a typo here
// (wrong date, wrong year) sent while autobook-worker is in production
// mode means a real booking attempt for the WRONG date.

const _NODE_ENV = String(process.env.NODE_ENV || '').toLowerCase();
if (_NODE_ENV === 'debug') {
    require('dotenv').config({ debug: true });
} else if (_NODE_ENV !== 'production') {
    require('dotenv').config();
}

const readline = require('readline');
const { sendAutobookTrigger } = require('../src/notifier/autobook');

function ask(question) {
    const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
    return new Promise((resolve) => rl.question(question, (answer) => { rl.close(); resolve(answer); }));
}

async function main() {
    const date = process.argv[2];
    if (!date) {
        console.error('Usage: node tools/manual_autobook_trigger.js "<date exactly as it should be matched, e.g. September 2, 2026>"');
        process.exit(1);
    }

    const modeHint = process.env.AUTOBOOK_MODE; // not authoritative here — this script has no visibility into the OTHER container's actual running env, just showing it if this host happens to share it
    console.log('\n================ MANUAL REAL AUTOBOOK TRIGGER ================');
    console.log(`Date:              "${date}"`);
    console.log(`AUTOBOOK_TRIGGER_URL:     ${process.env.AUTOBOOK_TRIGGER_URL || '(unset — will fail)'}`);
    console.log(`AUTOBOOK_TRIGGER_ENABLED: ${process.env.AUTOBOOK_TRIGGER_ENABLED || 'false'}`);
    console.log('This sends a REAL (isTest:false) trigger — the exact same call the');
    console.log('real polling loop makes. If autobook-worker is running with');
    console.log('AUTOBOOK_MODE=production, this WILL attempt a real booking and');
    console.log('click the real submit button for every profile with a valid config.');
    console.log('===============================================================\n');

    const confirmation = await ask(`Type the date EXACTLY as shown above to confirm ("${date}"): `);
    if (confirmation.trim() !== date) {
        console.error('\nTyped confirmation did not match exactly — aborting. Nothing was sent.');
        process.exit(1);
    }

    console.log('\nSending...');
    const result = await sendAutobookTrigger([date]);
    console.log('\nResult:', JSON.stringify(result, null, 2));

    if (result.skipped) {
        console.log(`\nNothing was sent — reason: ${result.reason}.`);
        if (result.reason === 'disabled') console.log('AUTOBOOK_TRIGGER_ENABLED is not "true" in this .env.');
        if (result.reason === 'misconfigured') console.log('AUTOBOOK_TRIGGER_URL or AUTOBOOK_TRIGGER_SECRET is missing.');
    } else if (result.ok) {
        console.log(`\nSent successfully. ${result.enqueuedCount ?? 0} job(s) enqueued on the autobook-worker side.`);
        if (result.skippedProfiles && result.skippedProfiles.length > 0) {
            console.log(`\n${result.skippedProfiles.length} profile(s) were skipped — this is why enqueuedCount can be 0 even on "ok: true":`);
            result.skippedProfiles.forEach(s => {
                console.log(`  ⤷ profile ${s.profileId}${s.date ? ` for ${s.date}` : ''}: ${s.errors.join('; ')}`);
            });
        }
        console.log('\nCheck: docker compose -f docker-compose.part2.yml logs -f autobook-worker');
    } else {
        console.log('\nSend failed — see error above.');
    }
}

main();