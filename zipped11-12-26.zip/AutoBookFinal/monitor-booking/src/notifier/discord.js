const { WebhookClient } = require('discord.js');
const axios = require('axios');

const dcWebhook = process.env.DISCORDWEBHOOK_URL;
const dcTestWebhook = process.env.DISCORD_TEST_WEBHOOK_URL;
const DISCORD_ENABLED = String(process.env.DISCORD_ENABLED || 'true').toLowerCase() === 'true';
const DISCORD_USE_TEST_WEBHOOK = String(process.env.DISCORD_USE_TEST_WEBHOOK || 'false').toLowerCase() === 'true';
const DISCORD_PING = String(process.env.DISCORD_PING || 'false').toLowerCase() === 'true';
const DISCORD_ROLE_ID = String(process.env.DISCORD_ROLE_ID || '1471243274617360434').trim();
const DISCORD_DEBUG_MENTION_ID = '1525866696898777179';
const DEBUG = String(process.env.DEBUG).toLowerCase() === 'true';

// Every timestamp shown in a Discord alert should read in Philippine
// time — the shuttle runs out of FEU Alabang — but Docker's node:20-slim
// base image defaults its system clock to UTC regardless of what host
// this actually runs on. IMPORTANT: passing locale 'en-PH' below (as this
// file already did before this fix) only changes word order/formatting
// conventions — it does NOT change which timezone the time is computed
// in. Only an explicit `timeZone` option does that, which is why every
// toLocaleDateString/toLocaleTimeString call below now passes one
// explicitly instead of relying on 'en-PH' to imply it.
const TIMEZONE = process.env.TIMEZONE || 'Asia/Manila';

const discordWebhookUrl = DISCORD_USE_TEST_WEBHOOK && dcTestWebhook ? dcTestWebhook : dcWebhook;
const discordClient = (DISCORD_ENABLED && discordWebhookUrl) ? new WebhookClient({ url: discordWebhookUrl }) : null;

async function postWithRetry(url, payload, retries = 3, backoff = 500) {
  for (let i = 0; i < retries; i++) {
    try {
      await axios.post(url, payload, { timeout: 5000 });
      return true;
    } catch (e) {
      if (i === retries - 1) throw e;
      await new Promise((resolve) => setTimeout(resolve, backoff * Math.pow(2, i)));
    }
  }
}

function buildDiscordPayload(currentlyOpenWithTime, shouldPing, autobookStatus = {}) {
  const now = new Date();
  const titleDate = now.toLocaleDateString('en-US', { timeZone: TIMEZONE, month: 'numeric', day: 'numeric', year: '2-digit' });
  const titleTime = now.toLocaleTimeString('en-US', { timeZone: TIMEZONE, hour: 'numeric', minute: '2-digit', second: '2-digit', hour12: true });
  const title = `*                 SHUTTLE NOTIFICATION!!\n*         :calendar_spiral: (${titleDate})         :clock1: ${titleTime}\n\n**OPEN DATES:**`;

  const fields = currentlyOpenWithTime.length > 0
    ? currentlyOpenWithTime.map((dateInfo) => ({
        name: `${dateInfo.date}   |   Added on: ${new Date(dateInfo.firstSeenAt).toLocaleDateString('en-PH', { timeZone: TIMEZONE, month: 'long', day: 'numeric', year: 'numeric' })}   [${new Date(dateInfo.firstSeenAt).toLocaleTimeString('en-PH', { timeZone: TIMEZONE, hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: true })}]`,
        value: '--------------------------------------------------------'
      }))
    : [{ name: 'EMPTY', value: '--------------------------------------------------------' }];

  fields.push({ name: 'BOOK HERE:', value: '[CLICK ME](https://feua.kliquep2p.com/client/booking-now)' });

  // Purely informational per-profile Autobook status, built in
  // src/notifier/index.js from app/trigger/server.js's response. Each
  // field only appears if that group is non-empty. "Attempting" means
  // Autobook accepted the job onto its queue just now — NOT that it has
  // finished or succeeded yet; that confirmation comes later as a direct
  // Discord DM to the profile owner once the real browser automation
  // completes (see index.js's doc comment for why this alert can't wait
  // for that).
  const {
    attempting = [],
    alreadyBooked = [],
    inactive = [],
    locked = [],
    invalid = [],
  } = autobookStatus;

  if (attempting.length > 0) {
    fields.push({ name: '🚗 Autobooking now (result comes via DM)', value: attempting.join(', ') });
  }
  if (alreadyBooked.length > 0) {
    fields.push({ name: '✅ Already booked (Autobook skipped)', value: alreadyBooked.join(', ') });
  }
  if (inactive.length > 0) {
    fields.push({ name: '⏸️ Paused (Autobook skipped)', value: inactive.join(', ') });
  }
  if (locked.length > 0) {
    fields.push({ name: '🔒 Locked by admin (Autobook skipped)', value: locked.join(', ') });
  }
  if (invalid.length > 0) {
    fields.push({ name: '⚠️ Incomplete config (Autobook skipped)', value: invalid.join(', ') });
  }

  const pingPrefix = DEBUG ? `<@${DISCORD_DEBUG_MENTION_ID}>` : (shouldPing || DISCORD_PING ? `<@&${DISCORD_ROLE_ID}>` : '');

  return {
    embeds: [{ title, color: 16763904, fields }],
    content: pingPrefix || null,
    allowedMentions: DEBUG ? { users: [DISCORD_DEBUG_MENTION_ID] } : undefined
  };
}

async function sendDiscord(currentlyOpenWithTime, shouldPing = false, autobookStatus = {}) {
  if (!DISCORD_ENABLED || !discordClient) return { success: false, error: 'Discord disabled or webhook missing' };

  const payload = buildDiscordPayload(currentlyOpenWithTime, shouldPing, autobookStatus);
  try {
    await discordClient.send(payload);
    return { success: true };
  } catch (error) {
    return { success: false, error: error.message || String(error) };
  }
}

module.exports = { sendDiscord };
