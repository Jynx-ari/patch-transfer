// Sends a "these dates just opened" signal to Autobook's trigger server,
// so Autobook doesn't need to run its own calendar polling — Monitor
// Booking already does that job. This follows the same pattern as
// discord.js/philsms.js in this folder: one function, called from
// notifier/index.js's notify().
//
// Fails soft: if Autobook is down, misconfigured, or disabled, this must
// never throw in a way that breaks the existing Discord/SMS notifications
// that already work today.

const AUTOBOOK_TRIGGER_URL = process.env.AUTOBOOK_TRIGGER_URL; // e.g. http://127.0.0.1:4790/trigger/date-open
const AUTOBOOK_TRIGGER_SECRET = process.env.AUTOBOOK_TRIGGER_SECRET;
const AUTOBOOK_TRIGGER_ENABLED = String(process.env.AUTOBOOK_TRIGGER_ENABLED || 'false').toLowerCase() === 'true';
const TIMEOUT_MS = 5000;

/**
 * @param {string[]} newDates - only genuinely NEW dates, not the full
 *   currently-open list, so Autobook doesn't re-enqueue jobs for dates it
 *   (or a previous run) already handled.
 */
async function sendAutobookTrigger(newDates) {
    if (!AUTOBOOK_TRIGGER_ENABLED) {
        return { skipped: true, reason: 'disabled' };
    }
    if (!AUTOBOOK_TRIGGER_URL || !AUTOBOOK_TRIGGER_SECRET) {
        console.warn('AUTOBOOK_TRIGGER_ENABLED is true but AUTOBOOK_TRIGGER_URL/SECRET is missing — skipping.');
        return { skipped: true, reason: 'misconfigured' };
    }
    if (!Array.isArray(newDates) || newDates.length === 0) {
        return { skipped: true, reason: 'no new dates' };
    }

    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), TIMEOUT_MS);

    try {
        const res = await fetch(AUTOBOOK_TRIGGER_URL, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'x-trigger-secret': AUTOBOOK_TRIGGER_SECRET,
            },
            body: JSON.stringify({
                dates: newDates,
                detectedAt: new Date().toISOString(),
                source: 'monitor',
            }),
            signal: controller.signal,
        });

        const data = await res.json().catch(() => ({}));
        if (!res.ok) {
            console.error(`Autobook trigger rejected (${res.status}):`, data.error || res.statusText);
            return { skipped: false, ok: false, status: res.status };
        }

        console.log(`Autobook trigger: enqueued ${data.enqueuedCount ?? 0} booking job(s) for ${newDates.length} new date(s).`);
        // data.skipped carries WHY each profile was skipped (from
        // app/trigger/server.js's validateProfile()/active-flag check) —
        // forwarded here too so a 0-enqueued result is debuggable from
        // this side, not just from the autobook-worker container's own
        // logs. data.enqueued (the actual array, not just the count) is
        // forwarded too now, so a caller can show WHO is being attempted,
        // not just how many.
        return {
            skipped: false,
            ok: true,
            enqueuedCount: data.enqueuedCount,
            enqueuedProfiles: data.enqueued || [],
            skippedProfiles: data.skipped || [],
        };
    } catch (err) {
        // Network error, timeout, Autobook not running, etc. — log and move on.
        console.error('Failed to reach Autobook trigger server:', err.message);
        return { skipped: false, ok: false, error: err.message };
    } finally {
        clearTimeout(timeout);
    }
}

module.exports = { sendAutobookTrigger };
