const { sendDiscord } = require('./discord');
const { sendSms } = require('./philsms');
const { sendAutobookTrigger } = require('./autobook');

async function notify({ discord = false, sms = false, autobook = false, shouldPing = false, currentlyOpenWithTime = [], newDates = [] }) {
  const results = { discord: null, sms: null, autobook: null };

  // Autobook is called FIRST (not after Discord/SMS as before) purely so
  // its response — which profiles it already has a logged booking for —
  // is available in time to fold into the Discord alert below. Discord
  // and SMS still go out unconditionally regardless of what Autobook
  // reports; nothing here makes them wait on or depend on Autobook being
  // reachable (see sendAutobookTrigger's own "fails soft" doc comment).
  if (autobook) {
    results.autobook = await sendAutobookTrigger(newDates);
  }

  // Build the full per-profile status breakdown from Autobook's response
  // — not just "already booked", but everyone Autobook is attempting
  // right now, and everyone skipped for any other reason (inactive,
  // incomplete config). Falls back to the raw profileId when a profile
  // has no `name` set. Purely informational for the Discord alert; it
  // does not change what Autobook actually does.
  //
  // IMPORTANT LIMITATION: "attempting" is NOT the same as "successfully
  // booked". Enqueuing a job here just means Autobook accepted it onto
  // its queue — the actual browser automation (login, form-fill, submit)
  // runs asynchronously afterward and can take anywhere from seconds to
  // a couple minutes, well after this HTTP response already came back.
  // Whether a given attempt actually succeeded is only known once
  // app/worker/worker.js finishes that job — at which point the PROFILE
  // OWNER gets a direct Discord DM with the invoice screenshot (success)
  // or a failure notice (see app/worker/worker.js's sendDM calls). This
  // alert can't wait around for that without holding up the "a date just
  // opened" ping for everyone by however long browser automation takes,
  // so it deliberately doesn't try — it reports "attempting" here, and
  // the per-profile DM is what confirms the real outcome.
  const uniqueNames = arr => [...new Set(arr.map(s => s.profileName || s.profileId))];

  const attempting = uniqueNames(results.autobook?.enqueuedProfiles || []);
  const skippedAll = results.autobook?.skippedProfiles || [];
  const alreadyBookedUnique = uniqueNames(skippedAll.filter(s => s.reason === 'already_booked'));
  const inactiveUnique = uniqueNames(skippedAll.filter(s => s.reason === 'inactive'));
  const lockedUnique = uniqueNames(skippedAll.filter(s => s.reason === 'locked'));
  const invalidUnique = uniqueNames(skippedAll.filter(s => s.reason === 'invalid'));

  if (discord) {
    results.discord = await sendDiscord(currentlyOpenWithTime, shouldPing, {
      attempting,
      alreadyBooked: alreadyBookedUnique,
      inactive: inactiveUnique,
      locked: lockedUnique,
      invalid: invalidUnique,
    });
  }

  if (sms) {
    results.sms = await sendSms(currentlyOpenWithTime);
  }

  return results;
}

module.exports = { notify };
