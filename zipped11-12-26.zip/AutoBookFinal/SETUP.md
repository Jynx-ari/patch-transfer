# Autobook + Monitor Booking — Complete Setup & Reference

This replaces the older `INSTRUCTIONS.md` and `CASAOS_SETUP.md` (both now
out of date — they were written before the production worker, the
multi-save signature flow, and the SMS notifier existed). Everything you
need is in this one file.

```
your-folder/
  docker-compose.part2.yml   <- root, one level above both project folders
  monitor-booking/           <- watches feua.kliquep2p.com for open dates
  autobook/                  <- Discord bot + browser automation + worker
```

---

## 1. What this system actually does, end to end

```
Monitor Booking (watches the site)
        │  detects a newly opened date
        ▼
  Trigger HTTP call (shared secret)
        │
        ▼
autobook-worker container
  ├─ hosts the trigger HTTP endpoint itself
  ├─ builds one booking job PER active profile (up to 5)
  ├─ shared in-memory job queue
  └─ 2 worker loops pull jobs off the queue, one profile at a time
        │
        ▼
  Playwright drives feua.kliquep2p.com for real:
  login → origin → dropoff → date → van → time → signature → submit
        │
        ▼
  Screenshot + JSON result written to profiles/<id>/booking-results/
  (or test-results/ in test mode)
```

Everything above is real and wired together. What's still a known
limitation: **the "did it actually book?" confirmation check is a
best-effort heuristic**, not a guarantee — see §7.

---

## 2. Prerequisites

- **Node.js 20+** — for `autobook/app`, `autobook/tools`, and
  `monitor-booking/` (only needed if running outside Docker)
- **Python 3.10+** — for `bot/bot.py` and `tools/inspect_page.py` (also
  only needed outside Docker; the bot itself is not containerized in this
  setup — see §5.4)
- **Docker + docker-compose** — for everything else (recommended path)
- A Discord application/bot already created at
  [discord.com/developers/applications](https://discord.com/developers/applications),
  invited to your server with `bot` + `applications.commands` scopes and
  at least **Send Messages** + **Use Application Commands** permissions

---

## 3. Environment files — full reference

Two separate `.env` files. Copy each from its matching `.env.example`.

### `autobook/.env`

| Variable | Default | What it does |
|---|---|---|
| `AUTOBOOK_TRIGGER_PORT` | `4790` | Port the worker's trigger HTTP endpoint listens on |
| `AUTOBOOK_TRIGGER_SECRET` | *(required)* | Shared secret — must match `monitor-booking/.env`'s copy exactly |
| `AUTOBOOK_DISCORD_TOKEN` | *(required)* | Discord bot token |
| `AUTOBOOK_TEST_GUILD_ID` | *(unset)* | Set during dev for instant slash-command sync to one server; unset for global |
| `AUTOBOOK_SIGNATURE_PORT` | `4791` | Signature capture web server's port |
| `AUTOBOOK_SIGNATURE_TOKEN_TTL_MIN` | `15` | How long a `/signature-link` session stays valid |
| `AUTOBOOK_SIGNATURE_BASE_URL` | *(unset)* | Public URL the bot builds signature links from, e.g. `https://sign.nogabautomations.com` |
| `AUTOBOOK_CREDENTIALS_KEY` | *(required)* | Fernet key encrypting saved site logins at rest — generate once, never lose it |
| **`AUTOBOOK_MODE`** | **`test`** | **`test` = dry-run only, never submits. `production` = real submits.** |
| **`AUTOBOOK_ALLOW_REAL_SUBMIT`** | **`false`** | **Must ALSO be `true` for production mode to actually start — two independent flags, on purpose** |
| `AUTOBOOK_WORKER_COUNT` | `2` | Concurrent worker loops sharing the queue (spec default: 2) |

### `monitor-booking/.env`

| Variable | Default | What it does |
|---|---|---|
| `DISCORDWEBHOOK_URL` / `DISCORD_TEST_WEBHOOK_URL` | — | Discord notification webhooks (prod / test) |
| `DISCORD_USE_TEST_WEBHOOK` | `false` | Use the test webhook instead of prod |
| `DISCORD_ENABLED` | `true` | Toggle Discord notifications |
| `DISCORD_PING` / `DISCORD_ROLE_ID` | — | Optional role ping on new dates |
| `TEAMS_ENABLED` | `true` | Toggle Teams notifications |
| `PHILSMS_API_TOKEN` | *(unset)* | PhilSMS API token — **leave unset to disable SMS entirely** |
| `PHILSMS_SENDER` | `PhilSMS` | Sender name shown on the text |
| `PHILSMS_RECIPIENT` | *(unset)* | **Single** phone number that receives the text. Only one — see §8 for multi-recipient. |
| `AUTOBOOK_TRIGGER_ENABLED` | `false` | Must be `true` for Monitor Booking to actually signal Autobook |
| `AUTOBOOK_TRIGGER_URL` | `http://autobook-worker:4790/trigger/date-open` | Where the trigger POST goes — service name in Docker, not `localhost` |
| `AUTOBOOK_TRIGGER_SECRET` | *(required)* | Must match `autobook/.env`'s copy exactly |

SMS was already wired in code (`monitor-booking/src/notifier/philsms.js`)
but its three env vars weren't documented in `.env.example` until this
session — the feature was silently inert without them. It's still
inert unless you actually fill in `PHILSMS_API_TOKEN` and
`PHILSMS_RECIPIENT`.

---

## 4. Local/dev workflow (no Docker)

```bash
cd autobook
npm install
npx playwright install chromium
sudo npx playwright install-deps chromium   # Linux servers only

python -m pip install -r requirements.txt --break-system-packages
playwright install chromium                 # for tools/inspect_page.py

python bot/bot.py                           # Discord config bot
```

**One-off manual dry run against a single profile:**
```bash
node tools/dry_run_booking.js profile1 --leg morning
```
Never clicks submit, regardless of any env var — this is a separate
standalone CLI tool from the worker.

**Persistent watcher, test mode** (equivalent to what the deployed
worker does with `AUTOBOOK_MODE=test`):
```bash
AUTOBOOK_MODE=test node app/worker/worker.js
# from another terminal:
node tools/fake_trigger.js "August 31, 2026"
```

---

## 5. Docker deployment (CasaOS or any Docker host)

### 5.1 Get both folders + the compose file onto the machine

```
/DATA/AppData/
├── monitor-booking/
├── autobook/
└── docker-compose.part2.yml
```

### 5.2 Fill in both `.env` files (see §3's tables)

Generate the shared trigger secret once and use it in both places:
```bash
openssl rand -hex 16
```

Leave `AUTOBOOK_MODE=test` and `AUTOBOOK_ALLOW_REAL_SUBMIT=false` for
now — flip these once you've actually watched a test run succeed
end-to-end (§6).

### 5.3 Deploy

```bash
docker compose -f docker-compose.part2.yml up -d --build
```

This brings up three containers on a shared `autobook-net` network:

- **`monitor-booking`** — unchanged, watches the site
- **`autobook-worker`** — hosts the trigger endpoint AND runs the
  Playwright automation, per `AUTOBOOK_MODE`
- **`autobook-signature`** — lightweight, phone-facing signature capture
  page (no Playwright, can never submit anything)

The old `autobook-trigger` service is commented out in the compose file.
**Do not uncomment it while `autobook-worker` is also running** — they'd
each hold their own private in-memory queue, and whichever one Monitor
Booking actually reaches would enqueue jobs the other can never see.
It's kept there only for isolated local testing on a different
network/port.

### 5.4 The Discord bot itself still runs on the host, not in Docker

`bot/bot.py` isn't containerized in this setup (profile-folder ownership
gets messy across host/container boundaries — see §9). Run it directly:
```bash
cd autobook && python bot/bot.py
```
Consider a systemd service or `pm2` to keep it alive across reboots;
that's outside this doc's scope.

### 5.5 Signature capture over Cloudflare Tunnel (optional but recommended)

1. Join `cloudflared` to `autobook-net`:
   ```bash
   docker network connect autobook-net <cloudflared-container-name>
   ```
2. In Cloudflare Zero Trust → **Networks → Tunnels** → your tunnel →
   **Public Hostname**: subdomain `sign`, domain `nogabautomations.com`,
   service `HTTP`, URL `autobook-signature:4791`.
3. Set `AUTOBOOK_SIGNATURE_BASE_URL=https://sign.nogabautomations.com`
   in `autobook/.env` and restart `bot.py`.
4. Test with `/signature-link` in Discord — open the link on a phone,
   draw, save. It should update in place to `Saved as signature variant
   1/3` and let you draw the next variant **without reloading** (see §7
   for how this works now).

### 5.6 Admin panel over Cloudflare Tunnel

Same tunnel container as §5.5 (`wonderful_wing`, or whatever yours is
named — check with `docker ps`), just a **second** public hostname on a
**different** subdomain pointing at the admin container instead. If §5.5
is already done, `cloudflared` is already joined to `autobook-net` — skip
straight to step 2.

1. (Only if you haven't done §5.5 yet) join `cloudflared` to `autobook-net`:
   ```bash
   docker network connect autobook-net <cloudflared-container-name>
   ```
2. In Cloudflare Zero Trust → **Networks → Tunnels** → your tunnel →
   **Public Hostname** → **Add a public hostname**: subdomain `admin`,
   domain `nogabautomations.com`, service `HTTP`, URL `autobook-admin:4792`.
   (Any subdomain works — `admin` is just an example. It does NOT need to
   match the `sign` one from §5.5 in any way; they're two independent
   entries on the same tunnel.)
3. Set `AUTOBOOK_ADMIN_PASSWORD` and `AUTOBOOK_ADMIN_SESSION_SECRET` in
   `autobook/.env` (generate the secret with `openssl rand -hex 32` —
   don't reuse the signature server's token TTL setting, this is a
   different value entirely).
4. Bring the container up:
   ```bash
   docker compose -f docker-compose.part2.yml up -d --build autobook-admin
   ```
5. Visit `https://admin.nogabautomations.com` (or whatever subdomain you
   picked) — you should land on the login page. Log in with
   `AUTOBOOK_ADMIN_PASSWORD` and confirm the profile list loads.

**No `ports:` mapping is exposed on the host for this container on
purpose** — same as the signature server. The only way in is through
Cloudflare's edge, which is also what gives you TLS for free; the
container itself only ever speaks plain HTTP over the internal Docker
network. Don't add a `ports:` entry for this service — that would open a
second, unauthenticated-at-the-network-level path to it that bypasses
Cloudflare entirely.

If the page won't load at all (not even a login screen), check, in order:
- `docker logs autobook-admin` — confirms the Node process actually
  started and is listening on `0.0.0.0:4792` (not just `127.0.0.1`,
  which `AUTOBOOK_ADMIN_HOST=0.0.0.0` already sets by default in the
  compose file).
- `docker network inspect autobook-net` — confirms both
  `cloudflared` and `autobook-admin` show up as connected members.
- The tunnel's own logs (`docker logs <cloudflared-container-name>`) —
  a `dial tcp: lookup autobook-admin: no such host` error there means
  the network join in step 1 didn't actually take, or the compose stack
  needs a restart to pick it up.

If the login page loads but every login attempt fails with "Admin panel
misconfigured", that's `admin_server.js`'s own startup warning — it means
`AUTOBOOK_ADMIN_PASSWORD` and/or `AUTOBOOK_ADMIN_SESSION_SECRET` aren't
actually reaching the container. Confirm they're set in `autobook/.env`
(not just `.env.example`) and re-run step 4 — compose only re-reads
`env_file` contents on container recreation, not with `docker restart`.

---

## 6. Switching between test and production

One switch, no rebuild, no different container:

```bash
# autobook/.env
AUTOBOOK_MODE=test              # safe default — dry-run only
AUTOBOOK_ALLOW_REAL_SUBMIT=false
```
```bash
# autobook/.env — once you're actually ready
AUTOBOOK_MODE=production
AUTOBOOK_ALLOW_REAL_SUBMIT=true
```

Then:
```bash
docker compose -f docker-compose.part2.yml up -d autobook-worker
```

Both flags are checked together on purpose — flipping only one is never
enough to cause a real submission. If `AUTOBOOK_MODE=production` is set
without `AUTOBOOK_ALLOW_REAL_SUBMIT=true`, the worker logs why and
refuses to start rather than silently falling back to test mode.

**Before your first real production run**, watch it closely:
- Tail `docker compose -f docker-compose.part2.yml logs -f autobook-worker`
- Check `profiles/<id>/booking-results/*.json` and the screenshots in
  `autobook/dry-run-screenshots/` for anything marked
  `needs_manual_check`

---

## 7. Signature capture — how the multi-save link works now

Each profile can hold up to **3** signature variants (`MAX_SIGNATURES_PER_PROFILE`
in `signature_server.js`), one picked at random per real booking with
small per-replay jitter so repeated signatures aren't byte-identical.

`/signature-link` in Discord gives a single URL good for the session's
full 15-minute TTL (`AUTOBOOK_SIGNATURE_TOKEN_TTL_MIN`), not just one
save. Under the hood, the URL you're given
(`/s/<usertoken>`) is session-level; each individual *save* uses its own
single-use sub-token (`/s/<usertoken>/<subtoken>`) that's minted fresh on
page load and rotated after every successful save — so the page can walk
through all 3 variants without ever reloading, while each individual save
still can't be replayed. The session token itself is only invalidated
once all 3 slots are full, or its TTL expires.

---

## 8. SMS — current state and what "more" would take

Right now `PHILSMS_RECIPIENT` is a single phone number. Fanning out to
multiple people would mean changing `philsms.js` to loop over a
comma-separated list — that's a real code change, not just an env var,
and hasn't been built. Say the word if you want it.

---

## 9. Multi-profile support

Already works at the queue/trigger level: `enqueueForNewDates()` in
`app/trigger/server.js` loops every active profile (up to the 5-profile
cap) and builds one job per profile per opened date, independently
validated — an invalid profile is skipped without blocking the others.
Each profile needs, independently:
- `/booking-set` (origin/dropoff/time config)
- `/credentials-set` (encrypted site login)
- `/signature-link` → at least one saved signature variant

---

## 10. Known limitations / what to watch

- **Confirmation detection is a heuristic**, not a certainty. The worker
  watches for either the URL leaving `booking-now` or a SweetAlert2
  popup with success-sounding text, within 15 seconds of the submit
  click. If neither fires clearly, the job is marked
  `needs_manual_check` — that's the system correctly admitting
  uncertainty, not a bug. This should get tightened against the site's
  actual real confirmation markup after the first real run.
- **No retry after a submit click, ever**, under any outcome — a
  duplicate click on a submission that may have already gone through
  risks a duplicate real booking, which is worse than one that needs a
  human glance at a screenshot.
- **`bot.py` runs on the host, not in Docker** (see §5.4) — a deliberate
  scope choice, not an oversight.
- **`autobook-worker` and `autobook-trigger` must never run
  simultaneously** — separate in-memory queues, see §5.3.
